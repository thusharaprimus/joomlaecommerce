DROP TABLE IF EXISTS `lal5d_ak_profiles`;
CREATE TABLE `lal5d_ak_profiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `configuration` longtext,
  `filters` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_ak_profiles
(`id`, `description`, `configuration`, `filters`) VALUES 
('1', 'Default Backup Profile', '', '');

DROP TABLE IF EXISTS `lal5d_ak_stats`;
CREATE TABLE `lal5d_ak_stats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `comment` longtext,
  `backupstart` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `backupend` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` enum('run','fail','complete') NOT NULL DEFAULT 'run',
  `origin` varchar(30) NOT NULL DEFAULT 'backend',
  `type` varchar(30) NOT NULL DEFAULT 'full',
  `profile_id` bigint(20) NOT NULL DEFAULT '1',
  `archivename` longtext,
  `absolute_path` longtext,
  `multipart` int(11) NOT NULL DEFAULT '0',
  `tag` varchar(255) DEFAULT NULL,
  `backupid` varchar(255) DEFAULT NULL,
  `filesexist` tinyint(3) NOT NULL DEFAULT '1',
  `remote_filename` varchar(1000) DEFAULT NULL,
  `total_size` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fullstatus` (`filesexist`,`status`),
  KEY `idx_stale` (`status`,`origin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_ak_storage`;
CREATE TABLE `lal5d_ak_storage` (
  `tag` varchar(255) NOT NULL,
  `lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data` longtext,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_akeeba_common`;
CREATE TABLE `lal5d_akeeba_common` (
  `key` varchar(255) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_assets`;
CREATE TABLE `lal5d_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_assets
(`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES 
('1', '0', '0', '185', '0', 'root.1', 'Root Asset', '{\"core.login.site\":{\"6\":1,\"2\":1},\"core.login.admin\":{\"6\":1},\"core.login.offline\":{\"6\":1},\"core.admin\":{\"8\":1},\"core.manage\":{\"7\":1},\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),
('2', '1', '1', '2', '1', 'com_admin', 'com_admin', '{}'),
('3', '1', '3', '6', '1', 'com_banners', 'com_banners', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('4', '1', '7', '8', '1', 'com_cache', 'com_cache', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),
('5', '1', '9', '10', '1', 'com_checkin', 'com_checkin', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),
('6', '1', '11', '12', '1', 'com_config', 'com_config', '{}'),
('7', '1', '13', '16', '1', 'com_contact', 'com_contact', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),
('8', '1', '17', '36', '1', 'com_content', 'com_content', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),
('9', '1', '37', '38', '1', 'com_cpanel', 'com_cpanel', '{}'),
('10', '1', '39', '40', '1', 'com_installer', 'com_installer', '{\"core.admin\":[],\"core.manage\":{\"7\":0},\"core.delete\":{\"7\":0},\"core.edit.state\":{\"7\":0}}'),
('11', '1', '41', '42', '1', 'com_languages', 'com_languages', '{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('12', '1', '43', '44', '1', 'com_login', 'com_login', '{}'),
('13', '1', '45', '46', '1', 'com_mailto', 'com_mailto', '{}'),
('14', '1', '47', '48', '1', 'com_massmail', 'com_massmail', '{}'),
('15', '1', '49', '50', '1', 'com_media', 'com_media', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":{\"5\":1}}'),
('16', '1', '51', '54', '1', 'com_menus', 'com_menus', '{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('17', '1', '55', '56', '1', 'com_messages', 'com_messages', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),
('18', '1', '57', '120', '1', 'com_modules', 'com_modules', '{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('19', '1', '121', '136', '1', 'com_newsfeeds', 'com_newsfeeds', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),
('20', '1', '137', '138', '1', 'com_plugins', 'com_plugins', '{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('21', '1', '139', '140', '1', 'com_redirect', 'com_redirect', '{\"core.admin\":{\"7\":1},\"core.manage\":[]}'),
('22', '1', '141', '142', '1', 'com_search', 'com_search', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),
('23', '1', '143', '144', '1', 'com_templates', 'com_templates', '{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('24', '1', '145', '148', '1', 'com_users', 'com_users', '{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('26', '1', '149', '150', '1', 'com_wrapper', 'com_wrapper', '{}'),
('27', '8', '18', '29', '2', 'com_content.category.2', 'Uncategorised', '{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),
('28', '3', '4', '5', '2', 'com_banners.category.3', 'Uncategorised', '{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('29', '7', '14', '15', '2', 'com_contact.category.4', 'Uncategorised', '{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),
('30', '19', '122', '123', '2', 'com_newsfeeds.category.5', 'Uncategorised', '{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),
('32', '24', '146', '147', '1', 'com_users.category.7', 'Uncategorised', '{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('33', '1', '151', '152', '1', 'com_finder', 'com_finder', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),
('34', '1', '153', '154', '1', 'com_joomlaupdate', 'com_joomlaupdate', '{\"core.admin\":[],\"core.manage\":[],\"core.delete\":[],\"core.edit.state\":[]}'),
('35', '1', '155', '156', '1', 'com_tags', 'com_tags', '{\"core.admin\":[],\"core.manage\":[],\"core.manage\":[],\"core.delete\":[],\"core.edit.state\":[]}'),
('36', '1', '157', '158', '1', 'com_contenthistory', 'com_contenthistory', '{}'),
('37', '1', '159', '160', '1', 'com_ajax', 'com_ajax', '{}'),
('38', '1', '161', '162', '1', 'com_postinstall', 'com_postinstall', '{}'),
('39', '18', '58', '59', '2', 'com_modules.module.1', 'Main Menu', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('40', '18', '60', '61', '2', 'com_modules.module.2', 'Login', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('41', '18', '62', '63', '2', 'com_modules.module.3', 'Popular Articles', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('42', '18', '64', '65', '2', 'com_modules.module.4', 'Recently Added Articles', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('43', '18', '66', '67', '2', 'com_modules.module.8', 'Toolbar', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('44', '18', '68', '69', '2', 'com_modules.module.9', 'Quick Icons', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('45', '18', '70', '71', '2', 'com_modules.module.10', 'Logged-in Users', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('46', '18', '72', '73', '2', 'com_modules.module.12', 'Admin Menu', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('47', '18', '74', '75', '2', 'com_modules.module.13', 'Admin Submenu', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('48', '18', '76', '77', '2', 'com_modules.module.14', 'User Status', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('49', '18', '78', '79', '2', 'com_modules.module.15', 'Title', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('50', '18', '80', '81', '2', 'com_modules.module.16', 'Login Form', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('51', '18', '82', '83', '2', 'com_modules.module.17', 'Breadcrumbs', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('52', '18', '84', '85', '2', 'com_modules.module.79', 'Multilanguage status', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}');

INSERT INTO lal5d_assets
(`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES 
('53', '18', '86', '87', '2', 'com_modules.module.86', 'Joomla Version', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),
('54', '16', '52', '53', '2', 'com_menus.menu.1', 'Main Menu', '{}'),
('55', '1', '163', '164', '1', 'com_virtuemart', 'VIRTUEMART', '{}'),
('56', '1', '165', '166', '1', 'com_virtuemart_allinone', 'VirtueMart_allinone', '{}'),
('57', '18', '88', '89', '2', 'com_modules.module.87', 'VM - Administrator Module', '{}'),
('58', '18', '90', '91', '2', 'com_modules.module.88', 'VM - Currencies Selector', '{}'),
('59', '18', '92', '93', '2', 'com_modules.module.89', 'VM - Featured products', '{}'),
('60', '18', '94', '95', '2', 'com_modules.module.90', 'VM - Search in Shop', '{}'),
('61', '18', '96', '97', '2', 'com_modules.module.91', 'VM - Manufacturer', '{}'),
('62', '18', '98', '99', '2', 'com_modules.module.92', 'VM - Shopping cart', '{}'),
('63', '18', '100', '101', '2', 'com_modules.module.93', 'VM - Category', '{}'),
('64', '18', '102', '103', '2', 'com_modules.module.94', 'menu', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),
('65', '27', '19', '20', '3', 'com_content.article.1', 'Menu', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),
('66', '27', '21', '22', '3', 'com_content.article.2', 'Color Variation', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),
('67', '27', '23', '24', '3', 'com_content.article.3', 'Service', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),
('68', '27', '25', '26', '3', 'com_content.article.4', 'Contact', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),
('69', '1', '167', '168', '1', 'com_gantry', 'Gantry', '{}'),
('70', '8', '30', '35', '2', 'com_content.category.8', 'Color Variation', '{}'),
('71', '70', '31', '32', '3', 'com_content.article.5', 'Color Variation', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),
('72', '19', '124', '125', '2', 'com_newsfeeds.category.9', 'Black Silver Color', '{}'),
('73', '19', '126', '127', '2', 'com_newsfeeds.category.10', 'Silver Black Color', '{}'),
('74', '19', '128', '129', '2', 'com_newsfeeds.category.11', 'Black Red Color', '{}'),
('75', '19', '130', '131', '2', 'com_newsfeeds.category.12', 'Red Black Color', '{}'),
('76', '19', '132', '133', '2', 'com_newsfeeds.category.13', 'Black Blue Color', '{}'),
('77', '19', '134', '135', '2', 'com_newsfeeds.category.14', 'Blue Black Color', '{}'),
('78', '70', '33', '34', '3', 'com_content.article.6', 'Color Variation', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),
('79', '1', '169', '170', '1', 'com_flippingbook', 'FlippingBook', '{}'),
('80', '1', '171', '172', '1', 'com_akeeba', 'Akeeba', '{}'),
('81', '1', '173', '174', '1', 'com_imageshow', 'ImageShow', '{}'),
('82', '18', '104', '105', '2', 'com_modules.module.95', 'JSN ImageShow', '{}'),
('83', '18', '106', '107', '2', 'com_modules.module.96', 'JSN imageshow Quick Icons', '{}'),
('84', '1', '175', '176', '1', 'com_pagebuilder', 'COM_PAGEBUILDER', '{}'),
('85', '18', '108', '109', '2', 'com_modules.module.97', 'Google Analytics Dashboard', '{}'),
('86', '18', '110', '111', '2', 'com_modules.module.98', 'GTranslate', '{}'),
('87', '27', '27', '28', '3', 'com_content.article.7', 'Home', '{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),
('88', '18', '112', '113', '2', 'com_modules.module.99', 'menu', '{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),
('89', '1', '177', '178', '1', 'com_poweradmin', 'PowerAdmin', '{}'),
('90', '18', '114', '115', '2', 'com_modules.module.100', 'JSN PowerAdmin Quick Icons', '{}'),
('91', '1', '179', '180', '1', 'com_uniform', 'UniForm', '{}'),
('92', '18', '116', '117', '2', 'com_modules.module.101', 'JSN UniForm', '{}'),
('93', '1', '181', '182', '1', 'com_mobilize', 'Mobilize', '{}'),
('94', '1', '183', '184', '1', 'com_easyslider', 'EasySlider', '{}'),
('95', '18', '118', '119', '2', 'com_modules.module.102', 'mod_easyslider', '{}');

DROP TABLE IF EXISTS `lal5d_associations`;
CREATE TABLE `lal5d_associations` (
  `id` int(11) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_banner_clients`;
CREATE TABLE `lal5d_banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extrainfo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_banner_tracks`;
CREATE TABLE `lal5d_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_banners`;
CREATE TABLE `lal5d_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `custombannercode` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`(100)),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_banners
(`id`, `cid`, `type`, `name`, `alias`, `imptotal`, `impmade`, `clicks`, `clickurl`, `state`, `catid`, `description`, `custombannercode`, `sticky`, `ordering`, `metakey`, `params`, `own_prefix`, `metakey_prefix`, `purchase_type`, `track_clicks`, `track_impressions`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `reset`, `created`, `language`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `version`) VALUES 
('1', '0', '0', 'banner1', 'banner1', '0', '0', '0', '', '1', '3', '', '', '0', '1', '', '{\"imageurl\":\"images\\/banners\\/main_vis.jpg\",\"width\":\"\",\"height\":\"\",\"alt\":\"\"}', '0', '', '-1', '0', '0', '0', '0000-00-00 00:00:00', '2016-11-14 04:33:50', '0000-00-00 00:00:00', '2016-12-14 00:00:00', '2016-11-14 04:32:40', '*', '602', '', '0000-00-00 00:00:00', '0', '1');

DROP TABLE IF EXISTS `lal5d_categories`;
CREATE TABLE `lal5d_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`(100)),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`(100)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_categories
(`id`, `asset_id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `extension`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `modified_user_id`, `modified_time`, `hits`, `language`, `version`) VALUES 
('1', '0', '0', '0', '25', '0', '', 'system', 'ROOT', 'root', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{}', '', '', '{}', '602', '2011-01-01 00:00:01', '0', '0000-00-00 00:00:00', '0', '*', '1'),
('2', '27', '1', '1', '2', '1', 'uncategorised', 'com_content', 'Uncategorised', 'uncategorised', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2011-01-01 00:00:01', '0', '0000-00-00 00:00:00', '0', '*', '1'),
('3', '28', '1', '3', '4', '1', 'uncategorised', 'com_banners', 'Uncategorised', 'uncategorised', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2011-01-01 00:00:01', '0', '0000-00-00 00:00:00', '0', '*', '1'),
('4', '29', '1', '5', '6', '1', 'uncategorised', 'com_contact', 'Uncategorised', 'uncategorised', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2011-01-01 00:00:01', '0', '0000-00-00 00:00:00', '0', '*', '1'),
('5', '30', '1', '7', '8', '1', 'uncategorised', 'com_newsfeeds', 'Uncategorised', 'uncategorised', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2011-01-01 00:00:01', '0', '0000-00-00 00:00:00', '0', '*', '1'),
('7', '32', '1', '9', '10', '1', 'uncategorised', 'com_users', 'Uncategorised', 'uncategorised', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2011-01-01 00:00:01', '0', '0000-00-00 00:00:00', '0', '*', '1'),
('8', '70', '1', '11', '12', '1', 'color-variation', 'com_content', 'Color Variation', 'color-variation', '', '', '-2', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2016-11-12 06:44:12', '0', '2016-11-12 06:44:12', '0', '*', '1'),
('9', '72', '1', '13', '14', '1', 'black-silver-color', 'com_newsfeeds', 'Black Silver Color', 'black-silver-color', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2016-11-12 06:48:19', '0', '2016-11-12 06:48:19', '0', '*', '1'),
('10', '73', '1', '15', '16', '1', 'silver-black-color', 'com_newsfeeds', 'Silver Black Color', 'silver-black-color', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2016-11-12 06:48:46', '0', '2016-11-12 06:48:46', '0', '*', '1'),
('11', '74', '1', '17', '18', '1', 'black-red-color', 'com_newsfeeds', 'Black Red Color', 'black-red-color', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2016-11-12 06:56:22', '0', '2016-11-12 06:56:22', '0', '*', '1'),
('12', '75', '1', '19', '20', '1', 'red-black-color', 'com_newsfeeds', 'Red Black Color', 'red-black-color', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2016-11-12 06:57:01', '0', '2016-11-12 06:57:01', '0', '*', '1'),
('13', '76', '1', '21', '22', '1', 'black-blue-color', 'com_newsfeeds', 'Black Blue Color', 'black-blue-color', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2016-11-12 06:58:22', '0', '2016-11-12 06:58:22', '0', '*', '1'),
('14', '77', '1', '23', '24', '1', 'blue-black-color', 'com_newsfeeds', 'Blue Black Color', 'blue-black-color', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}', '', '', '{\"author\":\"\",\"robots\":\"\"}', '602', '2016-11-12 06:58:45', '602', '2016-11-12 06:58:55', '0', '*', '1');

DROP TABLE IF EXISTS `lal5d_contact_details`;
CREATE TABLE `lal5d_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `suburb` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `misc` mediumtext COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `webpage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sortname1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortname2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortname3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if contact is featured.',
  `xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_content`;
CREATE TABLE `lal5d_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `introtext` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `fulltext` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `urls` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribs` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_content
(`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES 
('1', '65', 'Menu', 'menu', '', '', '-2', '2', '2016-11-12 06:22:40', '602', '', '2016-11-12 06:22:40', '0', '0', '0000-00-00 00:00:00', '2016-11-12 06:22:40', '0000-00-00 00:00:00', '{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}', '{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\",\"spfeatured_image\":\"\",\"post_format\":\"standard\",\"gallery\":\"\",\"audio\":\"\",\"video\":\"\",\"link_title\":\"\",\"link_url\":\"\",\"quote_text\":\"\",\"quote_author\":\"\",\"post_status\":\"\"}', '1', '3', '', '', '1', '0', '{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}', '0', '*', ''),
('2', '66', 'Color Variation', 'color-variation', '', '', '-2', '2', '2016-11-12 06:23:48', '602', '', '2016-11-12 06:23:48', '0', '0', '0000-00-00 00:00:00', '2016-11-12 06:23:48', '0000-00-00 00:00:00', '{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}', '{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\",\"spfeatured_image\":\"\",\"post_format\":\"standard\",\"gallery\":\"\",\"audio\":\"\",\"video\":\"\",\"link_title\":\"\",\"link_url\":\"\",\"quote_text\":\"\",\"quote_author\":\"\",\"post_status\":\"\"}', '1', '2', '', '', '1', '5', '{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}', '0', '*', ''),
('3', '67', 'Service', 'service', '', '', '-2', '2', '2016-11-12 06:24:19', '602', '', '2016-11-12 06:24:19', '0', '0', '0000-00-00 00:00:00', '2016-11-12 06:24:19', '0000-00-00 00:00:00', '{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}', '{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\",\"spfeatured_image\":\"\",\"post_format\":\"standard\",\"gallery\":\"\",\"audio\":\"\",\"video\":\"\",\"link_title\":\"\",\"link_url\":\"\",\"quote_text\":\"\",\"quote_author\":\"\",\"post_status\":\"\"}', '1', '2', '', '', '1', '2', '{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}', '0', '*', ''),
('4', '68', 'Contact', 'contact', '', '', '-2', '2', '2016-11-12 06:24:42', '602', '', '2016-11-12 06:24:42', '0', '0', '0000-00-00 00:00:00', '2016-11-12 06:24:42', '0000-00-00 00:00:00', '{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}', '{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\",\"spfeatured_image\":\"\",\"post_format\":\"standard\",\"gallery\":\"\",\"audio\":\"\",\"video\":\"\",\"link_title\":\"\",\"link_url\":\"\",\"quote_text\":\"\",\"quote_author\":\"\",\"post_status\":\"\"}', '1', '1', '', '', '1', '2', '{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}', '0', '*', ''),
('5', '71', 'Color Variation', 'color-variation', '', '', '2', '8', '2016-11-12 06:46:21', '602', '', '2016-11-12 06:46:21', '0', '0', '0000-00-00 00:00:00', '2016-11-12 06:46:21', '0000-00-00 00:00:00', '{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}', '{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\",\"spfeatured_image\":\"\",\"post_format\":\"standard\",\"gallery\":\"\",\"audio\":\"\",\"video\":\"\",\"link_title\":\"\",\"link_url\":\"\",\"quote_text\":\"\",\"quote_author\":\"\",\"post_status\":\"\"}', '1', '0', '', '', '1', '0', '{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}', '0', '*', ''),
('6', '78', 'Color Variation', 'color-variation-2', '', '', '-2', '8', '2016-11-12 07:04:04', '602', '', '2016-11-12 07:04:33', '602', '0', '0000-00-00 00:00:00', '2016-11-12 07:04:04', '0000-00-00 00:00:00', '{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}', '{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\",\"spfeatured_image\":\"\",\"post_format\":\"standard\",\"gallery\":\"\",\"audio\":\"\",\"video\":\"\",\"link_title\":\"\",\"link_url\":\"\",\"quote_text\":\"\",\"quote_author\":\"\",\"post_status\":\"\"}', '2', '0', '', '', '1', '1', '{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}', '0', '*', ''),
('7', '87', 'Home', 'home', '', '', '-2', '2', '2016-11-14 14:57:40', '602', '', '2016-11-14 14:57:40', '0', '0', '0000-00-00 00:00:00', '2016-11-14 14:57:40', '0000-00-00 00:00:00', '{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}', '{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\",\"spfeatured_image\":\"\",\"post_format\":\"standard\",\"gallery\":\"\",\"audio\":\"\",\"video\":\"\",\"link_title\":\"\",\"link_url\":\"\",\"quote_text\":\"\",\"quote_author\":\"\",\"post_status\":\"\"}', '1', '0', '', '', '1', '0', '{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}', '0', '*', '');

DROP TABLE IF EXISTS `lal5d_content_frontpage`;
CREATE TABLE `lal5d_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_content_rating`;
CREATE TABLE `lal5d_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_content_types`;
CREATE TABLE `lal5d_content_types` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type_alias` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `rules` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_mappings` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `router` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content_history_options` varchar(5120) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'JSON string for com_contenthistory options',
  PRIMARY KEY (`type_id`),
  KEY `idx_alias` (`type_alias`(100))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_content_types
(`type_id`, `type_title`, `type_alias`, `table`, `rules`, `field_mappings`, `router`, `content_history_options`) VALUES 
('1', 'Article', 'com_content.article', '{\"special\":{\"dbtable\":\"#__content\",\"key\":\"id\",\"type\":\"Content\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"state\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"introtext\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"attribs\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"urls\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"asset_id\"}, \"special\":{\"fulltext\":\"fulltext\"}}', 'ContentHelperRoute::getArticleRoute', '{\"formFile\":\"administrator\\/components\\/com_content\\/models\\/forms\\/article.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),
('2', 'Contact', 'com_contact.contact', '{\"special\":{\"dbtable\":\"#__contact_details\",\"key\":\"id\",\"type\":\"Contact\",\"prefix\":\"ContactTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"address\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"image\", \"core_urls\":\"webpage\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"null\"}, \"special\":{\"con_position\":\"con_position\",\"suburb\":\"suburb\",\"state\":\"state\",\"country\":\"country\",\"postcode\":\"postcode\",\"telephone\":\"telephone\",\"fax\":\"fax\",\"misc\":\"misc\",\"email_to\":\"email_to\",\"default_con\":\"default_con\",\"user_id\":\"user_id\",\"mobile\":\"mobile\",\"sortname1\":\"sortname1\",\"sortname2\":\"sortname2\",\"sortname3\":\"sortname3\"}}', 'ContactHelperRoute::getContactRoute', '{\"formFile\":\"administrator\\/components\\/com_contact\\/models\\/forms\\/contact.xml\",\"hideFields\":[\"default_con\",\"checked_out\",\"checked_out_time\",\"version\",\"xreference\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"], \"displayLookup\":[ {\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ] }'),
('3', 'Newsfeed', 'com_newsfeeds.newsfeed', '{\"special\":{\"dbtable\":\"#__newsfeeds\",\"key\":\"id\",\"type\":\"Newsfeed\",\"prefix\":\"NewsfeedsTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"link\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"null\"}, \"special\":{\"numarticles\":\"numarticles\",\"cache_time\":\"cache_time\",\"rtl\":\"rtl\"}}', 'NewsfeedsHelperRoute::getNewsfeedRoute', '{\"formFile\":\"administrator\\/components\\/com_newsfeeds\\/models\\/forms\\/newsfeed.xml\",\"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),
('4', 'User', 'com_users.user', '{\"special\":{\"dbtable\":\"#__users\",\"key\":\"id\",\"type\":\"User\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"null\",\"core_alias\":\"username\",\"core_created_time\":\"registerdate\",\"core_modified_time\":\"lastvisitDate\",\"core_body\":\"null\", \"core_hits\":\"null\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"access\":\"null\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"null\", \"core_language\":\"null\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"null\", \"core_ordering\":\"null\", \"core_metakey\":\"null\", \"core_metadesc\":\"null\", \"core_catid\":\"null\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\":{}}', 'UsersHelperRoute::getUserRoute', ''),
('5', 'Article Category', 'com_content.category', '{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}', 'ContentHelperRoute::getCategoryRoute', '{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),
('6', 'Contact Category', 'com_contact.category', '{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}', 'ContactHelperRoute::getCategoryRoute', '{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),
('7', 'Newsfeeds Category', 'com_newsfeeds.category', '{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}', 'NewsfeedsHelperRoute::getCategoryRoute', '{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),
('8', 'Tag', 'com_tags.tag', '{\"special\":{\"dbtable\":\"#__tags\",\"key\":\"tag_id\",\"type\":\"Tag\",\"prefix\":\"TagsTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"urls\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"null\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\"}}', 'TagsHelperRoute::getTagRoute', '{\"formFile\":\"administrator\\/components\\/com_tags\\/models\\/forms\\/tag.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\", \"lft\", \"rgt\", \"level\", \"path\", \"urls\", \"publish_up\", \"publish_down\"],\"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}]}'),
('9', 'Banner', 'com_banners.banner', '{\"special\":{\"dbtable\":\"#__banners\",\"key\":\"id\",\"type\":\"Banner\",\"prefix\":\"BannersTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"description\", \"core_hits\":\"null\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"link\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\":{\"imptotal\":\"imptotal\", \"impmade\":\"impmade\", \"clicks\":\"clicks\", \"clickurl\":\"clickurl\", \"custombannercode\":\"custombannercode\", \"cid\":\"cid\", \"purchase_type\":\"purchase_type\", \"track_impressions\":\"track_impressions\", \"track_clicks\":\"track_clicks\"}}', '', '{\"formFile\":\"administrator\\/components\\/com_banners\\/models\\/forms\\/banner.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\", \"reset\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"imptotal\", \"impmade\", \"reset\"], \"convertToInt\":[\"publish_up\", \"publish_down\", \"ordering\"], \"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"cid\",\"targetTable\":\"#__banner_clients\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),
('10', 'Banners Category', 'com_banners.category', '{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\": {\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}', '', '{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"], \"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),
('11', 'Banner Client', 'com_banners.client', '{\"special\":{\"dbtable\":\"#__banner_clients\",\"key\":\"id\",\"type\":\"Client\",\"prefix\":\"BannersTable\"}}', '', '', '', '{\"formFile\":\"administrator\\/components\\/com_banners\\/models\\/forms\\/client.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\"], \"ignoreChanges\":[\"checked_out\", \"checked_out_time\"], \"convertToInt\":[], \"displayLookup\":[]}'),
('12', 'User Notes', 'com_users.note', '{\"special\":{\"dbtable\":\"#__user_notes\",\"key\":\"id\",\"type\":\"Note\",\"prefix\":\"UsersTable\"}}', '', '', '', '{\"formFile\":\"administrator\\/components\\/com_users\\/models\\/forms\\/note.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\", \"publish_up\", \"publish_down\"],\"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\"], \"convertToInt\":[\"publish_up\", \"publish_down\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}]}'),
('13', 'User Notes Category', 'com_users.category', '{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}', '', '{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}', '', '{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"], \"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}');

DROP TABLE IF EXISTS `lal5d_contentitem_tag_map`;
CREATE TABLE `lal5d_contentitem_tag_map` (
  `type_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_content_id` int(10) unsigned NOT NULL COMMENT 'PK from the core content table',
  `content_item_id` int(11) NOT NULL COMMENT 'PK from the content type table',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'PK from the tag table',
  `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date of most recent save for this tag-item',
  `type_id` mediumint(8) NOT NULL COMMENT 'PK from the content_type table',
  UNIQUE KEY `uc_ItemnameTagid` (`type_id`,`content_item_id`,`tag_id`),
  KEY `idx_tag_type` (`tag_id`,`type_id`),
  KEY `idx_date_id` (`tag_date`,`tag_id`),
  KEY `idx_core_content_id` (`core_content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Maps items from content tables to tags';

DROP TABLE IF EXISTS `lal5d_core_log_searches`;
CREATE TABLE `lal5d_core_log_searches` (
  `search_term` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_extensions`;
CREATE TABLE `lal5d_extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `folder` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `system_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10092 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_extensions
(`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES 
('1', 'com_mailto', 'component', 'com_mailto', '', '0', '1', '1', '1', '{\"name\":\"com_mailto\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MAILTO_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mailto\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('2', 'com_wrapper', 'component', 'com_wrapper', '', '0', '1', '1', '1', '{\"name\":\"com_wrapper\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_WRAPPER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"wrapper\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('3', 'com_admin', 'component', 'com_admin', '', '1', '1', '1', '1', '{\"name\":\"com_admin\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_ADMIN_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('4', 'com_banners', 'component', 'com_banners', '', '1', '1', '1', '0', '{\"name\":\"com_banners\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_BANNERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"banners\"}', '{\"purchase_type\":\"3\",\"track_impressions\":\"0\",\"track_clicks\":\"0\",\"metakey_prefix\":\"\",\"save_history\":\"1\",\"history_limit\":10}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('5', 'com_cache', 'component', 'com_cache', '', '1', '1', '1', '1', '{\"name\":\"com_cache\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CACHE_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('6', 'com_categories', 'component', 'com_categories', '', '1', '1', '1', '1', '{\"name\":\"com_categories\",\"type\":\"component\",\"creationDate\":\"December 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('7', 'com_checkin', 'component', 'com_checkin', '', '1', '1', '1', '1', '{\"name\":\"com_checkin\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CHECKIN_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('8', 'com_contact', 'component', 'com_contact', '', '1', '1', '1', '0', '{\"name\":\"com_contact\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONTACT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contact\"}', '{\"show_contact_category\":\"hide\",\"save_history\":\"1\",\"history_limit\":10,\"show_contact_list\":\"0\",\"presentation_style\":\"sliders\",\"show_name\":\"1\",\"show_position\":\"1\",\"show_email\":\"0\",\"show_street_address\":\"1\",\"show_suburb\":\"1\",\"show_state\":\"1\",\"show_postcode\":\"1\",\"show_country\":\"1\",\"show_telephone\":\"1\",\"show_mobile\":\"1\",\"show_fax\":\"1\",\"show_webpage\":\"1\",\"show_misc\":\"1\",\"show_image\":\"1\",\"image\":\"\",\"allow_vcard\":\"0\",\"show_articles\":\"0\",\"show_profile\":\"0\",\"show_links\":\"0\",\"linka_name\":\"\",\"linkb_name\":\"\",\"linkc_name\":\"\",\"linkd_name\":\"\",\"linke_name\":\"\",\"contact_icons\":\"0\",\"icon_address\":\"\",\"icon_email\":\"\",\"icon_telephone\":\"\",\"icon_mobile\":\"\",\"icon_fax\":\"\",\"icon_misc\":\"\",\"show_headings\":\"1\",\"show_position_headings\":\"1\",\"show_email_headings\":\"0\",\"show_telephone_headings\":\"1\",\"show_mobile_headings\":\"0\",\"show_fax_headings\":\"0\",\"allow_vcard_headings\":\"0\",\"show_suburb_headings\":\"1\",\"show_state_headings\":\"1\",\"show_country_headings\":\"1\",\"show_email_form\":\"1\",\"show_email_copy\":\"1\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"1\",\"custom_reply\":\"0\",\"redirect\":\"\",\"show_category_crumb\":\"0\",\"metakey\":\"\",\"metadesc\":\"\",\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('9', 'com_cpanel', 'component', 'com_cpanel', '', '1', '1', '1', '1', '{\"name\":\"com_cpanel\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CPANEL_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10', 'com_installer', 'component', 'com_installer', '', '1', '1', '1', '1', '{\"name\":\"com_installer\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_INSTALLER_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('11', 'com_languages', 'component', 'com_languages', '', '1', '1', '1', '1', '{\"name\":\"com_languages\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\"}', '{\"administrator\":\"en-GB\",\"site\":\"en-GB\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('12', 'com_login', 'component', 'com_login', '', '1', '1', '1', '1', '{\"name\":\"com_login\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_LOGIN_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('13', 'com_media', 'component', 'com_media', '', '1', '1', '0', '1', '{\"name\":\"com_media\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MEDIA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"media\"}', '{\"upload_extensions\":\"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\",\"upload_maxsize\":\"10\",\"file_path\":\"images\",\"image_path\":\"images\",\"restrict_uploads\":\"1\",\"allowed_media_usergroup\":\"3\",\"check_mime\":\"1\",\"image_extensions\":\"bmp,gif,jpg,png\",\"ignore_extensions\":\"\",\"upload_mime\":\"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip\",\"upload_mime_illegal\":\"text\\/html\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('14', 'com_menus', 'component', 'com_menus', '', '1', '1', '1', '1', '{\"name\":\"com_menus\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MENUS_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('15', 'com_messages', 'component', 'com_messages', '', '1', '1', '1', '1', '{\"name\":\"com_messages\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MESSAGES_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('16', 'com_modules', 'component', 'com_modules', '', '1', '1', '1', '1', '{\"name\":\"com_modules\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MODULES_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('17', 'com_newsfeeds', 'component', 'com_newsfeeds', '', '1', '1', '1', '0', '{\"name\":\"com_newsfeeds\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}', '{\"newsfeed_layout\":\"_:default\",\"save_history\":\"1\",\"history_limit\":5,\"show_feed_image\":\"1\",\"show_feed_description\":\"1\",\"show_item_description\":\"1\",\"feed_character_count\":\"0\",\"feed_display_order\":\"des\",\"float_first\":\"right\",\"float_second\":\"right\",\"show_tags\":\"1\",\"category_layout\":\"_:default\",\"show_category_title\":\"1\",\"show_description\":\"1\",\"show_description_image\":\"1\",\"maxLevel\":\"-1\",\"show_empty_categories\":\"0\",\"show_subcat_desc\":\"1\",\"show_cat_items\":\"1\",\"show_cat_tags\":\"1\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_items_cat\":\"1\",\"filter_field\":\"1\",\"show_pagination_limit\":\"1\",\"show_headings\":\"1\",\"show_articles\":\"0\",\"show_link\":\"1\",\"show_pagination\":\"1\",\"show_pagination_results\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('18', 'com_plugins', 'component', 'com_plugins', '', '1', '1', '1', '1', '{\"name\":\"com_plugins\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_PLUGINS_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('19', 'com_search', 'component', 'com_search', '', '1', '1', '1', '0', '{\"name\":\"com_search\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_SEARCH_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"search\"}', '{\"enabled\":\"0\",\"show_date\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('20', 'com_templates', 'component', 'com_templates', '', '1', '1', '1', '1', '{\"name\":\"com_templates\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_TEMPLATES_XML_DESCRIPTION\",\"group\":\"\"}', '{\"template_positions_display\":\"1\",\"upload_limit\":\"10\",\"image_formats\":\"gif,bmp,jpg,jpeg,png\",\"source_formats\":\"txt,less,ini,xml,js,php,css\",\"font_formats\":\"woff,ttf,otf\",\"compressed_formats\":\"zip\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('22', 'com_content', 'component', 'com_content', '', '1', '1', '0', '1', '{\"name\":\"com_content\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}', '{\"article_layout\":\"_:default\",\"show_title\":\"1\",\"link_titles\":\"1\",\"show_intro\":\"1\",\"show_category\":\"1\",\"link_category\":\"1\",\"show_parent_category\":\"0\",\"link_parent_category\":\"0\",\"show_author\":\"1\",\"link_author\":\"0\",\"show_create_date\":\"0\",\"show_modify_date\":\"0\",\"show_publish_date\":\"1\",\"show_item_navigation\":\"1\",\"show_vote\":\"0\",\"show_readmore\":\"1\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"100\",\"show_icons\":\"1\",\"show_print_icon\":\"1\",\"show_email_icon\":\"1\",\"show_hits\":\"1\",\"show_noauth\":\"0\",\"show_publishing_options\":\"1\",\"show_article_options\":\"1\",\"save_history\":\"1\",\"history_limit\":10,\"show_urls_images_frontend\":\"0\",\"show_urls_images_backend\":\"1\",\"targeta\":0,\"targetb\":0,\"targetc\":0,\"float_intro\":\"left\",\"float_fulltext\":\"left\",\"category_layout\":\"_:blog\",\"show_category_title\":\"0\",\"show_description\":\"0\",\"show_description_image\":\"0\",\"maxLevel\":\"1\",\"show_empty_categories\":\"0\",\"show_no_articles\":\"1\",\"show_subcat_desc\":\"1\",\"show_cat_num_articles\":\"0\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_num_articles_cat\":\"1\",\"num_leading_articles\":\"1\",\"num_intro_articles\":\"4\",\"num_columns\":\"2\",\"num_links\":\"4\",\"multi_column_order\":\"0\",\"show_subcategory_content\":\"0\",\"show_pagination_limit\":\"1\",\"filter_field\":\"hide\",\"show_headings\":\"1\",\"list_show_date\":\"0\",\"date_format\":\"\",\"list_show_hits\":\"1\",\"list_show_author\":\"1\",\"orderby_pri\":\"order\",\"orderby_sec\":\"rdate\",\"order_date\":\"published\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_feed_link\":\"1\",\"feed_summary\":\"0\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('23', 'com_config', 'component', 'com_config', '', '1', '1', '0', '1', '{\"name\":\"com_config\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONFIG_XML_DESCRIPTION\",\"group\":\"\"}', '{\"filters\":{\"1\":{\"filter_type\":\"NH\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"6\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"7\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"2\":{\"filter_type\":\"NH\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"3\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"4\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"5\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"10\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"12\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"8\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"}}}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('24', 'com_redirect', 'component', 'com_redirect', '', '1', '1', '0', '1', '{\"name\":\"com_redirect\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_REDIRECT_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('25', 'com_users', 'component', 'com_users', '', '1', '1', '0', '1', '{\"name\":\"com_users\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_USERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"users\"}', '{\"allowUserRegistration\":\"0\",\"new_usertype\":\"2\",\"guest_usergroup\":\"9\",\"sendpassword\":\"1\",\"useractivation\":\"1\",\"mail_to_admin\":\"0\",\"captcha\":\"\",\"frontend_userparams\":\"1\",\"site_language\":\"0\",\"change_login_name\":\"0\",\"reset_count\":\"10\",\"reset_time\":\"1\",\"minimum_length\":\"4\",\"minimum_integers\":\"0\",\"minimum_symbols\":\"0\",\"minimum_uppercase\":\"0\",\"save_history\":\"1\",\"history_limit\":5,\"mailSubjectPrefix\":\"\",\"mailBodySuffix\":\"\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('27', 'com_finder', 'component', 'com_finder', '', '1', '1', '0', '0', '{\"name\":\"com_finder\",\"type\":\"component\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"finder\"}', '{\"show_description\":\"1\",\"description_length\":255,\"allow_empty_query\":\"0\",\"show_url\":\"1\",\"show_advanced\":\"1\",\"expand_advanced\":\"0\",\"show_date_filters\":\"0\",\"highlight_terms\":\"1\",\"opensearch_name\":\"\",\"opensearch_description\":\"\",\"batch_size\":\"50\",\"memory_table_limit\":30000,\"title_multiplier\":\"1.7\",\"text_multiplier\":\"0.7\",\"meta_multiplier\":\"1.2\",\"path_multiplier\":\"2.0\",\"misc_multiplier\":\"0.3\",\"stemmer\":\"snowball\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('28', 'com_joomlaupdate', 'component', 'com_joomlaupdate', '', '1', '1', '0', '1', '{\"name\":\"com_joomlaupdate\",\"type\":\"component\",\"creationDate\":\"February 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.2\",\"description\":\"COM_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('29', 'com_tags', 'component', 'com_tags', '', '1', '1', '1', '1', '{\"name\":\"com_tags\",\"type\":\"component\",\"creationDate\":\"December 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"COM_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}', '{\"tag_layout\":\"_:default\",\"save_history\":\"1\",\"history_limit\":5,\"show_tag_title\":\"0\",\"tag_list_show_tag_image\":\"0\",\"tag_list_show_tag_description\":\"0\",\"tag_list_image\":\"\",\"show_tag_num_items\":\"0\",\"tag_list_orderby\":\"title\",\"tag_list_orderby_direction\":\"ASC\",\"show_headings\":\"0\",\"tag_list_show_date\":\"0\",\"tag_list_show_item_image\":\"0\",\"tag_list_show_item_description\":\"0\",\"tag_list_item_maximum_characters\":0,\"return_any_or_all\":\"1\",\"include_children\":\"0\",\"maximum\":200,\"tag_list_language_filter\":\"all\",\"tags_layout\":\"_:default\",\"all_tags_orderby\":\"title\",\"all_tags_orderby_direction\":\"ASC\",\"all_tags_show_tag_image\":\"0\",\"all_tags_show_tag_descripion\":\"0\",\"all_tags_tag_maximum_characters\":20,\"all_tags_show_tag_hits\":\"0\",\"filter_field\":\"1\",\"show_pagination_limit\":\"1\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"tag_field_ajax_mode\":\"1\",\"show_feed_link\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('30', 'com_contenthistory', 'component', 'com_contenthistory', '', '1', '1', '1', '0', '{\"name\":\"com_contenthistory\",\"type\":\"component\",\"creationDate\":\"May 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_CONTENTHISTORY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contenthistory\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('31', 'com_ajax', 'component', 'com_ajax', '', '1', '1', '1', '1', '{\"name\":\"com_ajax\",\"type\":\"component\",\"creationDate\":\"August 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_AJAX_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"ajax\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('32', 'com_postinstall', 'component', 'com_postinstall', '', '1', '1', '1', '1', '{\"name\":\"com_postinstall\",\"type\":\"component\",\"creationDate\":\"September 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_POSTINSTALL_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('102', 'LIB_PHPUTF8', 'library', 'phputf8', '', '0', '1', '1', '1', '{\"name\":\"LIB_PHPUTF8\",\"type\":\"library\",\"creationDate\":\"2006\",\"author\":\"Harry Fuecks\",\"copyright\":\"Copyright various authors\",\"authorEmail\":\"hfuecks@gmail.com\",\"authorUrl\":\"http:\\/\\/sourceforge.net\\/projects\\/phputf8\",\"version\":\"0.5\",\"description\":\"LIB_PHPUTF8_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"phputf8\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('103', 'LIB_JOOMLA', 'library', 'joomla', '', '0', '1', '1', '1', '{\"name\":\"LIB_JOOMLA\",\"type\":\"library\",\"creationDate\":\"2008\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"https:\\/\\/www.joomla.org\",\"version\":\"13.1\",\"description\":\"LIB_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}', '{\"mediaversion\":\"45df9c7e2e7f66261d85ad785954215e\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('104', 'LIB_IDNA', 'library', 'idna_convert', '', '0', '1', '1', '1', '{\"name\":\"LIB_IDNA\",\"type\":\"library\",\"creationDate\":\"2004\",\"author\":\"phlyLabs\",\"copyright\":\"2004-2011 phlyLabs Berlin, http:\\/\\/phlylabs.de\",\"authorEmail\":\"phlymail@phlylabs.de\",\"authorUrl\":\"http:\\/\\/phlylabs.de\",\"version\":\"0.8.0\",\"description\":\"LIB_IDNA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"idna_convert\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('105', 'FOF', 'library', 'fof', '', '0', '1', '1', '1', '{\"name\":\"FOF\",\"type\":\"library\",\"creationDate\":\"2015-04-22 13:15:32\",\"author\":\"Nicholas K. Dionysopoulos \\/ Akeeba Ltd\",\"copyright\":\"(C)2011-2015 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@akeebabackup.com\",\"authorUrl\":\"https:\\/\\/www.akeebabackup.com\",\"version\":\"2.4.3\",\"description\":\"LIB_FOF_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"fof\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('106', 'LIB_PHPASS', 'library', 'phpass', '', '0', '1', '1', '1', '{\"name\":\"LIB_PHPASS\",\"type\":\"library\",\"creationDate\":\"2004-2006\",\"author\":\"Solar Designer\",\"copyright\":\"\",\"authorEmail\":\"solar@openwall.com\",\"authorUrl\":\"http:\\/\\/www.openwall.com\\/phpass\\/\",\"version\":\"0.3\",\"description\":\"LIB_PHPASS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"phpass\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('200', 'mod_articles_archive', 'module', 'mod_articles_archive', '', '0', '1', '1', '0', '{\"name\":\"mod_articles_archive\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_archive\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('201', 'mod_articles_latest', 'module', 'mod_articles_latest', '', '0', '1', '1', '0', '{\"name\":\"mod_articles_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LATEST_NEWS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_latest\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('202', 'mod_articles_popular', 'module', 'mod_articles_popular', '', '0', '1', '1', '0', '{\"name\":\"mod_articles_popular\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_popular\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('203', 'mod_banners', 'module', 'mod_banners', '', '0', '1', '1', '0', '{\"name\":\"mod_banners\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_BANNERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_banners\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('204', 'mod_breadcrumbs', 'module', 'mod_breadcrumbs', '', '0', '1', '1', '1', '{\"name\":\"mod_breadcrumbs\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_BREADCRUMBS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_breadcrumbs\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('205', 'mod_custom', 'module', 'mod_custom', '', '0', '1', '1', '1', '{\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_custom\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('206', 'mod_feed', 'module', 'mod_feed', '', '0', '1', '1', '0', '{\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_feed\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('207', 'mod_footer', 'module', 'mod_footer', '', '0', '1', '1', '0', '{\"name\":\"mod_footer\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FOOTER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_footer\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('208', 'mod_login', 'module', 'mod_login', '', '0', '1', '1', '1', '{\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_login\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('209', 'mod_menu', 'module', 'mod_menu', '', '0', '1', '1', '1', '{\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_menu\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('210', 'mod_articles_news', 'module', 'mod_articles_news', '', '0', '1', '1', '0', '{\"name\":\"mod_articles_news\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_NEWS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_news\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('211', 'mod_random_image', 'module', 'mod_random_image', '', '0', '1', '1', '0', '{\"name\":\"mod_random_image\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_RANDOM_IMAGE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_random_image\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('212', 'mod_related_items', 'module', 'mod_related_items', '', '0', '1', '1', '0', '{\"name\":\"mod_related_items\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_RELATED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_related_items\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('213', 'mod_search', 'module', 'mod_search', '', '0', '1', '1', '0', '{\"name\":\"mod_search\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SEARCH_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_search\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('214', 'mod_stats', 'module', 'mod_stats', '', '0', '1', '1', '0', '{\"name\":\"mod_stats\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_stats\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0');

INSERT INTO lal5d_extensions
(`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES 
('215', 'mod_syndicate', 'module', 'mod_syndicate', '', '0', '1', '1', '1', '{\"name\":\"mod_syndicate\",\"type\":\"module\",\"creationDate\":\"May 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SYNDICATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_syndicate\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('216', 'mod_users_latest', 'module', 'mod_users_latest', '', '0', '1', '1', '0', '{\"name\":\"mod_users_latest\",\"type\":\"module\",\"creationDate\":\"December 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_USERS_LATEST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_users_latest\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('218', 'mod_whosonline', 'module', 'mod_whosonline', '', '0', '1', '1', '0', '{\"name\":\"mod_whosonline\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WHOSONLINE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_whosonline\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('219', 'mod_wrapper', 'module', 'mod_wrapper', '', '0', '1', '1', '0', '{\"name\":\"mod_wrapper\",\"type\":\"module\",\"creationDate\":\"October 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WRAPPER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_wrapper\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('220', 'mod_articles_category', 'module', 'mod_articles_category', '', '0', '1', '1', '0', '{\"name\":\"mod_articles_category\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_category\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('221', 'mod_articles_categories', 'module', 'mod_articles_categories', '', '0', '1', '1', '0', '{\"name\":\"mod_articles_categories\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_categories\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('222', 'mod_languages', 'module', 'mod_languages', '', '0', '1', '1', '1', '{\"name\":\"mod_languages\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"MOD_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_languages\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('223', 'mod_finder', 'module', 'mod_finder', '', '0', '1', '0', '0', '{\"name\":\"mod_finder\",\"type\":\"module\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_finder\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('300', 'mod_custom', 'module', 'mod_custom', '', '1', '1', '1', '1', '{\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_custom\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('301', 'mod_feed', 'module', 'mod_feed', '', '1', '1', '1', '0', '{\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_feed\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('302', 'mod_latest', 'module', 'mod_latest', '', '1', '1', '1', '0', '{\"name\":\"mod_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LATEST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_latest\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('303', 'mod_logged', 'module', 'mod_logged', '', '1', '1', '1', '0', '{\"name\":\"mod_logged\",\"type\":\"module\",\"creationDate\":\"January 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGGED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_logged\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('304', 'mod_login', 'module', 'mod_login', '', '1', '1', '1', '1', '{\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"March 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_login\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('305', 'mod_menu', 'module', 'mod_menu', '', '1', '1', '1', '0', '{\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"March 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_menu\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('307', 'mod_popular', 'module', 'mod_popular', '', '1', '1', '1', '0', '{\"name\":\"mod_popular\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_popular\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('308', 'mod_quickicon', 'module', 'mod_quickicon', '', '1', '1', '1', '1', '{\"name\":\"mod_quickicon\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_QUICKICON_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_quickicon\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('309', 'mod_status', 'module', 'mod_status', '', '1', '1', '1', '0', '{\"name\":\"mod_status\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATUS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_status\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('310', 'mod_submenu', 'module', 'mod_submenu', '', '1', '1', '1', '0', '{\"name\":\"mod_submenu\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SUBMENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_submenu\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('311', 'mod_title', 'module', 'mod_title', '', '1', '1', '1', '0', '{\"name\":\"mod_title\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_TITLE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_title\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('312', 'mod_toolbar', 'module', 'mod_toolbar', '', '1', '1', '1', '1', '{\"name\":\"mod_toolbar\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_TOOLBAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_toolbar\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('313', 'mod_multilangstatus', 'module', 'mod_multilangstatus', '', '1', '1', '1', '0', '{\"name\":\"mod_multilangstatus\",\"type\":\"module\",\"creationDate\":\"September 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MULTILANGSTATUS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_multilangstatus\"}', '{\"cache\":\"0\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('314', 'mod_version', 'module', 'mod_version', '', '1', '1', '1', '0', '{\"name\":\"mod_version\",\"type\":\"module\",\"creationDate\":\"January 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_VERSION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_version\"}', '{\"format\":\"short\",\"product\":\"1\",\"cache\":\"0\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('315', 'mod_stats_admin', 'module', 'mod_stats_admin', '', '1', '1', '1', '0', '{\"name\":\"mod_stats_admin\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_stats_admin\"}', '{\"serverinfo\":\"0\",\"siteinfo\":\"0\",\"counter\":\"0\",\"increase\":\"0\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('316', 'mod_tags_popular', 'module', 'mod_tags_popular', '', '0', '1', '1', '0', '{\"name\":\"mod_tags_popular\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"MOD_TAGS_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_tags_popular\"}', '{\"maximum\":\"5\",\"timeframe\":\"alltime\",\"owncache\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('317', 'mod_tags_similar', 'module', 'mod_tags_similar', '', '0', '1', '1', '0', '{\"name\":\"mod_tags_similar\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"MOD_TAGS_SIMILAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_tags_similar\"}', '{\"maximum\":\"5\",\"matchtype\":\"any\",\"owncache\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('400', 'plg_authentication_gmail', 'plugin', 'gmail', 'authentication', '0', '1', '1', '0', '{\"name\":\"plg_authentication_gmail\",\"type\":\"plugin\",\"creationDate\":\"February 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_GMAIL_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"gmail\"}', '{\"applysuffix\":\"0\",\"suffix\":\"\",\"verifypeer\":\"1\",\"user_blacklist\":\"\"}', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('401', 'plg_authentication_joomla', 'plugin', 'joomla', 'authentication', '0', '1', '1', '1', '{\"name\":\"plg_authentication_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_AUTH_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('402', 'plg_authentication_ldap', 'plugin', 'ldap', 'authentication', '0', '0', '1', '0', '{\"name\":\"plg_authentication_ldap\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LDAP_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"ldap\"}', '{\"host\":\"\",\"port\":\"389\",\"use_ldapV3\":\"0\",\"negotiate_tls\":\"0\",\"no_referrals\":\"0\",\"auth_method\":\"bind\",\"base_dn\":\"\",\"search_string\":\"\",\"users_dn\":\"\",\"username\":\"admin\",\"password\":\"bobby7\",\"ldap_fullname\":\"fullName\",\"ldap_email\":\"mail\",\"ldap_uid\":\"uid\"}', '', '', '0', '0000-00-00 00:00:00', '3', '0'),
('403', 'plg_content_contact', 'plugin', 'contact', 'content', '0', '1', '1', '0', '{\"name\":\"plg_content_contact\",\"type\":\"plugin\",\"creationDate\":\"January 2014\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.2\",\"description\":\"PLG_CONTENT_CONTACT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contact\"}', '', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('404', 'plg_content_emailcloak', 'plugin', 'emailcloak', 'content', '0', '1', '1', '0', '{\"name\":\"plg_content_emailcloak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"emailcloak\"}', '{\"mode\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('406', 'plg_content_loadmodule', 'plugin', 'loadmodule', 'content', '0', '1', '1', '0', '{\"name\":\"plg_content_loadmodule\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LOADMODULE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"loadmodule\"}', '{\"style\":\"xhtml\"}', '', '', '0', '2011-09-18 15:22:50', '0', '0'),
('407', 'plg_content_pagebreak', 'plugin', 'pagebreak', 'content', '0', '1', '1', '0', '{\"name\":\"plg_content_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagebreak\"}', '{\"title\":\"1\",\"multipage_toc\":\"1\",\"showall\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '4', '0'),
('408', 'plg_content_pagenavigation', 'plugin', 'pagenavigation', 'content', '0', '1', '1', '0', '{\"name\":\"plg_content_pagenavigation\",\"type\":\"plugin\",\"creationDate\":\"January 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_PAGENAVIGATION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagenavigation\"}', '{\"position\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '5', '0'),
('409', 'plg_content_vote', 'plugin', 'vote', 'content', '0', '1', '1', '0', '{\"name\":\"plg_content_vote\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_VOTE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"vote\"}', '', '', '', '0', '0000-00-00 00:00:00', '6', '0'),
('410', 'plg_editors_codemirror', 'plugin', 'codemirror', 'editors', '0', '1', '1', '1', '{\"name\":\"plg_editors_codemirror\",\"type\":\"plugin\",\"creationDate\":\"28 March 2011\",\"author\":\"Marijn Haverbeke\",\"copyright\":\"Copyright (C) 2014 by Marijn Haverbeke <marijnh@gmail.com> and others\",\"authorEmail\":\"marijnh@gmail.com\",\"authorUrl\":\"http:\\/\\/codemirror.net\\/\",\"version\":\"5.18.0\",\"description\":\"PLG_CODEMIRROR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"codemirror\"}', '{\"lineNumbers\":\"1\",\"lineWrapping\":\"1\",\"matchTags\":\"1\",\"matchBrackets\":\"1\",\"marker-gutter\":\"1\",\"autoCloseTags\":\"1\",\"autoCloseBrackets\":\"1\",\"autoFocus\":\"1\",\"theme\":\"default\",\"tabmode\":\"indent\"}', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('411', 'plg_editors_none', 'plugin', 'none', 'editors', '0', '1', '1', '1', '{\"name\":\"plg_editors_none\",\"type\":\"plugin\",\"creationDate\":\"September 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_NONE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"none\"}', '', '', '', '0', '0000-00-00 00:00:00', '2', '0'),
('412', 'plg_editors_tinymce', 'plugin', 'tinymce', 'editors', '0', '1', '1', '0', '{\"name\":\"plg_editors_tinymce\",\"type\":\"plugin\",\"creationDate\":\"2005-2016\",\"author\":\"Ephox Corporation\",\"copyright\":\"Ephox Corporation\",\"authorEmail\":\"N\\/A\",\"authorUrl\":\"http:\\/\\/www.tinymce.com\",\"version\":\"4.4.3\",\"description\":\"PLG_TINY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tinymce\"}', '{\"mode\":\"1\",\"skin\":\"0\",\"mobile\":\"0\",\"entity_encoding\":\"raw\",\"lang_mode\":\"1\",\"text_direction\":\"ltr\",\"content_css\":\"1\",\"content_css_custom\":\"\",\"relative_urls\":\"1\",\"newlines\":\"0\",\"invalid_elements\":\"script,applet,iframe\",\"extended_elements\":\"\",\"html_height\":\"550\",\"html_width\":\"750\",\"resizing\":\"1\",\"element_path\":\"1\",\"fonts\":\"1\",\"paste\":\"1\",\"searchreplace\":\"1\",\"insertdate\":\"1\",\"colors\":\"1\",\"table\":\"1\",\"smilies\":\"1\",\"hr\":\"1\",\"link\":\"1\",\"media\":\"1\",\"print\":\"1\",\"directionality\":\"1\",\"fullscreen\":\"1\",\"alignment\":\"1\",\"visualchars\":\"1\",\"visualblocks\":\"1\",\"nonbreaking\":\"1\",\"template\":\"1\",\"blockquote\":\"1\",\"wordcount\":\"1\",\"advlist\":\"1\",\"autosave\":\"1\",\"contextmenu\":\"1\",\"inlinepopups\":\"1\",\"custom_plugin\":\"\",\"custom_button\":\"\"}', '', '', '0', '0000-00-00 00:00:00', '3', '0'),
('413', 'plg_editors-xtd_article', 'plugin', 'article', 'editors-xtd', '0', '1', '1', '0', '{\"name\":\"plg_editors-xtd_article\",\"type\":\"plugin\",\"creationDate\":\"October 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_ARTICLE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"article\"}', '', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('414', 'plg_editors-xtd_image', 'plugin', 'image', 'editors-xtd', '0', '1', '1', '0', '{\"name\":\"plg_editors-xtd_image\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_IMAGE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"image\"}', '', '', '', '0', '0000-00-00 00:00:00', '2', '0'),
('415', 'plg_editors-xtd_pagebreak', 'plugin', 'pagebreak', 'editors-xtd', '0', '1', '1', '0', '{\"name\":\"plg_editors-xtd_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagebreak\"}', '', '', '', '0', '0000-00-00 00:00:00', '3', '0'),
('416', 'plg_editors-xtd_readmore', 'plugin', 'readmore', 'editors-xtd', '0', '1', '1', '0', '{\"name\":\"plg_editors-xtd_readmore\",\"type\":\"plugin\",\"creationDate\":\"March 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_READMORE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"readmore\"}', '', '', '', '0', '0000-00-00 00:00:00', '4', '0'),
('417', 'plg_search_categories', 'plugin', 'categories', 'search', '0', '1', '1', '0', '{\"name\":\"plg_search_categories\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"categories\"}', '{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('418', 'plg_search_contacts', 'plugin', 'contacts', 'search', '0', '1', '1', '0', '{\"name\":\"plg_search_contacts\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CONTACTS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contacts\"}', '{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('419', 'plg_search_content', 'plugin', 'content', 'search', '0', '1', '1', '0', '{\"name\":\"plg_search_content\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}', '{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('420', 'plg_search_newsfeeds', 'plugin', 'newsfeeds', 'search', '0', '1', '1', '0', '{\"name\":\"plg_search_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}', '{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('422', 'plg_system_languagefilter', 'plugin', 'languagefilter', 'system', '0', '0', '1', '1', '{\"name\":\"plg_system_languagefilter\",\"type\":\"plugin\",\"creationDate\":\"July 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"languagefilter\"}', '', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('423', 'plg_system_p3p', 'plugin', 'p3p', 'system', '0', '0', '1', '0', '{\"name\":\"plg_system_p3p\",\"type\":\"plugin\",\"creationDate\":\"September 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_P3P_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"p3p\"}', '{\"headers\":\"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM\"}', '', '', '0', '0000-00-00 00:00:00', '2', '0'),
('424', 'plg_system_cache', 'plugin', 'cache', 'system', '0', '0', '1', '1', '{\"name\":\"plg_system_cache\",\"type\":\"plugin\",\"creationDate\":\"February 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CACHE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"cache\"}', '{\"browsercache\":\"0\",\"cachetime\":\"15\"}', '', '', '0', '0000-00-00 00:00:00', '9', '0'),
('425', 'plg_system_debug', 'plugin', 'debug', 'system', '0', '1', '1', '0', '{\"name\":\"plg_system_debug\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_DEBUG_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"debug\"}', '{\"profile\":\"1\",\"queries\":\"1\",\"memory\":\"1\",\"language_files\":\"1\",\"language_strings\":\"1\",\"strip-first\":\"1\",\"strip-prefix\":\"\",\"strip-suffix\":\"\"}', '', '', '0', '0000-00-00 00:00:00', '4', '0'),
('426', 'plg_system_log', 'plugin', 'log', 'system', '0', '1', '1', '1', '{\"name\":\"plg_system_log\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LOG_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"log\"}', '', '', '', '0', '0000-00-00 00:00:00', '5', '0');

INSERT INTO lal5d_extensions
(`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES 
('427', 'plg_system_redirect', 'plugin', 'redirect', 'system', '0', '0', '1', '1', '{\"name\":\"plg_system_redirect\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_REDIRECT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"redirect\"}', '', '', '', '0', '0000-00-00 00:00:00', '6', '0'),
('428', 'plg_system_remember', 'plugin', 'remember', 'system', '0', '1', '1', '1', '{\"name\":\"plg_system_remember\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_REMEMBER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"remember\"}', '', '', '', '0', '0000-00-00 00:00:00', '7', '0'),
('429', 'plg_system_sef', 'plugin', 'sef', 'system', '0', '1', '1', '0', '{\"name\":\"plg_system_sef\",\"type\":\"plugin\",\"creationDate\":\"December 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEF_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"sef\"}', '', '', '', '0', '0000-00-00 00:00:00', '8', '0'),
('430', 'plg_system_logout', 'plugin', 'logout', 'system', '0', '1', '1', '1', '{\"name\":\"plg_system_logout\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"logout\"}', '', '', '', '0', '0000-00-00 00:00:00', '3', '0'),
('431', 'plg_user_contactcreator', 'plugin', 'contactcreator', 'user', '0', '1', '1', '0', '{\"name\":\"plg_user_contactcreator\",\"type\":\"plugin\",\"creationDate\":\"August 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTACTCREATOR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contactcreator\"}', '{\"autowebpage\":\"\",\"category\":\"34\",\"autopublish\":\"0\"}', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('432', 'plg_user_joomla', 'plugin', 'joomla', 'user', '0', '1', '1', '0', '{\"name\":\"plg_user_joomla\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_USER_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}', '{\"autoregister\":\"1\",\"mail_to_user\":\"1\",\"forceLogout\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '2', '0'),
('433', 'plg_user_profile', 'plugin', 'profile', 'user', '0', '1', '1', '0', '{\"name\":\"plg_user_profile\",\"type\":\"plugin\",\"creationDate\":\"January 2008\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_USER_PROFILE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"profile\"}', '{\"register-require_address1\":\"1\",\"register-require_address2\":\"1\",\"register-require_city\":\"1\",\"register-require_region\":\"1\",\"register-require_country\":\"1\",\"register-require_postal_code\":\"1\",\"register-require_phone\":\"1\",\"register-require_website\":\"1\",\"register-require_favoritebook\":\"1\",\"register-require_aboutme\":\"1\",\"register-require_tos\":\"1\",\"register-require_dob\":\"1\",\"profile-require_address1\":\"1\",\"profile-require_address2\":\"1\",\"profile-require_city\":\"1\",\"profile-require_region\":\"1\",\"profile-require_country\":\"1\",\"profile-require_postal_code\":\"1\",\"profile-require_phone\":\"1\",\"profile-require_website\":\"1\",\"profile-require_favoritebook\":\"1\",\"profile-require_aboutme\":\"1\",\"profile-require_tos\":\"1\",\"profile-require_dob\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('434', 'plg_extension_joomla', 'plugin', 'joomla', 'extension', '0', '1', '1', '1', '{\"name\":\"plg_extension_joomla\",\"type\":\"plugin\",\"creationDate\":\"May 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}', '', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('435', 'plg_content_joomla', 'plugin', 'joomla', 'content', '0', '1', '1', '0', '{\"name\":\"plg_content_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('436', 'plg_system_languagecode', 'plugin', 'languagecode', 'system', '0', '0', '1', '0', '{\"name\":\"plg_system_languagecode\",\"type\":\"plugin\",\"creationDate\":\"November 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"languagecode\"}', '', '', '', '0', '0000-00-00 00:00:00', '10', '0'),
('437', 'plg_quickicon_joomlaupdate', 'plugin', 'joomlaupdate', 'quickicon', '0', '1', '1', '1', '{\"name\":\"plg_quickicon_joomlaupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomlaupdate\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('438', 'plg_quickicon_extensionupdate', 'plugin', 'extensionupdate', 'quickicon', '0', '1', '1', '1', '{\"name\":\"plg_quickicon_extensionupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"extensionupdate\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('439', 'plg_captcha_recaptcha', 'plugin', 'recaptcha', 'captcha', '0', '0', '1', '0', '{\"name\":\"plg_captcha_recaptcha\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.4.0\",\"description\":\"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"recaptcha\"}', '{\"public_key\":\"\",\"private_key\":\"\",\"theme\":\"clean\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('440', 'plg_system_highlight', 'plugin', 'highlight', 'system', '0', '1', '1', '0', '{\"name\":\"plg_system_highlight\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_HIGHLIGHT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"highlight\"}', '', '', '', '0', '0000-00-00 00:00:00', '7', '0'),
('441', 'plg_content_finder', 'plugin', 'finder', 'content', '0', '1', '1', '0', '{\"name\":\"plg_content_finder\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"finder\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('442', 'plg_finder_categories', 'plugin', 'categories', 'finder', '0', '1', '1', '0', '{\"name\":\"plg_finder_categories\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"categories\"}', '', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('443', 'plg_finder_contacts', 'plugin', 'contacts', 'finder', '0', '1', '1', '0', '{\"name\":\"plg_finder_contacts\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CONTACTS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contacts\"}', '', '', '', '0', '0000-00-00 00:00:00', '2', '0'),
('444', 'plg_finder_content', 'plugin', 'content', 'finder', '0', '1', '1', '0', '{\"name\":\"plg_finder_content\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}', '', '', '', '0', '0000-00-00 00:00:00', '3', '0'),
('445', 'plg_finder_newsfeeds', 'plugin', 'newsfeeds', 'finder', '0', '1', '1', '0', '{\"name\":\"plg_finder_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}', '', '', '', '0', '0000-00-00 00:00:00', '4', '0'),
('447', 'plg_finder_tags', 'plugin', 'tags', 'finder', '0', '1', '1', '0', '{\"name\":\"plg_finder_tags\",\"type\":\"plugin\",\"creationDate\":\"February 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('448', 'plg_twofactorauth_totp', 'plugin', 'totp', 'twofactorauth', '0', '0', '1', '0', '{\"name\":\"plg_twofactorauth_totp\",\"type\":\"plugin\",\"creationDate\":\"August 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"PLG_TWOFACTORAUTH_TOTP_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"totp\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('449', 'plg_authentication_cookie', 'plugin', 'cookie', 'authentication', '0', '1', '1', '0', '{\"name\":\"plg_authentication_cookie\",\"type\":\"plugin\",\"creationDate\":\"July 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_AUTH_COOKIE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"cookie\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('450', 'plg_twofactorauth_yubikey', 'plugin', 'yubikey', 'twofactorauth', '0', '0', '1', '0', '{\"name\":\"plg_twofactorauth_yubikey\",\"type\":\"plugin\",\"creationDate\":\"September 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"PLG_TWOFACTORAUTH_YUBIKEY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"yubikey\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('451', 'plg_search_tags', 'plugin', 'tags', 'search', '0', '1', '1', '0', '{\"name\":\"plg_search_tags\",\"type\":\"plugin\",\"creationDate\":\"March 2014\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}', '{\"search_limit\":\"50\",\"show_tagged_items\":\"1\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('452', 'plg_system_updatenotification', 'plugin', 'updatenotification', 'system', '0', '1', '1', '0', '{\"name\":\"plg_system_updatenotification\",\"type\":\"plugin\",\"creationDate\":\"May 2015\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_SYSTEM_UPDATENOTIFICATION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"updatenotification\"}', '{\"lastrun\":1479127224}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('453', 'plg_editors-xtd_module', 'plugin', 'module', 'editors-xtd', '0', '1', '1', '0', '{\"name\":\"plg_editors-xtd_module\",\"type\":\"plugin\",\"creationDate\":\"October 2015\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_MODULE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"module\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('454', 'plg_system_stats', 'plugin', 'stats', 'system', '0', '1', '1', '0', '{\"name\":\"plg_system_stats\",\"type\":\"plugin\",\"creationDate\":\"November 2013\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_SYSTEM_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"stats\"}', '{\"mode\":3,\"lastrun\":1478930142,\"unique_id\":\"c87eab394c2f6fa1e32af08210c503ca8a78e91a\",\"interval\":12}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('455', 'plg_installer_packageinstaller', 'plugin', 'packageinstaller', 'installer', '0', '1', '1', '1', '{\"name\":\"plg_installer_packageinstaller\",\"type\":\"plugin\",\"creationDate\":\"May 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.0\",\"description\":\"PLG_INSTALLER_PACKAGEINSTALLER_PLUGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"packageinstaller\"}', '', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('456', 'PLG_INSTALLER_FOLDERINSTALLER', 'plugin', 'folderinstaller', 'installer', '0', '1', '1', '1', '{\"name\":\"PLG_INSTALLER_FOLDERINSTALLER\",\"type\":\"plugin\",\"creationDate\":\"May 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.0\",\"description\":\"PLG_INSTALLER_FOLDERINSTALLER_PLUGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"folderinstaller\"}', '', '', '', '0', '0000-00-00 00:00:00', '2', '0'),
('457', 'PLG_INSTALLER_URLINSTALLER', 'plugin', 'urlinstaller', 'installer', '0', '1', '1', '1', '{\"name\":\"PLG_INSTALLER_URLINSTALLER\",\"type\":\"plugin\",\"creationDate\":\"May 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.0\",\"description\":\"PLG_INSTALLER_URLINSTALLER_PLUGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"urlinstaller\"}', '', '', '', '0', '0000-00-00 00:00:00', '3', '0'),
('503', 'beez3', 'template', 'beez3', '', '0', '1', '1', '0', '{\"name\":\"beez3\",\"type\":\"template\",\"creationDate\":\"25 November 2009\",\"author\":\"Angie Radtke\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"a.radtke@derauftritt.de\",\"authorUrl\":\"http:\\/\\/www.der-auftritt.de\",\"version\":\"3.1.0\",\"description\":\"TPL_BEEZ3_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"sitetitle\":\"\",\"sitedescription\":\"\",\"navposition\":\"center\",\"templatecolor\":\"nature\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('504', 'hathor', 'template', 'hathor', '', '1', '1', '1', '0', '{\"name\":\"hathor\",\"type\":\"template\",\"creationDate\":\"May 2010\",\"author\":\"Andrea Tarr\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"3.0.0\",\"description\":\"TPL_HATHOR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"showSiteName\":\"0\",\"colourChoice\":\"0\",\"boldText\":\"0\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('506', 'protostar', 'template', 'protostar', '', '0', '1', '1', '0', '{\"name\":\"protostar\",\"type\":\"template\",\"creationDate\":\"4\\/30\\/2012\",\"author\":\"Kyle Ledbetter\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"TPL_PROTOSTAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"templateColor\":\"\",\"logoFile\":\"\",\"googleFont\":\"1\",\"googleFontName\":\"Open+Sans\",\"fluidContainer\":\"0\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('507', 'isis', 'template', 'isis', '', '1', '1', '1', '0', '{\"name\":\"isis\",\"type\":\"template\",\"creationDate\":\"3\\/30\\/2012\",\"author\":\"Kyle Ledbetter\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"TPL_ISIS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"templateColor\":\"\",\"logoFile\":\"\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('600', 'English (en-GB)', 'language', 'en-GB', '', '0', '1', '1', '1', '{\"name\":\"English (en-GB)\",\"type\":\"language\",\"creationDate\":\"October 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.4\",\"description\":\"en-GB site language\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('601', 'English (en-GB)', 'language', 'en-GB', '', '1', '1', '1', '1', '{\"name\":\"English (en-GB)\",\"type\":\"language\",\"creationDate\":\"October 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.4\",\"description\":\"en-GB administrator language\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('700', 'files_joomla', 'file', 'joomla', '', '0', '1', '1', '1', '{\"name\":\"files_joomla\",\"type\":\"file\",\"creationDate\":\"October 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.4\",\"description\":\"FILES_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('802', 'English (en-GB) Language Pack', 'package', 'pkg_en-GB', '', '0', '1', '1', '1', '{\"name\":\"English (en-GB) Language Pack\",\"type\":\"package\",\"creationDate\":\"October 2016\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.6.4.1\",\"description\":\"en-GB language pack\",\"group\":\"\",\"filename\":\"pkg_en-GB\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10000', 'VIRTUEMART', 'component', 'com_virtuemart', '', '1', '1', '0', '0', '{\"name\":\"VIRTUEMART\",\"type\":\"component\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004-2015 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"max|at|virtuemart.net\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"\",\"group\":\"\",\"filename\":\"virtuemart\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10001', 'VirtueMart_allinone', 'component', 'com_virtuemart_allinone', '', '1', '1', '0', '0', '{\"name\":\"VirtueMart_allinone\",\"type\":\"component\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004-2015 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"\",\"group\":\"\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10002', 'VM Payment - Standard', 'plugin', 'standard', 'vmpayment', '0', '1', '1', '0', '{\"name\":\"Standard\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"Standard payment plugin\",\"group\":\"\",\"filename\":\"standard\"}', '', '', '', '0', '0000-00-00 00:00:00', '20', '0'),
('10003', 'VM Payment - Klarna', 'plugin', 'klarna', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"Klarna\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"Klarna VirtueMart Payment Plugin\",\"group\":\"\",\"filename\":\"klarna\"}', '', '', '', '0', '0000-00-00 00:00:00', '6', '0'),
('10004', 'VM Payment - KlarnaCheckout', 'plugin', 'klarnacheckout', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"Klarna Checkout\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"\",\"group\":\"\",\"filename\":\"klarnacheckout\"}', '', '', '', '0', '0000-00-00 00:00:00', '20', '0'),
('10005', 'VM Payment - Sofort Banking/Überweisung', 'plugin', 'sofort', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"Sofort\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"<a href=\\\"http:\\/www.sofort.com\\\" target=\\\"_blank\\\">Sofort<\\/a> is a popular\\n\\tpayment provider and available in many countries. \\n    \",\"group\":\"\",\"filename\":\"sofort\"}', '', '', '', '0', '0000-00-00 00:00:00', '4', '0'),
('10006', 'VM Payment - PayPal', 'plugin', 'paypal', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"PayPal\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"PayPal\",\"group\":\"\",\"filename\":\"paypal\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10007', 'VM Payment - Heidelpay', 'plugin', 'heidelpay', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"Heidelpay\",\"type\":\"plugin\",\"creationDate\":\"12-Sep-2012\",\"author\":\"Heidelberger Payment GmbH\",\"copyright\":\"Copyright Heidelberger Payment GmbH\",\"authorEmail\":\"info@heidelpay.de\",\"authorUrl\":\"http:\\/\\/www.heidelpay.de\",\"version\":\"3.0.0\",\"description\":\"\\n        <h2>Virtuemart Plugin von:<\\/h2><p><a href=\\\"http:\\/\\/www.Heidelpay.de\\\" target=\\\"_blank\\\"><img src=\\\"http:\\/\\/www.heidelpay.de\\/gfx\\/logo.gif\\\" style=\\\"margin-right:20px;\\\"\\/><\\/a><\\/p> \",\"group\":\"\",\"filename\":\"heidelpay\"}', '', '', '', '0', '0000-00-00 00:00:00', '8', '0'),
('10008', 'VM Payment - Paybox', 'plugin', 'paybox', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"VM Payment - Paybox\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"<a href=\\\"http:\\/\\/paybox.com\\\" target=\\\"_blank\\\">Paybox<\\/a> \\n    \",\"group\":\"\",\"filename\":\"paybox\"}', '', '', '', '0', '0000-00-00 00:00:00', '7', '0'),
('10009', 'VM Payment - 2Checkout', 'plugin', 'tco', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"2Checkout\",\"type\":\"plugin\",\"creationDate\":\"October 2015\",\"author\":\"Craig Christenson\",\"copyright\":\"Copyright (C) 2004-2015 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.2checkout.com\",\"version\":\"0.1\",\"description\":\"<a href=\\\"https:\\/\\/www.2checkout.com\\/referral?r=virtuemart\\\" target=\\\"_blank\\\">2Checkout<\\/a> is a popular payment provider and available in many countries. \\n    \",\"group\":\"\",\"filename\":\"tco\"}', '', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('10010', 'VM Payment - Pay with Amazon', 'plugin', 'amazon', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"AMAZON\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"AMAZON payment plugin\",\"group\":\"\",\"filename\":\"amazon\"}', '', '', '', '0', '0000-00-00 00:00:00', '2', '0'),
('10011', 'System - Pay with Amazon', 'plugin', 'amazon', 'system', '0', '0', '1', '0', '{\"name\":\"AMAZON\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"AMAZON payment SYSTEM plugin\",\"group\":\"\",\"filename\":\"amazon\"}', '', '', '', '0', '0000-00-00 00:00:00', '2', '0');

INSERT INTO lal5d_extensions
(`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES 
('10012', 'VM Payment - Realex HPP & API', 'plugin', 'realex_hpp_api', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"realex_hpp_api\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"Realex HPP and API\",\"group\":\"\",\"filename\":\"realex_hpp_api\"}', '', '', '', '0', '0000-00-00 00:00:00', '3', '0'),
('10013', 'VM UserField - Realex HPP & API', 'plugin', 'realex_hpp_api', 'vmuserfield', '0', '0', '1', '0', '{\"name\":\"Realex_hpp_api\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"Card storage plugin for Realex\",\"group\":\"\",\"filename\":\"realex_hpp_api\"}', '', '', '', '0', '0000-00-00 00:00:00', '3', '0'),
('10014', 'VM Payment - Skrill', 'plugin', 'skrill', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"Skrill\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"Skrill Holdings Limited\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.skrill.com\",\"version\":\"3.0.18\",\"description\":\"<a href=\\\"http:\\/\\/www.skrill.com\\\" target=\\\"_blank\\\">skrill<\\/a> is a popular\\n\\tpayment provider authorised by the Financial Services Authority of the United Kingdom (FSA). \\n    \",\"group\":\"\",\"filename\":\"skrill\"}', '', '', '', '0', '0000-00-00 00:00:00', '9', '0'),
('10015', 'VM Payment - Authorize.net', 'plugin', 'authorizenet', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"Authorize.net AIM\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"Authorize.net AIM\",\"group\":\"\",\"filename\":\"authorizenet\"}', '', '', '', '0', '0000-00-00 00:00:00', '20', '0'),
('10016', 'VM Payment - Sofort iDeal', 'plugin', 'sofort_ideal', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"Sofort Ideal\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"<a href=\\\"http:\\/www.sofort.com\\\" target=\\\"_blank\\\">Sofort<\\/a> is a popular\\n\\tpayment provider and available in many countries. \\n    \",\"group\":\"\",\"filename\":\"sofort\"}', '', '', '', '0', '0000-00-00 00:00:00', '5', '0'),
('10017', 'VM Payment - Klikandpay', 'plugin', 'klikandpay', 'vmpayment', '0', '0', '1', '0', '{\"name\":\"VM Payment - klikandpay\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"Beta1\",\"description\":\"<a href=\\\"http:\\/\\/klikandpay.com\\\" target=\\\"_blank\\\">klikandpay<\\/a> \\n    \",\"group\":\"\",\"filename\":\"klikandpay\"}', '', '', '', '0', '0000-00-00 00:00:00', '10', '0'),
('10018', 'VM Shipment - By weight, ZIP and countries', 'plugin', 'weight_countries', 'vmshipment', '0', '1', '1', '0', '{\"name\":\"By weight, ZIP and countries\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"VMSHIPMENT_WEIGHT_COUNTRIES_PLUGIN_DESC\",\"group\":\"\",\"filename\":\"weight_countries\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10019', 'VM Custom - Customer text input', 'plugin', 'textinput', 'vmcustom', '0', '1', '1', '0', '{\"name\":\"VMCustom - textinput\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004-2014 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"text input plugin for product\",\"group\":\"\",\"filename\":\"textinput\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10020', 'VM Custom - Product specification', 'plugin', 'specification', 'vmcustom', '0', '1', '1', '0', '{\"name\":\"plgvm_specification\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004-2014 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"VMCustom - specification; text input plugin for product\",\"group\":\"\",\"filename\":\"specification\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10021', 'VM Calculation - Avalara Tax', 'plugin', 'avalara', 'vmcalculation', '0', '0', '1', '0', '{\"name\":\"VM - Calculation Avalara Tax\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"Max Milbers\",\"copyright\":\"Copyright (C) 2013 iStraxx UG (haftungsbeschr\\u00e4nkt). All rights reserved\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"VM - Calculation Avalara Tax; On demand tax calculation for whole U.S.A.\",\"group\":\"\",\"filename\":\"avalara\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10022', 'VirtueMart Product', 'plugin', 'virtuemart', 'search', '0', '0', '1', '0', '{\"name\":\"Search - VirtueMart\",\"type\":\"plugin\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"PLG_SEARCH_VIRTUEMART_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"virtuemart\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10023', 'mod_vmmenu', 'module', 'mod_vmmenu', '', '1', '1', '3', '0', '{\"name\":\"VirtueMart Administrator Menu\",\"type\":\"module\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004-2013 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"max|at|virtuemart.net\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"MOD_VMMENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_vmmenu\"}', '', '', '', '0', '0000-00-00 00:00:00', '5', '0'),
('10024', 'mod_virtuemart_currencies', 'module', 'mod_virtuemart_currencies', '', '0', '1', '1', '0', '{\"name\":\"mod_virtuemart_currencies\",\"type\":\"module\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"MOD_VIRTUEMART_CURRENCIES_DESC\",\"group\":\"\",\"filename\":\"mod_virtuemart_currencies\"}', '', '', '', '0', '0000-00-00 00:00:00', '5', '0'),
('10025', 'mod_virtuemart_product', 'module', 'mod_virtuemart_product', '', '0', '1', '1', '0', '{\"name\":\"mod_virtuemart_product\",\"type\":\"module\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"MOD_VIRTUEMART_PRODUCT_DESC\",\"group\":\"\",\"filename\":\"mod_virtuemart_product\"}', '', '', '', '0', '0000-00-00 00:00:00', '3', '0'),
('10026', 'mod_virtuemart_search', 'module', 'mod_virtuemart_search', '', '0', '1', '1', '0', '{\"name\":\"mod_virtuemart_search\",\"type\":\"module\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"MOD_VIRTUEMART_SEARCH_DESC\",\"group\":\"\",\"filename\":\"mod_virtuemart_search\"}', '', '', '', '0', '0000-00-00 00:00:00', '2', '0'),
('10027', 'mod_virtuemart_manufacturer', 'module', 'mod_virtuemart_manufacturer', '', '0', '1', '1', '0', '{\"name\":\"mod_virtuemart_manufacturer\",\"type\":\"module\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"MOD_VIRTUEMART_MANUFACTURER_DESC\",\"group\":\"\",\"filename\":\"mod_virtuemart_manufacturer\"}', '', '', '', '0', '0000-00-00 00:00:00', '8', '0'),
('10028', 'mod_virtuemart_cart', 'module', 'mod_virtuemart_cart', '', '0', '1', '1', '0', '{\"name\":\"mod_virtuemart_cart\",\"type\":\"module\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"MOD_VIRTUEMART_CART_DESC\",\"group\":\"\",\"filename\":\"mod_virtuemart_cart\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10029', 'mod_virtuemart_category', 'module', 'mod_virtuemart_category', '', '0', '1', '1', '0', '{\"name\":\"mod_virtuemart_category\",\"type\":\"module\",\"creationDate\":\"September 20 2016\",\"author\":\"The VirtueMart Development Team\",\"copyright\":\"Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/www.virtuemart.net\",\"version\":\"3.0.18\",\"description\":\"MOD_VIRTUEMART_CATEGORY_DESC\",\"group\":\"\",\"filename\":\"mod_virtuemart_category\"}', '', '', '', '0', '0000-00-00 00:00:00', '4', '0'),
('10031', 'Helix3 - Ajax', 'plugin', 'helix3', 'ajax', '0', '1', '1', '0', '{\"name\":\"Helix3 - Ajax\",\"type\":\"plugin\",\"creationDate\":\"Jan 2015\",\"author\":\"JoomShaper.com\",\"copyright\":\"Copyright (C) 2010 - 2015 JoomShaper. All rights reserved.\",\"authorEmail\":\"support@joomshaper.com\",\"authorUrl\":\"www.joomshaper.com\",\"version\":\"1.2\",\"description\":\"Helix3 Framework - Joomla Template Framework by JoomShaper\",\"group\":\"\",\"filename\":\"helix3\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10032', 'System - Helix3 Framework', 'plugin', 'helix3', 'system', '0', '1', '1', '0', '{\"name\":\"System - Helix3 Framework\",\"type\":\"plugin\",\"creationDate\":\"Jan 2015\",\"author\":\"JoomShaper.com\",\"copyright\":\"Copyright (C) 2010 - 2015 JoomShaper. All rights reserved.\",\"authorEmail\":\"support@joomshaper.com\",\"authorUrl\":\"www.joomshaper.com\",\"version\":\"1.2\",\"description\":\"Helix3 Framework - Joomla Template Framework by JoomShaper\",\"group\":\"\",\"filename\":\"helix3\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10033', 'BestShop', 'template', 'bestshop', '', '0', '1', '1', '0', '{\"name\":\"BestShop\",\"type\":\"template\",\"creationDate\":\"Nov 2016\",\"author\":\"webkomp.eu\",\"copyright\":\"Copyright (C) 2016 webkomp.eu All rights reserved.\",\"authorEmail\":\"biuro@web-komp.eu\",\"authorUrl\":\"http:\\/\\/www.web-komp.eu\",\"version\":\"1.2\",\"description\":\"BestShop - Joomla! template\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"sticky_header\":\"1\",\"boxed_layout\":\"0\",\"page_loader\":\"1\",\"logo_type\":\"image\",\"logo_position\":\"logo\",\"body_bg_repeat\":\"inherit\",\"body_bg_size\":\"inherit\",\"body_bg_attachment\":\"inherit\",\"body_bg_position\":\"0 0\",\"enabled_copyright\":\"1\",\"copyright_position\":\"footer1\",\"copyright\":\"\\u00a9 2015 Your Company. All Rights Reserved. Designed By JoomShaper\",\"show_social_icons\":\"1\",\"social_position\":\"top1\",\"enable_contactinfo\":\"1\",\"contact_position\":\"top2\",\"contact_phone\":\"+228 872 4444\",\"contact_time\":\"Mon - Sat: 09.00 - 19.00\",\"contact_email\":\"contact@email.com\",\"comingsoon_mode\":\"0\",\"comingsoon_title\":\"Coming Soon Title\",\"comingsoon_date\":\"5-10-2018\",\"comingsoon_content\":\"Coming soon content\",\"preset\":\"preset1\",\"preset1_bg\":\"#ffffff\",\"preset1_text\":\"#000000\",\"preset1_major\":\"#26aae1\",\"preset2_bg\":\"#ffffff\",\"preset2_text\":\"#000000\",\"preset2_major\":\"#3d449a\",\"preset3_bg\":\"#ffffff\",\"preset3_text\":\"#000000\",\"preset3_major\":\"#2bb673\",\"preset4_bg\":\"#ffffff\",\"preset4_text\":\"#000000\",\"preset4_major\":\"#eb4947\",\"menu\":\"mainmenu\",\"menu_type\":\"mega_offcanvas\",\"menu_animation\":\"menu-fade\",\"enable_body_font\":\"1\",\"body_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"300\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h1_font\":\"1\",\"h1_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"800\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h2_font\":\"1\",\"h2_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"600\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h3_font\":\"1\",\"h3_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"regular\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h4_font\":\"1\",\"h4_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"regular\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h5_font\":\"1\",\"h5_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"600\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h6_font\":\"1\",\"h6_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"600\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_navigation_font\":\"0\",\"enable_custom_font\":\"0\",\"compress_css\":\"0\",\"compress_js\":\"0\",\"lessoption\":\"0\",\"show_post_format\":\"1\",\"commenting_engine\":\"disabled\",\"disqus_devmode\":\"0\",\"intensedebate_acc\":\"\",\"fb_width\":\"500\",\"fb_cpp\":\"10\",\"comments_count\":\"0\",\"social_share\":\"1\",\"image_small\":\"0\",\"image_small_size\":\"100X100\",\"image_thumbnail\":\"1\",\"image_thumbnail_size\":\"200X200\",\"image_medium\":\"0\",\"image_medium_size\":\"300X300\",\"image_large\":\"0\",\"image_large_size\":\"600X600\",\"blog_list_image\":\"default\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10034', 'rt_vehicles', 'template', 'rt_vehicles', '', '0', '1', '1', '0', '{\"name\":\"rt_vehicles\",\"type\":\"template\",\"creationDate\":\"October 2016\",\"author\":\"Rush Themes\",\"copyright\":\"Copyright (C) 2016 Rush Themes\",\"authorEmail\":\"mail@rushthemes.com\",\"authorUrl\":\"http:\\/\\/www.rushthemes.com\",\"version\":\"1.0\",\"description\":\"Rush Themes Responsive Joomla 3x Templates\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"logo\":\"templates\\/rt_vehicles\\/images\\/logo.png\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10036', 'Gantry', 'library', 'lib_gantry', '', '0', '1', '1', '0', '{\"name\":\"Gantry\",\"type\":\"library\",\"creationDate\":\"September 14, 2016\",\"author\":\"RocketTheme, LLC\",\"copyright\":\"(C) 2005 - 2016 RocketTheme, LLC. All rights reserved.\",\"authorEmail\":\"support@rockettheme.com\",\"authorUrl\":\"http:\\/\\/www.rockettheme.com\",\"version\":\"4.1.32\",\"description\":\"Gantry Starting Template for Joomla! v4.1.32\",\"group\":\"\",\"filename\":\"lib_gantry\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10037', 'Gantry', 'component', 'com_gantry', '', '1', '1', '0', '0', '{\"name\":\"Gantry\",\"type\":\"component\",\"creationDate\":\"September 14, 2016\",\"author\":\"RocketTheme, LLC\",\"copyright\":\"(C) 2005 - 2016 RocketTheme, LLC. All rights reserved.\",\"authorEmail\":\"support@rockettheme.com\",\"authorUrl\":\"http:\\/\\/www.rockettheme.com\",\"version\":\"4.1.32\",\"description\":\"Gantry Starting Template for Joomla! v4.1.32\",\"group\":\"\",\"filename\":\"gantry\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10038', 'System - Gantry', 'plugin', 'gantry', 'system', '0', '1', '1', '0', '{\"name\":\"System - Gantry\",\"type\":\"plugin\",\"creationDate\":\"September 14, 2016\",\"author\":\"RocketTheme, LLC\",\"copyright\":\"(C) 2005 - 2016 RocketTheme, LLC. All rights reserved.\",\"authorEmail\":\"support@rockettheme.com\",\"authorUrl\":\"http:\\/\\/www.rockettheme.com\",\"version\":\"4.1.32\",\"description\":\"Gantry System Plugin for Joomla\",\"group\":\"\",\"filename\":\"gantry\"}', '{\"debugloglevel\":\"63\"}', '', '', '0', '0000-00-00 00:00:00', '1', '0'),
('10039', 'PLG_EMBED_GOOGLE_MAP', 'plugin', 'embed_google_map', 'content', '0', '1', '1', '0', '{\"name\":\"PLG_EMBED_GOOGLE_MAP\",\"type\":\"plugin\",\"creationDate\":\"25 June 2016\",\"author\":\"Petteri Kivim\\u00e4ki\",\"copyright\":\"(C)2012-2016 Petteri Kivim\\u00e4ki\",\"authorEmail\":\"dinky_jackson@hotmail.com\",\"authorUrl\":\"\",\"version\":\"2.1.0\",\"description\":\"PLG_EMBED_GOOGLE_MAP_DESC\",\"group\":\"\",\"filename\":\"embed_google_map\"}', '{\"version\":\"new\",\"map_type\":\"m\",\"zoom\":\"14\",\"language\":\"-\",\"add_link\":\"1\",\"link_label\":\"View Larger Map\",\"link_full\":\"1\",\"show_info\":\"0\",\"height\":\"400\",\"width\":\"300\",\"border\":\"0\",\"border_style\":\"solid\",\"border_color\":\"#000000\",\"https\":\"1\",\"embed_api_key\":\"\",\"load_async\":\"1\",\"delay_ms\":\"2000\",\"scrolling\":\"0\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10040', 'FlippingBook', 'component', 'com_flippingbook', '', '1', '1', '0', '0', '{\"name\":\"FlippingBook\",\"type\":\"component\",\"creationDate\":\"July 2013\",\"author\":\"Mediaparts Interactive\",\"copyright\":\"(C) 2013 Mediaparts Interactive. All rights reserved.\",\"authorEmail\":\"support@page-flip-tools.com\",\"authorUrl\":\"http:\\/\\/page-flip-tools.com\",\"version\":\"3.1.0\",\"description\":\"FlippingBook Joomla Gallery Component allows you to build stunning flash books on your site in minutes. Prepare images for your book, upload them to the server and create a book in several mouse clicks. Enjoy the realistic page flip effect based on the excellent page flip engine.\",\"group\":\"\",\"filename\":\"flippingbook\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10041', 'Akeeba', 'component', 'com_akeeba', '', '1', '1', '0', '0', '{\"name\":\"Akeeba\",\"type\":\"component\",\"creationDate\":\"2015-10-14\",\"author\":\"Nicholas K. Dionysopoulos\",\"copyright\":\"Copyright (c)2006-2014 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@dionysopoulos.me\",\"authorUrl\":\"http:\\/\\/www.akeebabackup.com\",\"version\":\"4.4.2\",\"description\":\"Akeeba Backup Core - Full Joomla! site backup solution, Core Edition.\",\"group\":\"\",\"filename\":\"akeeba\"}', '{\"confwiz_upgrade\":1}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10042', 'F0F (NEW) DO NOT REMOVE', 'library', 'lib_f0f', '', '0', '1', '1', '0', '{\"name\":\"F0F (NEW) DO NOT REMOVE\",\"type\":\"library\",\"creationDate\":\"2015-07-20 16:28:08\",\"author\":\"Nicholas K. Dionysopoulos \\/ Akeeba Ltd\",\"copyright\":\"(C)2011-2014 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@akeebabackup.com\",\"authorUrl\":\"https:\\/\\/www.akeebabackup.com\",\"version\":\"rev8F10700-1437402488\",\"description\":\"Framework-on-Framework (FOF) newer version - DO NOT REMOVE - The rapid component development framework for Joomla!. This package is the newer version of FOF, not the one shipped with Joomla! as the official Joomla! RAD Layer. The Joomla! RAD Layer has ceased development in March 2014. DO NOT UNINSTALL THIS PACKAGE, IT IS *** N O T *** A DUPLICATE OF THE \'FOF\' PACKAGE. REMOVING EITHER FOF PACKAGE WILL BREAK YOUR SITE.\",\"group\":\"\",\"filename\":\"lib_f0f\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10043', 'AkeebaStrapper', 'file', 'files_strapper', '', '0', '1', '0', '0', '{\"name\":\"AkeebaStrapper\",\"type\":\"file\",\"creationDate\":\"2015-07-20 16:28:08\",\"author\":\"Nicholas K. Dionysopoulos\",\"copyright\":\"(C) 2012-2013 Akeeba Ltd.\",\"authorEmail\":\"nicholas@dionysopoulos.me\",\"authorUrl\":\"https:\\/\\/www.akeebabackup.com\",\"version\":\"rev8F10700-1437402488\",\"description\":\"Namespaced jQuery, jQuery UI and Bootstrap for Akeeba products.\",\"group\":\"\"}', '', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10044', 'plg_system_jsntplframework', 'plugin', 'jsntplframework', 'system', '0', '1', '1', '1', '{\"name\":\"plg_system_jsntplframework\",\"type\":\"plugin\",\"creationDate\":\"08\\/21\\/2015\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"3.1.6\",\"description\":\"\",\"group\":\"\",\"filename\":\"jsntplframework\"}', '{\"update-check\":1479130535}', '', '', '0', '0000-00-00 00:00:00', '9999', '0'),
('10045', 'jsn_dome_free', 'template', 'jsn_dome_free', '', '0', '1', '1', '0', '{\"name\":\"jsn_dome_free\",\"type\":\"template\",\"creationDate\":\"08\\/21\\/2015\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"4.0.4\",\"description\":\"TPL_JSN_DOME_FREE_XML_DESCRIPTION\",\"group\":\"jsntemplate\",\"filename\":\"templateDetails\"}', '[]', 'jsntemplate', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10046', 'ImageShow', 'component', 'com_imageshow', '', '1', '1', '0', '0', '{\"name\":\"ImageShow\",\"type\":\"component\",\"creationDate\":\"11\\/08\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"5.0.3\",\"description\":\"JSN IMAGESHOW FREE\",\"group\":\"\",\"filename\":\"imageshow\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10047', 'Content - JSN ImageShow', 'plugin', 'imageshow', 'content', '0', '1', '1', '1', '{\"name\":\"Content - JSN ImageShow\",\"type\":\"plugin\",\"creationDate\":\"11/08/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"5.0.3\",\"description\":\"JSN_IMAGESHOW_CONTENT_PLUGIN\",\"group\":\"\",\"filename\":\"imageshow\",\"dependency\":[\"imageshow\"]}', '{\"imageshow\":\"imageshow\"}', '[\"imageshow\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10048', 'System - JSN ImageShow', 'plugin', 'imageshow', 'system', '0', '1', '1', '1', '{\"name\":\"System - JSN ImageShow\",\"type\":\"plugin\",\"creationDate\":\"11/08/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"5.0.3\",\"description\":\"JSN_IMAGESHOW_SYSTEM_PLUGIN\",\"group\":\"\",\"filename\":\"imageshow\",\"dependency\":[\"imageshow\"]}', '{\"imageshow\":\"imageshow\"}', '[\"imageshow\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10049', 'Button - ImageShow', 'plugin', 'imageshow', 'editors-xtd', '0', '1', '1', '1', '{\"name\":\"Button - ImageShow\",\"type\":\"plugin\",\"creationDate\":\"11/08/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"5.0.3\",\"description\":\"PLG_EDITOR_JSN_IMAGESHOW_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"imageshow\",\"dependency\":[\"imageshow\"]}', '{\"imageshow\":\"imageshow\"}', '[\"imageshow\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10050', 'JSN ImageShow', 'module', 'mod_imageshow', '', '0', '1', '0', '1', '{\"name\":\"JSN ImageShow\",\"type\":\"module\",\"creationDate\":\"11/08/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"5.0.3\",\"description\":\"JSN_MODULE_JSN_IMAGESHOW_MODULE\",\"group\":\"\",\"filename\":\"mod_imageshow\",\"dependency\":[\"imageshow\"]}', '{\"imageshow\":\"imageshow\"}', '[\"imageshow\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10051', 'JSN ImageShow Quick Icons', 'module', 'mod_imageshow_quickicon', '', '1', '1', '2', '1', '{\"name\":\"JSN ImageShow Quick Icons\",\"type\":\"module\",\"creationDate\":\"11/08/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"5.0.3\",\"description\":\"Quick access icon to reach JSN ImageShow Launch Pad\",\"group\":\"\",\"filename\":\"mod_imageshow_quickicon\",\"dependency\":[\"imageshow\"]}', '{\"imageshow\":\"imageshow\"}', '[\"imageshow\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10052', 'plg_system_jsnframework', 'plugin', 'jsnframework', 'system', '0', '1', '1', '1', '{\"name\":\"plg_system_jsnframework\",\"type\":\"plugin\",\"creationDate\":\"10/05/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (C) 2013 JoomlaShine.com. All Rights Reserved.\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"1.6.6\",\"description\":\"PLG_SYSTEM_JSNFRAMEWORK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"jsnframework\",\"dependency\":[\"imageshow\",\"pagebuilder\",\"poweradmin\",\"uniform\",\"mobilize\",\"easyslider\"]}', '{\"imageshow\":\"imageshow\",\"pagebuilder\":\"pagebuilder\",\"poweradmin\":\"poweradmin\",\"uniform\":\"uniform\",\"mobilize\":\"mobilize\",\"easyslider\":\"easyslider\"}', '[\"imageshow\",\"pagebuilder\",\"poweradmin\",\"uniform\",\"mobilize\",\"easyslider\"]', '', '0', '0000-00-00 00:00:00', '-9999', '0'),
('10053', 'Source Picasa', 'plugin', 'sourcepicasa', 'jsnimageshow', '0', '1', '1', '1', '{\"name\":\"Source Picasa\",\"type\":\"plugin\",\"creationDate\":\"03/23/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"1.1.8\",\"description\":\"JSN IMAGESHOW IMAGE SOURCE PICASA\",\"group\":\"\",\"filename\":\"sourcepicasa\",\"dependency\":[\"imageshow\"]}', '{\"imageshow\":\"imageshow\"}', '[\"imageshow\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10054', 'Theme Classic', 'plugin', 'themeclassic', 'jsnimageshow', '0', '1', '1', '1', '{\"name\":\"Theme Classic\",\"type\":\"plugin\",\"creationDate\":\"09/22/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"1.4.0\",\"description\":\"JSN IMAGESHOW SHOWCASE THEME CLASSIC PLUGIN\",\"group\":\"\",\"filename\":\"themeclassic\",\"dependency\":[\"imageshow\"]}', '{\"imageshow\":\"imageshow\"}', '[\"imageshow\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10055', 'jsn_reta_free', 'template', 'jsn_reta_free', '', '0', '1', '1', '0', '{\"name\":\"jsn_reta_free\",\"type\":\"template\",\"creationDate\":\"10\\/08\\/2015\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"1.0.2\",\"description\":\"TPL_JSN_RETA_FREE_XML_DESCRIPTION\",\"group\":\"jsntemplate\",\"filename\":\"templateDetails\"}', '[]', 'jsntemplate', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10056', 'wt_blank_free', 'template', 'wt_blank_free', '', '0', '1', '1', '0', '{\"name\":\"wt_blank_free\",\"type\":\"template\",\"creationDate\":\"Aug 2015\",\"author\":\"WarpTheme\",\"copyright\":\"Copyright (C) WarpTheme\",\"authorEmail\":\"support@warptheme.com\",\"authorUrl\":\"http:\\/\\/www.warptheme.com\",\"version\":\"1.0.0\",\"description\":\"\\n\\t\\t<div class=\\\"overview-header\\\" style=\\\"text-align: left;\\\">\\n\\t\\t\\t<h2>                             \\n\\t\\t\\t  <small style=\\\"display: block;\\\">Free Responsive Joomla template - <strong>WT Blank<\\/strong>.<\\/small><\\/h2>\\n\\t\\t\\t<p>WT Blank has a responsive layout and provides various features and extended styles for K2, allowing you to creatively build a website in your unique way, from simple to complicated. WT Blank is a full responsive template built Uikit and Warp Framework.<\\/p>\\n\\t\\t\\t<p>Help and Support: Visit <a href=\\\"http:\\/\\/warptheme.com\\/\\\" target=\\\"_blank\\\">WarpTheme<\\/a><\\/p>\\n\\t\\t\\t<\\/div>\\n\\t\\t\",\"group\":\"\",\"filename\":\"templateDetails\"}', '{\"config\":\"\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10057', 'PageBuilder', 'component', 'com_pagebuilder', '', '1', '1', '0', '0', '{\"name\":\"PageBuilder\",\"type\":\"component\",\"creationDate\":\"10\\/10\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2013 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"1.3.2\",\"description\":\"COM_PAGEBUILDER_DESC\",\"group\":\"\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10058', 'System - JSN PageBuilder', 'plugin', 'pagebuilder', 'system', '0', '1', '1', '0', '{\"name\":\"System - JSN PageBuilder\",\"type\":\"plugin\",\"creationDate\":\"10/10/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"1.3.2\",\"description\":\"System - JSN PageBuilder\",\"group\":\"\",\"filename\":\"pagebuilder\",\"dependency\":[\"pagebuilder\"]}', '{\"pagebuilder\":\"pagebuilder\",\"shortcodes\":\"pb_accordion:accordion|pb_accordion_item:element|pb_alert:alert|pb_articlelist:articlelist|pb_audio:audio|pb_button:button|pb_buttonbar:buttonbar|pb_buttonbar_item:element|pb_carousel:carousel|pb_carousel_item:element|pb_divider:divider|pb_easyslider:easyslider|pb_googlemap:googlemap|pb_googlemap_item:element|pb_heading:heading|pb_image:image|pb_imageshow:imageshow|pb_list_item:element|pb_list:list|pb_market_item:element|pb_market:market|pb_module:module|pb_pricingtable_item:element|pb_pricingtable:pricingtable|pb_progressbar_item:element|pb_progressbar:progressbar|pb_progresscircle:progresscircle|pb_promobox:promobox|pb_qrcode:qrcode|pb_socialicon_item:element|pb_socialicon:socialicon|pb_tab_item:element|pb_tab:tab|pb_table_item:element|pb_table:table|pb_testimonial_item:element|pb_testimonial:testimonial|pb_text:text|pb_tooltip:tooltip|pb_uniform:uniform|pb_video:video|pb_weather:weather|pb_helper_item:helpers|pb_html_item:helpers|pb_articles_item:models|pb_authors_item:models|pb_categories_item:models|pb_easyblogarticles_item:models|pb_easyblogcategories_item:models|pb_k2articles_item:models|pb_k2categories_item:models|pb_validate_file_item:helpers|pb_pricingtable_item_item:element|pb_pricingtableattr_item:pricingtableattr|pb_column:column|pb_row:row\",\"articles\":[]}', '[\"pagebuilder\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10059', 'Button - JSN PageBuilder', 'plugin', 'pagebuilder', 'editors-xtd', '0', '1', '1', '0', '{\"name\":\"Button - JSN PageBuilder\",\"type\":\"plugin\",\"creationDate\":\"10/10/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"1.3.2\",\"description\":\"Editor button plugin to ativate JSN PageBuilder\",\"group\":\"\",\"filename\":\"pagebuilder\",\"dependency\":[\"pagebuilder\"]}', '{\"pagebuilder\":\"pagebuilder\"}', '[\"pagebuilder\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10060', 'JSN PageBuilder extended - Default Elements', 'plugin', 'defaultelements', 'jsnpagebuilder', '0', '1', '1', '1', '{\"name\":\"JSN PageBuilder extended - Default Elements\",\"type\":\"plugin\",\"creationDate\":\"10/10/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"1.3.2\",\"description\":\"All Default JSN PageBuilder Elements\",\"group\":\"\",\"filename\":\"defaultelements\",\"dependency\":[\"pagebuilder\"]}', '{\"pagebuilder\":\"pagebuilder\"}', '[\"pagebuilder\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10061', 'JSN PageBuilder extended - Content Search', 'plugin', 'jsnpagebuildersearch', 'search', '0', '1', '1', '1', '{\"name\":\"JSN PageBuilder extended - Content Search\",\"type\":\"plugin\",\"creationDate\":\"10/10/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"1.3.2\",\"description\":\"JSN PageBuilder extended - Content Search\",\"group\":\"\",\"filename\":\"jsnpagebuildersearch\",\"dependency\":[\"pagebuilder\"]}', '{\"pagebuilder\":\"pagebuilder\"}', '[\"pagebuilder\"]', '', '0', '0000-00-00 00:00:00', '-9999', '0'),
('10062', 'JSN PageBuilder extended - K2 Search', 'plugin', 'jsnpagebuilderk2search', 'search', '0', '1', '1', '1', '{\"name\":\"JSN PageBuilder extended - K2 Search\",\"type\":\"plugin\",\"creationDate\":\"10/10/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"1.3.2\",\"description\":\"JSN PageBuilder extended - K2 Search\",\"group\":\"\",\"filename\":\"jsnpagebuilderk2search\",\"dependency\":[\"pagebuilder\"]}', '{\"pagebuilder\":\"pagebuilder\"}', '[\"pagebuilder\"]', '', '0', '0000-00-00 00:00:00', '-9999', '0'),
('10063', 'JSN PageBuilder Plugin Content', 'plugin', 'pagebuilder', 'content', '0', '1', '1', '1', '{\"name\":\"JSN PageBuilder Plugin Content\",\"type\":\"plugin\",\"creationDate\":\"10/10/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (C) @JOOMLASHINECOPYRIGHTYEAR@ JoomlaShine.com. All Rights Reserved.\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"1.3.2\",\"description\":\"\",\"group\":\"\",\"filename\":\"pagebuilder\",\"dependency\":[\"pagebuilder\"]}', '{\"pagebuilder\":\"pagebuilder\"}', '[\"pagebuilder\"]', '', '0', '0000-00-00 00:00:00', '0', '0');

INSERT INTO lal5d_extensions
(`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES 
('10064', 'Google Analytics Dashboard', 'module', 'mod_ga_dash', '', '1', '1', '2', '0', '{\"name\":\"Google Analytics Dashboard\",\"type\":\"module\",\"creationDate\":\"Oct 2014\",\"author\":\"Alin Marcu\",\"copyright\":\"Copyright (C) 2010 deconf.com. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"https:\\/\\/deconf.com\\/\",\"version\":\"2.7\",\"description\":\"\\t\\n\\t\\tFor more help and FAQ, go to <a href=\'https:\\/\\/deconf.com\\/google-analytics-dashboard-joomla\\/\' target=\'_blank\'>Google Analytics Dashboard for Joomla!<\\/a>.<br \\/>\\n\\t\",\"group\":\"\",\"filename\":\"mod_ga_dash\"}', '{\"ga_domain\":\"\",\"spacer4\":\"\",\"spacer6\":\"\",\"spacer2\":\"\",\"ga_chart_theme\":\"1\",\"spacer7\":\"\",\"ga_enable_map\":\"0\",\"ga_enable_traffic\":\"0\",\"ga_enable_pgd\":\"0\",\"ga_enable_rd\":\"0\",\"ga_enable_sd\":\"0\",\"spacer8\":\"\",\"ga_dash_cache\":\"3600\",\"spacer5\":\"\",\"spacer9\":\"\",\"spacer3\":\"\",\"spacer1\":\"\",\"ga_api_key\":\"\",\"ga_client_id\":\"\",\"ga_client_secret\":\"\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10065', 'GTranslate', 'module', 'mod_gtranslate', '', '0', '1', '0', '0', '{\"name\":\"GTranslate\",\"type\":\"module\",\"creationDate\":\"September 2010\",\"author\":\"Edvard Ananyan\",\"copyright\":\"Copyright (C) 2008 - 2015 Edvard Ananyan. All rights reserved.\",\"authorEmail\":\"edo888@gmail.com\",\"authorUrl\":\"http:\\/\\/gtranslate.net\",\"version\":\"3.0.35\",\"description\":\"\\n    \\n    <span style=\'font-weight:normal;text-align:left;\'>\\n    <p>GTranslate - Makes your website multilingual and available to the world.<\\/p>\\n    <p><i>Ugrade to <a href=\\\"http:\\/\\/gtranslate.net\\/features?xyz=997\\\" target=\\\"_blank\\\">GTranslate Enterprise<\\/a> and enable the following features:<\\/i><\\/p>\\n    <ul>\\n        <li><strong>Enable search engine indexing<\\/strong> - Search engines will index your translated pages which will increase international traffic.<\\/li>\\n        <li><strong>Search engine friendly<\\/strong> - The URL will change depending on a selected language e.g. es.domain.com for Spanish.<\\/li>\\n        <li><strong>Meta data translation<\\/strong> - Meta keywords and description will be translated which will increase translated keywords ranking in the search engines.<\\/li>\\n        <li><strong>Ability to edit translations<\\/strong> - You will be able to edit the translated texts directly from the front-end.<\\/li>\\n        <li><strong>Cache support<\\/strong> - Translations will be cached and make your translated pages to load faster.<\\/li>\\n        <li><strong><a href=\\\"http:\\/\\/gtranslate.net\\/translation-delivery-network\\\" target=\\\"_blank\\\">Translation Delivery Network<\\/a><\\/strong> - The translations will be delivered by our cloud network. No software is installed on your server.<\\/li>\\n        <li><strong>Centralized translation cache<\\/strong> - The quality of the translations cache will improve over time by using crowd sourced and professional translations.<\\/li>\\n        <li><strong>Seamless updates<\\/strong> - We care about further updates. You just enjoy the up to date service every day.<\\/li>\\n        <li><strong>URL Translation<\\/strong> - The URL will be translated which is very important for multilingual SEO.<\\/li>\\n        <li><strong>Ability to edit translated URLs<\\/strong> - You will be able to change the translated URL manually.<\\/li>\\n        <li><strong>Language hosting<\\/strong> - Host your language on top level country domain name to rank higher on local search engines results (ccTLD domain.es).<\\/li>\\n    <\\/ul>\\n\\n    <table border=\\\"0\\\" cellpadding=\\\"20\\\">\\n    <tr>\\n    <td>\\n    <h3>Tour Video<\\/h3>\\n    <iframe src=\\\"http:\\/\\/player.vimeo.com\\/video\\/30132555?title=1&amp;byline=0&amp;portrait=0\\\" width=\\\"568\\\" height=\\\"360\\\" frameborder=\\\"0\\\" webkitAllowFullScreen mozallowfullscreen allowFullScreen><\\/iframe>\\n    <\\/td>\\n    <td>\\n    <h3>Translation Delivery Network<\\/h3>\\n    <iframe src=\\\"http:\\/\\/player.vimeo.com\\/video\\/38686858?title=1&amp;byline=0&amp;portrait=0\\\" width=\\\"568\\\" height=\\\"360\\\" frameborder=\\\"0\\\" webkitAllowFullScreen mozallowfullscreen allowFullScreen><\\/iframe>\\n    <\\/td>\\n    <\\/tr>\\n    <\\/table>\\n\\n    <p><a href=\'http:\\/\\/gtranslate.net\\/docs\\/54-joomla-module-documentation\' target=\'_blank\' class=\'btn btn-large btn-info\'><i class=\'icon-support\'><\\/i> Documentation<\\/a> &nbsp; <a href=\'http:\\/\\/extensions.joomla.org\\/extensions\\/extension\\/languages\\/automatic-translations\\/gtranslate#reviews\' target=\'_blank\' class=\'btn btn-large btn-warning\'><i class=\'icon-comments\'><\\/i> Reviews<\\/a><\\/p>\\n    <p><b>Version: 3.0.35<\\/b><br\\/>Copyright &copy; 2008 - 2015 Edvard Ananyan, All rights reserved. <a href=\'http:\\/\\/gtranslate.net\' target=\'_blank\'><b>http:\\/\\/gtranslate.net<\\/b><\\/a><\\/p>\\n    <\\/span>\\n    \\n    \",\"group\":\"\",\"filename\":\"mod_gtranslate\"}', '{\"moduleclass_sfx\":\"\",\"pro_version\":\"0\",\"enterprise_version\":\"0\",\"method\":\"onfly\",\"look\":\"both\",\"flag_size\":\"16\",\"orientation\":\"h\",\"new_tab\":\"0\",\"analytics\":\"0\",\"language\":\"en\",\"show_af\":\"1\",\"show_sq\":\"1\",\"show_ar\":\"1\",\"show_hy\":\"1\",\"show_az\":\"1\",\"show_eu\":\"1\",\"show_be\":\"1\",\"show_bg\":\"1\",\"show_ca\":\"1\",\"show_zh-CN\":\"1\",\"show_zh-TW\":\"1\",\"show_hr\":\"1\",\"show_cs\":\"1\",\"show_da\":\"1\",\"show_nl\":\"1\",\"show_en\":\"2\",\"show_et\":\"1\",\"show_tl\":\"1\",\"show_fi\":\"1\",\"show_fr\":\"2\",\"show_gl\":\"1\",\"show_ka\":\"1\",\"show_de\":\"2\",\"show_el\":\"1\",\"show_ht\":\"1\",\"show_iw\":\"1\",\"show_hi\":\"1\",\"show_hu\":\"1\",\"show_is\":\"1\",\"show_id\":\"1\",\"show_ga\":\"1\",\"show_it\":\"2\",\"show_ja\":\"1\",\"show_ko\":\"1\",\"show_lv\":\"1\",\"show_lt\":\"1\",\"show_mk\":\"1\",\"show_ms\":\"1\",\"show_mt\":\"1\",\"show_no\":\"1\",\"show_fa\":\"1\",\"show_pl\":\"1\",\"show_pt\":\"2\",\"show_ro\":\"1\",\"show_ru\":\"2\",\"show_sr\":\"1\",\"show_sk\":\"1\",\"show_sl\":\"1\",\"show_es\":\"2\",\"show_sw\":\"1\",\"show_sv\":\"1\",\"show_th\":\"1\",\"show_tr\":\"1\",\"show_uk\":\"1\",\"show_ur\":\"1\",\"show_vi\":\"1\",\"show_cy\":\"1\",\"show_yi\":\"1\",\"show_bn\":\"0\",\"show_bs\":\"0\",\"show_ceb\":\"0\",\"show_eo\":\"0\",\"show_gu\":\"0\",\"show_ha\":\"0\",\"show_hmn\":\"0\",\"show_ig\":\"0\",\"show_jw\":\"0\",\"show_kn\":\"0\",\"show_km\":\"0\",\"show_lo\":\"0\",\"show_la\":\"0\",\"show_mi\":\"0\",\"show_mr\":\"0\",\"show_mn\":\"0\",\"show_ne\":\"0\",\"show_pa\":\"0\",\"show_so\":\"0\",\"show_ta\":\"0\",\"show_te\":\"0\",\"show_yo\":\"0\",\"show_zu\":\"0\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10066', 'Theme Grid', 'plugin', 'themegrid', 'jsnimageshow', '0', '1', '1', '0', '{\"name\":\"Theme Grid\",\"type\":\"plugin\",\"creationDate\":\"11\\/07\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"1.2.3\",\"description\":\"JSN IMAGESHOW SHOWCASE THEME GRID PLUGIN\",\"group\":\"\",\"filename\":\"themegrid\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10067', 'Theme Slider', 'plugin', 'themeslider', 'jsnimageshow', '0', '1', '1', '0', '{\"name\":\"Theme Slider\",\"type\":\"plugin\",\"creationDate\":\"11\\/07\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"1.2.6\",\"description\":\"JSN IMAGESHOW SHOWCASE THEME SLIDER PLUGIN\",\"group\":\"\",\"filename\":\"themeslider\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10068', 'Theme Carousel', 'plugin', 'themecarousel', 'jsnimageshow', '0', '1', '1', '0', '{\"name\":\"Theme Carousel\",\"type\":\"plugin\",\"creationDate\":\"11\\/07\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"1.1.4\",\"description\":\"JSN IMAGESHOW SHOWCASE THEME CAROUSEL PLUGIN\",\"group\":\"\",\"filename\":\"themecarousel\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10069', 'Theme Flow', 'plugin', 'themeflow', 'jsnimageshow', '0', '1', '1', '0', '{\"name\":\"Theme Flow\",\"type\":\"plugin\",\"creationDate\":\"11\\/07\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"1.1.3\",\"description\":\"JSN IMAGESHOW SHOWCASE THEME FLOW PLUGIN\",\"group\":\"\",\"filename\":\"themeflow\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10070', 'Theme Strip', 'plugin', 'themestrip', 'jsnimageshow', '0', '1', '1', '0', '{\"name\":\"Theme Strip\",\"type\":\"plugin\",\"creationDate\":\"11\\/07\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"1.1.3\",\"description\":\"JSN IMAGESHOW SHOWCASE THEME STRIP PLUGIN\",\"group\":\"\",\"filename\":\"themestrip\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10071', 'PowerAdmin', 'component', 'com_poweradmin', '', '1', '1', '0', '0', '{\"name\":\"PowerAdmin\",\"type\":\"component\",\"creationDate\":\"10\\/19\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2015 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"2.4.4\",\"description\":\"JSN PowerAdmin\",\"group\":\"\",\"filename\":\"poweradmin\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10072', 'System - JSN PowerAdmin', 'plugin', 'jsnpoweradmin', 'system', '0', '1', '1', '1', '{\"name\":\"System - JSN PowerAdmin\",\"type\":\"plugin\",\"creationDate\":\"10/19/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"2.4.4\",\"description\":\"System - JSN PowerAdmin plugin\",\"group\":\"\",\"filename\":\"jsnpoweradmin\",\"dependency\":[\"poweradmin\"]}', '{\"poweradmin\":\"poweradmin\"}', '[\"poweradmin\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10073', 'JSN PowerAdmin extended - com_content', 'plugin', 'content', 'jsnpoweradmin', '0', '1', '1', '0', '{\"name\":\"JSN PowerAdmin extended - com_content\",\"type\":\"plugin\",\"creationDate\":\"10/19/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"2.4.4\",\"description\":\"Support view for com_content in site manager (from PowerAdmin 1.3.0)\",\"group\":\"\",\"filename\":\"content\",\"dependency\":[\"poweradmin\"]}', '{\"poweradmin\":\"poweradmin\"}', '[\"poweradmin\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10074', 'JSN PowerAdmin extended - com_contact', 'plugin', 'contact', 'jsnpoweradmin', '0', '1', '1', '0', '{\"name\":\"JSN PowerAdmin extended - com_contact\",\"type\":\"plugin\",\"creationDate\":\"10/19/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"2.4.4\",\"description\":\"Support view for com_contact in site manager (from PowerAdmin 2.0)\",\"group\":\"\",\"filename\":\"contact\",\"dependency\":[\"poweradmin\"]}', '{\"poweradmin\":\"poweradmin\"}', '[\"poweradmin\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10075', 'JSN PowerAdmin extended - com_users', 'plugin', 'users', 'jsnpoweradmin', '0', '1', '1', '0', '{\"name\":\"JSN PowerAdmin extended - com_users\",\"type\":\"plugin\",\"creationDate\":\"10/19/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"2.4.4\",\"description\":\"Support view for com_users in site manager (from PowerAdmin 2.0)\",\"group\":\"\",\"filename\":\"users\",\"dependency\":[\"poweradmin\"]}', '{\"poweradmin\":\"poweradmin\"}', '[\"poweradmin\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10076', 'JSN PowerAdmin extended - com_weblinks', 'plugin', 'weblinks', 'jsnpoweradmin', '0', '1', '1', '0', '{\"name\":\"JSN PowerAdmin extended - com_weblinks\",\"type\":\"plugin\",\"creationDate\":\"10/19/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"2.4.4\",\"description\":\"Support view for com_weblinks in site manager (from PowerAdmin 2.0)\",\"group\":\"\",\"filename\":\"weblinks\",\"dependency\":[\"poweradmin\"]}', '{\"poweradmin\":\"poweradmin\"}', '[\"poweradmin\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10077', 'JSN PowerAdmin extended - com_pagebuilder', 'plugin', 'pagebuilder', 'jsnpoweradmin', '0', '1', '1', '0', '{\"name\":\"JSN PowerAdmin extended - com_pagebuilder\",\"type\":\"plugin\",\"creationDate\":\"10/19/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"2.4.4\",\"description\":\"Support view for com_pagebuilder in site manager\",\"group\":\"\",\"filename\":\"pagebuilder\",\"dependency\":[\"poweradmin\"]}', '{\"poweradmin\":\"poweradmin\"}', '[\"poweradmin\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10078', 'mod_poweradmin', 'module', 'mod_poweradmin', '', '1', '1', '2', '0', '{\"name\":\"mod_poweradmin\",\"type\":\"module\",\"creationDate\":\"10/19/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"2.4.4\",\"description\":\"JSN PowerAdmin Quick Icons\",\"group\":\"\",\"filename\":\"mod_poweradmin\",\"dependency\":[\"poweradmin\"]}', '{\"poweradmin\":\"poweradmin\"}', '[\"poweradmin\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10079', 'UniForm', 'component', 'com_uniform', '', '1', '1', '0', '0', '{\"name\":\"UniForm\",\"type\":\"component\",\"creationDate\":\"10\\/27\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2016 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"4.0.4\",\"description\":\"JSN UniForm FREE \\u2013 A very simple solution to build forms for your Joomla website.\",\"group\":\"\",\"filename\":\"uniform\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10080', 'JSN UniForm', 'module', 'mod_uniform', '', '0', '1', '0', '1', '{\"name\":\"JSN UniForm\",\"type\":\"module\",\"creationDate\":\"10/27/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (C) 2016 JoomlaShine.com. All Rights Reserved.\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"4.0.4\",\"description\":\"JSN_UNIFORM_MODULE_DES\",\"group\":\"\",\"filename\":\"mod_uniform\",\"dependency\":[\"uniform\"]}', '{\"uniform\":\"uniform\"}', '[\"uniform\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10081', 'JSN_UNIFORM_PLUGIN_CONTENT_TITLE', 'plugin', 'uniform', 'content', '0', '1', '1', '1', '{\"name\":\"JSN_UNIFORM_PLUGIN_CONTENT_TITLE\",\"type\":\"plugin\",\"creationDate\":\"10/27/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (C) 2016 JoomlaShine.com. All Rights Reserved.\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"4.0.4\",\"description\":\"JSN_UNIFORM_PLUGIN_CONTENT_DES\",\"group\":\"\",\"filename\":\"uniform\",\"dependency\":[\"uniform\"]}', '{\"uniform\":\"uniform\"}', '[\"uniform\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10082', 'JSN_UNIFORM_PLUGIN_BUTTON_TITLE', 'plugin', 'uniform', 'editors-xtd', '0', '1', '1', '1', '{\"name\":\"JSN_UNIFORM_PLUGIN_BUTTON_TITLE\",\"type\":\"plugin\",\"creationDate\":\"10/27/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (C) 2016 JoomlaShine.com. All Rights Reserved.\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"4.0.4\",\"description\":\"JSN_UNIFORM_PLUGIN_BUTTON_DES\",\"group\":\"\",\"filename\":\"uniform\",\"dependency\":[\"uniform\"]}', '{\"uniform\":\"uniform\"}', '[\"uniform\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10083', 'System - JSN Uniform', 'plugin', 'uniform', 'system', '0', '1', '1', '0', '{\"name\":\"System - JSN Uniform\",\"type\":\"plugin\",\"creationDate\":\"10/27/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2015 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"4.0.4\",\"description\":\"System - JSN Uniform\",\"group\":\"\",\"filename\":\"uniform\",\"dependency\":[\"uniform\"]}', '{\"uniform\":\"uniform\"}', '[\"uniform\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10084', 'Mobilize', 'component', 'com_mobilize', '', '1', '1', '0', '0', '{\"name\":\"Mobilize\",\"type\":\"component\",\"creationDate\":\"07\\/22\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"1.2.1\",\"description\":\"JSN Mobilize\",\"group\":\"\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10085', 'jsn_mobilize', 'template', 'jsn_mobilize', '', '0', '0', '1', '1', '{\"name\":\"jsn_mobilize\",\"type\":\"template\",\"creationDate\":\"August 29, 2012\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"1.2.1\",\"description\":\"TPL_MOBILIZE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\",\"dependency\":[\"mobilize\"]}', '{\"mobilize\":\"mobilize\"}', '[\"mobilize\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10086', 'plg_system_jsnmobilize', 'plugin', 'jsnmobilize', 'system', '0', '1', '1', '1', '{\"name\":\"plg_system_jsnmobilize\",\"type\":\"plugin\",\"creationDate\":\"07/22/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2012 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"1.2.1\",\"description\":\"PLG_SYSTEM_JSNMOBILIZE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"jsnmobilize\",\"dependency\":[\"mobilize\"]}', '{\"mobilize\":\"mobilize\"}', '[\"mobilize\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10087', 'EasySlider', 'component', 'com_easyslider', '', '1', '1', '0', '0', '{\"name\":\"EasySlider\",\"type\":\"component\",\"creationDate\":\"05\\/27\\/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (C) 2015 JoomlaShine.com. All Rights Reserved.\",\"authorEmail\":\"support@joomlashine.com\",\"authorUrl\":\"http:\\/\\/www.joomlashine.com\",\"version\":\"2.1.3\",\"description\":\"JSN EasySlider Component\",\"group\":\"\"}', '{}', '', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10088', 'PLG_SYSTEM_JSNEASYSLIDER', 'plugin', 'easyslider', 'system', '0', '1', '1', '1', '{\"name\":\"PLG_SYSTEM_JSNEASYSLIDER\",\"type\":\"plugin\",\"creationDate\":\"05/27/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (C) 2013 JoomlaShine.com. All Rights Reserved.\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"2.1.3\",\"description\":\"PLG_SYSTEM_JSNEASYSLIDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"easyslider\",\"dependency\":[\"easyslider\"]}', '{\"easyslider\":\"easyslider\"}', '[\"easyslider\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10089', 'JSN EasySlider', 'module', 'mod_easyslider', '', '0', '1', '0', '1', '{\"name\":\"JSN EasySlider\",\"type\":\"module\",\"creationDate\":\"05/27/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (c) 2008 - 2013 - JoomlaShine.com\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"http://www.joomlashine.com\",\"version\":\"2.1.3\",\"description\":\"JSN_MODULE_JSN_EASYSLIDER_MODULE\",\"group\":\"\",\"filename\":\"mod_easyslider\",\"dependency\":[\"easyslider\"]}', '{\"easyslider\":\"easyslider\"}', '[\"easyslider\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10090', 'JSN_EASYSLIDER_PLUGIN_BUTTON_TITLE', 'plugin', 'jsneasyslider', 'editors-xtd', '0', '1', '1', '1', '{\"name\":\"JSN_EASYSLIDER_PLUGIN_BUTTON_TITLE\",\"type\":\"plugin\",\"creationDate\":\"05/27/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"2.1.3\",\"description\":\"JSN_EASYSLIDER_PLUGIN_BUTTON_DESC\",\"group\":\"\",\"filename\":\"jsneasyslider\",\"dependency\":[\"easyslider\"]}', '{\"easyslider\":\"easyslider\"}', '[\"easyslider\"]', '', '0', '0000-00-00 00:00:00', '0', '0'),
('10091', 'JSN_EASYSLIDER_PLUGIN_CONTENT_TITLE', 'plugin', 'jsneasyslider', 'content', '0', '1', '1', '1', '{\"name\":\"JSN_EASYSLIDER_PLUGIN_CONTENT_TITLE\",\"type\":\"plugin\",\"creationDate\":\"05/27/2016\",\"author\":\"JoomlaShine.com\",\"copyright\":\"Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.\",\"authorEmail\":\"admin@joomlashine.com\",\"authorUrl\":\"www.joomlashine.com\",\"version\":\"2.1.3\",\"description\":\"JSN_EASYSLIDER_PLUGIN_CONTENT_DESC\",\"group\":\"\",\"filename\":\"jsneasyslider\",\"dependency\":[\"easyslider\"]}', '{\"easyslider\":\"easyslider\"}', '[\"easyslider\"]', '', '0', '0000-00-00 00:00:00', '0', '0');

DROP TABLE IF EXISTS `lal5d_finder_filters`;
CREATE TABLE `lal5d_finder_filters` (
  `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext,
  PRIMARY KEY (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lal5d_finder_links`;
CREATE TABLE `lal5d_finder_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(400) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_title` (`title`(100)),
  KEY `idx_md5` (`md5sum`),
  KEY `idx_url` (`url`(75)),
  KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links
(`link_id`, `url`, `route`, `title`, `description`, `indexdate`, `md5sum`, `published`, `state`, `access`, `language`, `publish_start_date`, `publish_end_date`, `start_date`, `end_date`, `list_price`, `sale_price`, `type_id`, `object`) VALUES 
('5', 'index.php?option=com_content&view=category&id=8', '', 'Color Variation', '', '2016-11-14 20:30:30', '20d735e04d73b721b0046ddc07c6473c', '1', '0', '1', '*', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2016-11-12 06:44:12', '0000-00-00 00:00:00', '0', '0', '2', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:18:{s:2:\"id\";s:1:\"8\";s:5:\"alias\";s:15:\"color-variation\";s:7:\"summary\";s:0:\"\";s:9:\"extension\";s:11:\"com_content\";s:10:\"created_by\";s:3:\"602\";s:8:\"modified\";s:19:\"2016-11-12 06:44:12\";s:11:\"modified_by\";s:1:\"0\";s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":2:{s:6:\"author\";s:0:\"\";s:6:\"robots\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:3:\"lft\";s:2:\"11\";s:9:\"parent_id\";s:1:\"1\";s:5:\"level\";s:1:\"1\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":3:{s:15:\"category_layout\";s:0:\"\";s:5:\"image\";s:0:\"\";s:9:\"image_alt\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:4:\"slug\";s:17:\"8:color-variation\";s:6:\"layout\";s:8:\"category\";s:10:\"metaauthor\";N;s:4:\"path\";s:0:\"\";}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:4:\"link\";i:4;s:7:\"metakey\";i:5;s:8:\"metadesc\";i:6;s:10:\"metaauthor\";i:7;s:6:\"author\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:2:{s:4:\"Type\";a:1:{s:8:\"Category\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:8:\"Category\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:47:\"index.php?option=com_content&view=category&id=8\";s:5:\"route\";s:0:\"\";s:5:\"title\";s:15:\"Color Variation\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:0;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"0000-00-00 00:00:00\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:44:12\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:2;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('7', 'index.php?option=com_newsfeeds&view=category&id=9', 'index.php?option=com_newsfeeds&view=category&id=9&Itemid=101', 'Black Silver Color', '', '2016-11-12 12:18:20', '1700eae2aadc902ad4d970a2b02d55ce', '1', '1', '1', '*', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2016-11-12 06:48:19', '0000-00-00 00:00:00', '0', '0', '2', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:18:{s:2:\"id\";s:1:\"9\";s:5:\"alias\";s:18:\"black-silver-color\";s:7:\"summary\";s:0:\"\";s:9:\"extension\";s:13:\"com_newsfeeds\";s:10:\"created_by\";s:3:\"602\";s:8:\"modified\";s:19:\"2016-11-12 06:48:19\";s:11:\"modified_by\";s:1:\"0\";s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":2:{s:6:\"author\";s:0:\"\";s:6:\"robots\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:3:\"lft\";s:2:\"13\";s:9:\"parent_id\";s:1:\"1\";s:5:\"level\";s:1:\"1\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":3:{s:15:\"category_layout\";s:0:\"\";s:5:\"image\";s:0:\"\";s:9:\"image_alt\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:4:\"slug\";s:20:\"9:black-silver-color\";s:6:\"layout\";s:8:\"category\";s:10:\"metaauthor\";N;s:4:\"path\";s:70:\"index.php/component/newsfeeds/category/9-black-silver-color?Itemid=101\";}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:4:\"link\";i:4;s:7:\"metakey\";i:5;s:8:\"metadesc\";i:6;s:10:\"metaauthor\";i:7;s:6:\"author\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:2:{s:4:\"Type\";a:1:{s:8:\"Category\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:8:\"Category\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:49:\"index.php?option=com_newsfeeds&view=category&id=9\";s:5:\"route\";s:60:\"index.php?option=com_newsfeeds&view=category&id=9&Itemid=101\";s:5:\"title\";s:18:\"Black Silver Color\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:1;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"0000-00-00 00:00:00\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:48:19\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:2;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('8', 'index.php?option=com_newsfeeds&view=category&id=10', 'index.php?option=com_newsfeeds&view=category&id=10&Itemid=101', 'Silver Black Color', '', '2016-11-12 12:18:47', '342b1fb610efd23cf47396db875d137f', '1', '1', '1', '*', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2016-11-12 06:48:46', '0000-00-00 00:00:00', '0', '0', '2', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:18:{s:2:\"id\";s:2:\"10\";s:5:\"alias\";s:18:\"silver-black-color\";s:7:\"summary\";s:0:\"\";s:9:\"extension\";s:13:\"com_newsfeeds\";s:10:\"created_by\";s:3:\"602\";s:8:\"modified\";s:19:\"2016-11-12 06:48:46\";s:11:\"modified_by\";s:1:\"0\";s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":2:{s:6:\"author\";s:0:\"\";s:6:\"robots\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:3:\"lft\";s:2:\"15\";s:9:\"parent_id\";s:1:\"1\";s:5:\"level\";s:1:\"1\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":3:{s:15:\"category_layout\";s:0:\"\";s:5:\"image\";s:0:\"\";s:9:\"image_alt\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:4:\"slug\";s:21:\"10:silver-black-color\";s:6:\"layout\";s:8:\"category\";s:10:\"metaauthor\";N;s:4:\"path\";s:71:\"index.php/component/newsfeeds/category/10-silver-black-color?Itemid=101\";}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:4:\"link\";i:4;s:7:\"metakey\";i:5;s:8:\"metadesc\";i:6;s:10:\"metaauthor\";i:7;s:6:\"author\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:2:{s:4:\"Type\";a:1:{s:8:\"Category\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:8:\"Category\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:50:\"index.php?option=com_newsfeeds&view=category&id=10\";s:5:\"route\";s:61:\"index.php?option=com_newsfeeds&view=category&id=10&Itemid=101\";s:5:\"title\";s:18:\"Silver Black Color\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:1;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"0000-00-00 00:00:00\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:48:46\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:2;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('9', 'index.php?option=com_newsfeeds&view=category&id=11', 'index.php?option=com_newsfeeds&view=category&id=11&Itemid=101', 'Black Red Color', '', '2016-11-12 12:26:23', '47dd4835e28d1ffef91f1c4480a07de4', '1', '1', '1', '*', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2016-11-12 06:56:22', '0000-00-00 00:00:00', '0', '0', '2', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:18:{s:2:\"id\";s:2:\"11\";s:5:\"alias\";s:15:\"black-red-color\";s:7:\"summary\";s:0:\"\";s:9:\"extension\";s:13:\"com_newsfeeds\";s:10:\"created_by\";s:3:\"602\";s:8:\"modified\";s:19:\"2016-11-12 06:56:22\";s:11:\"modified_by\";s:1:\"0\";s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":2:{s:6:\"author\";s:0:\"\";s:6:\"robots\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:3:\"lft\";s:2:\"17\";s:9:\"parent_id\";s:1:\"1\";s:5:\"level\";s:1:\"1\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":3:{s:15:\"category_layout\";s:0:\"\";s:5:\"image\";s:0:\"\";s:9:\"image_alt\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:4:\"slug\";s:18:\"11:black-red-color\";s:6:\"layout\";s:8:\"category\";s:10:\"metaauthor\";N;s:4:\"path\";s:68:\"index.php/component/newsfeeds/category/11-black-red-color?Itemid=101\";}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:4:\"link\";i:4;s:7:\"metakey\";i:5;s:8:\"metadesc\";i:6;s:10:\"metaauthor\";i:7;s:6:\"author\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:2:{s:4:\"Type\";a:1:{s:8:\"Category\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:8:\"Category\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:50:\"index.php?option=com_newsfeeds&view=category&id=11\";s:5:\"route\";s:61:\"index.php?option=com_newsfeeds&view=category&id=11&Itemid=101\";s:5:\"title\";s:15:\"Black Red Color\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:1;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"0000-00-00 00:00:00\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:56:22\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:2;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('10', 'index.php?option=com_newsfeeds&view=category&id=12', 'index.php?option=com_newsfeeds&view=category&id=12&Itemid=101', 'Red Black Color', '', '2016-11-12 12:27:02', '7136f866112d9d15bba70f0033f151e2', '1', '1', '1', '*', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2016-11-12 06:57:01', '0000-00-00 00:00:00', '0', '0', '2', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:18:{s:2:\"id\";s:2:\"12\";s:5:\"alias\";s:15:\"red-black-color\";s:7:\"summary\";s:0:\"\";s:9:\"extension\";s:13:\"com_newsfeeds\";s:10:\"created_by\";s:3:\"602\";s:8:\"modified\";s:19:\"2016-11-12 06:57:01\";s:11:\"modified_by\";s:1:\"0\";s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":2:{s:6:\"author\";s:0:\"\";s:6:\"robots\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:3:\"lft\";s:2:\"19\";s:9:\"parent_id\";s:1:\"1\";s:5:\"level\";s:1:\"1\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":3:{s:15:\"category_layout\";s:0:\"\";s:5:\"image\";s:0:\"\";s:9:\"image_alt\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:4:\"slug\";s:18:\"12:red-black-color\";s:6:\"layout\";s:8:\"category\";s:10:\"metaauthor\";N;s:4:\"path\";s:68:\"index.php/component/newsfeeds/category/12-red-black-color?Itemid=101\";}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:4:\"link\";i:4;s:7:\"metakey\";i:5;s:8:\"metadesc\";i:6;s:10:\"metaauthor\";i:7;s:6:\"author\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:2:{s:4:\"Type\";a:1:{s:8:\"Category\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:8:\"Category\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:50:\"index.php?option=com_newsfeeds&view=category&id=12\";s:5:\"route\";s:61:\"index.php?option=com_newsfeeds&view=category&id=12&Itemid=101\";s:5:\"title\";s:15:\"Red Black Color\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:1;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"0000-00-00 00:00:00\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:57:01\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:2;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('11', 'index.php?option=com_newsfeeds&view=category&id=13', 'index.php?option=com_newsfeeds&view=category&id=13&Itemid=101', 'Black Blue Color', '', '2016-11-12 12:28:22', 'e0343b427a6b8f8c30ca20a1eb2d28b4', '1', '1', '1', '*', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2016-11-12 06:58:22', '0000-00-00 00:00:00', '0', '0', '2', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:18:{s:2:\"id\";s:2:\"13\";s:5:\"alias\";s:16:\"black-blue-color\";s:7:\"summary\";s:0:\"\";s:9:\"extension\";s:13:\"com_newsfeeds\";s:10:\"created_by\";s:3:\"602\";s:8:\"modified\";s:19:\"2016-11-12 06:58:22\";s:11:\"modified_by\";s:1:\"0\";s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":2:{s:6:\"author\";s:0:\"\";s:6:\"robots\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:3:\"lft\";s:2:\"21\";s:9:\"parent_id\";s:1:\"1\";s:5:\"level\";s:1:\"1\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":3:{s:15:\"category_layout\";s:0:\"\";s:5:\"image\";s:0:\"\";s:9:\"image_alt\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:4:\"slug\";s:19:\"13:black-blue-color\";s:6:\"layout\";s:8:\"category\";s:10:\"metaauthor\";N;s:4:\"path\";s:69:\"index.php/component/newsfeeds/category/13-black-blue-color?Itemid=101\";}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:4:\"link\";i:4;s:7:\"metakey\";i:5;s:8:\"metadesc\";i:6;s:10:\"metaauthor\";i:7;s:6:\"author\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:2:{s:4:\"Type\";a:1:{s:8:\"Category\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:8:\"Category\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:50:\"index.php?option=com_newsfeeds&view=category&id=13\";s:5:\"route\";s:61:\"index.php?option=com_newsfeeds&view=category&id=13&Itemid=101\";s:5:\"title\";s:16:\"Black Blue Color\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:1;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"0000-00-00 00:00:00\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:58:22\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:2;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('12', 'index.php?option=com_newsfeeds&view=category&id=14', 'index.php?option=com_newsfeeds&view=category&id=14&Itemid=101', 'Blue Black Color', '', '2016-11-12 12:28:56', '39fa86bc6a0d9e87e82de0f7749cfe1f', '1', '1', '1', '*', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2016-11-12 06:58:45', '0000-00-00 00:00:00', '0', '0', '2', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:18:{s:2:\"id\";s:2:\"14\";s:5:\"alias\";s:16:\"blue-black-color\";s:7:\"summary\";s:0:\"\";s:9:\"extension\";s:13:\"com_newsfeeds\";s:10:\"created_by\";s:3:\"602\";s:8:\"modified\";s:19:\"2016-11-12 06:58:55\";s:11:\"modified_by\";s:3:\"602\";s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":2:{s:6:\"author\";s:0:\"\";s:6:\"robots\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:3:\"lft\";s:2:\"23\";s:9:\"parent_id\";s:1:\"1\";s:5:\"level\";s:1:\"1\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":3:{s:15:\"category_layout\";s:0:\"\";s:5:\"image\";s:0:\"\";s:9:\"image_alt\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:4:\"slug\";s:19:\"14:blue-black-color\";s:6:\"layout\";s:8:\"category\";s:10:\"metaauthor\";N;s:4:\"path\";s:69:\"index.php/component/newsfeeds/category/14-blue-black-color?Itemid=101\";}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:4:\"link\";i:4;s:7:\"metakey\";i:5;s:8:\"metadesc\";i:6;s:10:\"metaauthor\";i:7;s:6:\"author\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:2:{s:4:\"Type\";a:1:{s:8:\"Category\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:8:\"Category\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:50:\"index.php?option=com_newsfeeds&view=category&id=14\";s:5:\"route\";s:61:\"index.php?option=com_newsfeeds&view=category&id=14&Itemid=101\";s:5:\"title\";s:16:\"Blue Black Color\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:1;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"0000-00-00 00:00:00\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:58:45\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:2;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('13', 'index.php?option=com_content&view=article&id=2', 'index.php?option=com_content&view=article&id=2:color-variation&catid=2&Itemid=116', 'Color Variation', '', '2016-11-12 12:32:44', 'd4bcf37ea9a2567886f3c7250ab87733', '1', '0', '1', '*', '2016-11-12 06:23:48', '0000-00-00 00:00:00', '2016-11-12 06:23:48', '0000-00-00 00:00:00', '0', '0', '4', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:24:{s:2:\"id\";s:1:\"2\";s:5:\"alias\";s:15:\"color-variation\";s:7:\"summary\";s:0:\"\";s:4:\"body\";s:0:\"\";s:5:\"catid\";s:1:\"2\";s:10:\"created_by\";s:3:\"602\";s:16:\"created_by_alias\";s:0:\"\";s:8:\"modified\";s:19:\"2016-11-12 06:23:48\";s:11:\"modified_by\";s:1:\"0\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":69:{s:14:\"article_layout\";s:9:\"_:default\";s:10:\"show_title\";s:1:\"1\";s:11:\"link_titles\";s:1:\"1\";s:10:\"show_intro\";s:1:\"1\";s:13:\"show_category\";s:1:\"1\";s:13:\"link_category\";s:1:\"1\";s:20:\"show_parent_category\";s:1:\"0\";s:20:\"link_parent_category\";s:1:\"0\";s:11:\"show_author\";s:1:\"1\";s:11:\"link_author\";s:1:\"0\";s:16:\"show_create_date\";s:1:\"0\";s:16:\"show_modify_date\";s:1:\"0\";s:17:\"show_publish_date\";s:1:\"1\";s:20:\"show_item_navigation\";s:1:\"1\";s:9:\"show_vote\";s:1:\"0\";s:13:\"show_readmore\";s:1:\"1\";s:19:\"show_readmore_title\";s:1:\"1\";s:14:\"readmore_limit\";s:3:\"100\";s:10:\"show_icons\";s:1:\"1\";s:15:\"show_print_icon\";s:1:\"1\";s:15:\"show_email_icon\";s:1:\"1\";s:9:\"show_hits\";s:1:\"1\";s:11:\"show_noauth\";s:1:\"0\";s:23:\"show_publishing_options\";s:1:\"1\";s:20:\"show_article_options\";s:1:\"1\";s:12:\"save_history\";s:1:\"1\";s:13:\"history_limit\";i:10;s:25:\"show_urls_images_frontend\";s:1:\"0\";s:24:\"show_urls_images_backend\";s:1:\"1\";s:7:\"targeta\";i:0;s:7:\"targetb\";i:0;s:7:\"targetc\";i:0;s:11:\"float_intro\";s:4:\"left\";s:14:\"float_fulltext\";s:4:\"left\";s:15:\"category_layout\";s:6:\"_:blog\";s:19:\"show_category_title\";s:1:\"0\";s:16:\"show_description\";s:1:\"0\";s:22:\"show_description_image\";s:1:\"0\";s:8:\"maxLevel\";s:1:\"1\";s:21:\"show_empty_categories\";s:1:\"0\";s:16:\"show_no_articles\";s:1:\"1\";s:16:\"show_subcat_desc\";s:1:\"1\";s:21:\"show_cat_num_articles\";s:1:\"0\";s:21:\"show_base_description\";s:1:\"1\";s:11:\"maxLevelcat\";s:2:\"-1\";s:25:\"show_empty_categories_cat\";s:1:\"0\";s:20:\"show_subcat_desc_cat\";s:1:\"1\";s:25:\"show_cat_num_articles_cat\";s:1:\"1\";s:20:\"num_leading_articles\";s:1:\"1\";s:18:\"num_intro_articles\";s:1:\"4\";s:11:\"num_columns\";s:1:\"2\";s:9:\"num_links\";s:1:\"4\";s:18:\"multi_column_order\";s:1:\"0\";s:24:\"show_subcategory_content\";s:1:\"0\";s:21:\"show_pagination_limit\";s:1:\"1\";s:12:\"filter_field\";s:4:\"hide\";s:13:\"show_headings\";s:1:\"1\";s:14:\"list_show_date\";s:1:\"0\";s:11:\"date_format\";s:0:\"\";s:14:\"list_show_hits\";s:1:\"1\";s:16:\"list_show_author\";s:1:\"1\";s:11:\"orderby_pri\";s:5:\"order\";s:11:\"orderby_sec\";s:5:\"rdate\";s:10:\"order_date\";s:9:\"published\";s:15:\"show_pagination\";s:1:\"2\";s:23:\"show_pagination_results\";s:1:\"1\";s:14:\"show_feed_link\";s:1:\"1\";s:12:\"feed_summary\";s:1:\"0\";s:11:\"post_format\";s:8:\"standard\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":4:{s:6:\"robots\";s:0:\"\";s:6:\"author\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"xreference\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"version\";s:1:\"1\";s:8:\"ordering\";s:1:\"2\";s:8:\"category\";s:13:\"Uncategorised\";s:9:\"cat_state\";s:1:\"1\";s:10:\"cat_access\";s:1:\"1\";s:4:\"slug\";s:17:\"2:color-variation\";s:7:\"catslug\";s:15:\"2:uncategorised\";s:6:\"author\";s:10:\"Super User\";s:6:\"layout\";s:7:\"article\";s:4:\"path\";s:25:\"index.php/color-variation\";s:10:\"metaauthor\";N;}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:7:\"metakey\";i:4;s:8:\"metadesc\";i:5;s:10:\"metaauthor\";i:6;s:6:\"author\";i:7;s:16:\"created_by_alias\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:4:{s:4:\"Type\";a:1:{s:7:\"Article\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:7:\"Article\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:6:\"Author\";a:1:{s:10:\"Super User\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:10:\"Super User\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Category\";a:1:{s:13:\"Uncategorised\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:13:\"Uncategorised\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:46:\"index.php?option=com_content&view=article&id=2\";s:5:\"route\";s:81:\"index.php?option=com_content&view=article&id=2:color-variation&catid=2&Itemid=116\";s:5:\"title\";s:15:\"Color Variation\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:0;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"2016-11-12 06:23:48\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:23:48\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:4;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('18', 'index.php?option=com_content&view=article&id=7', 'index.php?option=com_content&view=article&id=7:home&catid=2&Itemid=101', 'Home', '', '2016-11-14 20:29:59', 'ad3d37c018aae049dced596d589c776c', '1', '0', '1', '*', '2016-11-14 14:57:40', '0000-00-00 00:00:00', '2016-11-14 14:57:40', '0000-00-00 00:00:00', '0', '0', '4', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:24:{s:2:\"id\";s:1:\"7\";s:5:\"alias\";s:4:\"home\";s:7:\"summary\";s:0:\"\";s:4:\"body\";s:0:\"\";s:5:\"catid\";s:1:\"2\";s:10:\"created_by\";s:3:\"602\";s:16:\"created_by_alias\";s:0:\"\";s:8:\"modified\";s:19:\"2016-11-14 14:57:40\";s:11:\"modified_by\";s:1:\"0\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":69:{s:14:\"article_layout\";s:9:\"_:default\";s:10:\"show_title\";s:1:\"1\";s:11:\"link_titles\";s:1:\"1\";s:10:\"show_intro\";s:1:\"1\";s:13:\"show_category\";s:1:\"1\";s:13:\"link_category\";s:1:\"1\";s:20:\"show_parent_category\";s:1:\"0\";s:20:\"link_parent_category\";s:1:\"0\";s:11:\"show_author\";s:1:\"1\";s:11:\"link_author\";s:1:\"0\";s:16:\"show_create_date\";s:1:\"0\";s:16:\"show_modify_date\";s:1:\"0\";s:17:\"show_publish_date\";s:1:\"1\";s:20:\"show_item_navigation\";s:1:\"1\";s:9:\"show_vote\";s:1:\"0\";s:13:\"show_readmore\";s:1:\"1\";s:19:\"show_readmore_title\";s:1:\"1\";s:14:\"readmore_limit\";s:3:\"100\";s:10:\"show_icons\";s:1:\"1\";s:15:\"show_print_icon\";s:1:\"1\";s:15:\"show_email_icon\";s:1:\"1\";s:9:\"show_hits\";s:1:\"1\";s:11:\"show_noauth\";s:1:\"0\";s:23:\"show_publishing_options\";s:1:\"1\";s:20:\"show_article_options\";s:1:\"1\";s:12:\"save_history\";s:1:\"1\";s:13:\"history_limit\";i:10;s:25:\"show_urls_images_frontend\";s:1:\"0\";s:24:\"show_urls_images_backend\";s:1:\"1\";s:7:\"targeta\";i:0;s:7:\"targetb\";i:0;s:7:\"targetc\";i:0;s:11:\"float_intro\";s:4:\"left\";s:14:\"float_fulltext\";s:4:\"left\";s:15:\"category_layout\";s:6:\"_:blog\";s:19:\"show_category_title\";s:1:\"0\";s:16:\"show_description\";s:1:\"0\";s:22:\"show_description_image\";s:1:\"0\";s:8:\"maxLevel\";s:1:\"1\";s:21:\"show_empty_categories\";s:1:\"0\";s:16:\"show_no_articles\";s:1:\"1\";s:16:\"show_subcat_desc\";s:1:\"1\";s:21:\"show_cat_num_articles\";s:1:\"0\";s:21:\"show_base_description\";s:1:\"1\";s:11:\"maxLevelcat\";s:2:\"-1\";s:25:\"show_empty_categories_cat\";s:1:\"0\";s:20:\"show_subcat_desc_cat\";s:1:\"1\";s:25:\"show_cat_num_articles_cat\";s:1:\"1\";s:20:\"num_leading_articles\";s:1:\"1\";s:18:\"num_intro_articles\";s:1:\"4\";s:11:\"num_columns\";s:1:\"2\";s:9:\"num_links\";s:1:\"4\";s:18:\"multi_column_order\";s:1:\"0\";s:24:\"show_subcategory_content\";s:1:\"0\";s:21:\"show_pagination_limit\";s:1:\"1\";s:12:\"filter_field\";s:4:\"hide\";s:13:\"show_headings\";s:1:\"1\";s:14:\"list_show_date\";s:1:\"0\";s:11:\"date_format\";s:0:\"\";s:14:\"list_show_hits\";s:1:\"1\";s:16:\"list_show_author\";s:1:\"1\";s:11:\"orderby_pri\";s:5:\"order\";s:11:\"orderby_sec\";s:5:\"rdate\";s:10:\"order_date\";s:9:\"published\";s:15:\"show_pagination\";s:1:\"2\";s:23:\"show_pagination_results\";s:1:\"1\";s:14:\"show_feed_link\";s:1:\"1\";s:12:\"feed_summary\";s:1:\"0\";s:11:\"post_format\";s:8:\"standard\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":4:{s:6:\"robots\";s:0:\"\";s:6:\"author\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"xreference\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"version\";s:1:\"1\";s:8:\"ordering\";s:1:\"0\";s:8:\"category\";s:13:\"Uncategorised\";s:9:\"cat_state\";s:1:\"1\";s:10:\"cat_access\";s:1:\"1\";s:4:\"slug\";s:6:\"7:home\";s:7:\"catslug\";s:15:\"2:uncategorised\";s:6:\"author\";s:10:\"Super User\";s:6:\"layout\";s:7:\"article\";s:4:\"path\";s:32:\"index.php/2-uncategorised/7-home\";s:10:\"metaauthor\";N;}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:7:\"metakey\";i:4;s:8:\"metadesc\";i:5;s:10:\"metaauthor\";i:6;s:6:\"author\";i:7;s:16:\"created_by_alias\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:4:{s:4:\"Type\";a:1:{s:7:\"Article\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:7:\"Article\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:6:\"Author\";a:1:{s:10:\"Super User\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:10:\"Super User\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Category\";a:1:{s:13:\"Uncategorised\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:13:\"Uncategorised\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:46:\"index.php?option=com_content&view=article&id=7\";s:5:\"route\";s:70:\"index.php?option=com_content&view=article&id=7:home&catid=2&Itemid=101\";s:5:\"title\";s:4:\"Home\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:0;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"2016-11-14 14:57:40\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-14 14:57:40\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:4;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('20', 'index.php?option=com_content&view=article&id=4', 'index.php?option=com_content&view=article&id=4:contact&catid=2&Itemid=118', 'Contact', '', '2016-11-14 20:30:02', '4c95696e50483b4a08b8aa1c0a1183c2', '1', '0', '1', '*', '2016-11-12 06:24:42', '0000-00-00 00:00:00', '2016-11-12 06:24:42', '0000-00-00 00:00:00', '0', '0', '4', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:24:{s:2:\"id\";s:1:\"4\";s:5:\"alias\";s:7:\"contact\";s:7:\"summary\";s:0:\"\";s:4:\"body\";s:0:\"\";s:5:\"catid\";s:1:\"2\";s:10:\"created_by\";s:3:\"602\";s:16:\"created_by_alias\";s:0:\"\";s:8:\"modified\";s:19:\"2016-11-12 06:24:42\";s:11:\"modified_by\";s:1:\"0\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":69:{s:14:\"article_layout\";s:9:\"_:default\";s:10:\"show_title\";s:1:\"1\";s:11:\"link_titles\";s:1:\"1\";s:10:\"show_intro\";s:1:\"1\";s:13:\"show_category\";s:1:\"1\";s:13:\"link_category\";s:1:\"1\";s:20:\"show_parent_category\";s:1:\"0\";s:20:\"link_parent_category\";s:1:\"0\";s:11:\"show_author\";s:1:\"1\";s:11:\"link_author\";s:1:\"0\";s:16:\"show_create_date\";s:1:\"0\";s:16:\"show_modify_date\";s:1:\"0\";s:17:\"show_publish_date\";s:1:\"1\";s:20:\"show_item_navigation\";s:1:\"1\";s:9:\"show_vote\";s:1:\"0\";s:13:\"show_readmore\";s:1:\"1\";s:19:\"show_readmore_title\";s:1:\"1\";s:14:\"readmore_limit\";s:3:\"100\";s:10:\"show_icons\";s:1:\"1\";s:15:\"show_print_icon\";s:1:\"1\";s:15:\"show_email_icon\";s:1:\"1\";s:9:\"show_hits\";s:1:\"1\";s:11:\"show_noauth\";s:1:\"0\";s:23:\"show_publishing_options\";s:1:\"1\";s:20:\"show_article_options\";s:1:\"1\";s:12:\"save_history\";s:1:\"1\";s:13:\"history_limit\";i:10;s:25:\"show_urls_images_frontend\";s:1:\"0\";s:24:\"show_urls_images_backend\";s:1:\"1\";s:7:\"targeta\";i:0;s:7:\"targetb\";i:0;s:7:\"targetc\";i:0;s:11:\"float_intro\";s:4:\"left\";s:14:\"float_fulltext\";s:4:\"left\";s:15:\"category_layout\";s:6:\"_:blog\";s:19:\"show_category_title\";s:1:\"0\";s:16:\"show_description\";s:1:\"0\";s:22:\"show_description_image\";s:1:\"0\";s:8:\"maxLevel\";s:1:\"1\";s:21:\"show_empty_categories\";s:1:\"0\";s:16:\"show_no_articles\";s:1:\"1\";s:16:\"show_subcat_desc\";s:1:\"1\";s:21:\"show_cat_num_articles\";s:1:\"0\";s:21:\"show_base_description\";s:1:\"1\";s:11:\"maxLevelcat\";s:2:\"-1\";s:25:\"show_empty_categories_cat\";s:1:\"0\";s:20:\"show_subcat_desc_cat\";s:1:\"1\";s:25:\"show_cat_num_articles_cat\";s:1:\"1\";s:20:\"num_leading_articles\";s:1:\"1\";s:18:\"num_intro_articles\";s:1:\"4\";s:11:\"num_columns\";s:1:\"2\";s:9:\"num_links\";s:1:\"4\";s:18:\"multi_column_order\";s:1:\"0\";s:24:\"show_subcategory_content\";s:1:\"0\";s:21:\"show_pagination_limit\";s:1:\"1\";s:12:\"filter_field\";s:4:\"hide\";s:13:\"show_headings\";s:1:\"1\";s:14:\"list_show_date\";s:1:\"0\";s:11:\"date_format\";s:0:\"\";s:14:\"list_show_hits\";s:1:\"1\";s:16:\"list_show_author\";s:1:\"1\";s:11:\"orderby_pri\";s:5:\"order\";s:11:\"orderby_sec\";s:5:\"rdate\";s:10:\"order_date\";s:9:\"published\";s:15:\"show_pagination\";s:1:\"2\";s:23:\"show_pagination_results\";s:1:\"1\";s:14:\"show_feed_link\";s:1:\"1\";s:12:\"feed_summary\";s:1:\"0\";s:11:\"post_format\";s:8:\"standard\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":4:{s:6:\"robots\";s:0:\"\";s:6:\"author\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"xreference\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"version\";s:1:\"1\";s:8:\"ordering\";s:1:\"1\";s:8:\"category\";s:13:\"Uncategorised\";s:9:\"cat_state\";s:1:\"1\";s:10:\"cat_access\";s:1:\"1\";s:4:\"slug\";s:9:\"4:contact\";s:7:\"catslug\";s:15:\"2:uncategorised\";s:6:\"author\";s:10:\"Super User\";s:6:\"layout\";s:7:\"article\";s:4:\"path\";s:17:\"index.php/contact\";s:10:\"metaauthor\";N;}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:7:\"metakey\";i:4;s:8:\"metadesc\";i:5;s:10:\"metaauthor\";i:6;s:6:\"author\";i:7;s:16:\"created_by_alias\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:4:{s:4:\"Type\";a:1:{s:7:\"Article\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:7:\"Article\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:6:\"Author\";a:1:{s:10:\"Super User\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:10:\"Super User\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Category\";a:1:{s:13:\"Uncategorised\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:13:\"Uncategorised\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:46:\"index.php?option=com_content&view=article&id=4\";s:5:\"route\";s:73:\"index.php?option=com_content&view=article&id=4:contact&catid=2&Itemid=118\";s:5:\"title\";s:7:\"Contact\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:0;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"2016-11-12 06:24:42\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:24:42\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:4;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('21', 'index.php?option=com_content&view=article&id=3', 'index.php?option=com_content&view=article&id=3:service&catid=2&Itemid=117', 'Service', '', '2016-11-14 20:30:04', 'a1c9e43b45f18c5f92bd048083cccd8e', '1', '0', '1', '*', '2016-11-12 06:24:19', '0000-00-00 00:00:00', '2016-11-12 06:24:19', '0000-00-00 00:00:00', '0', '0', '4', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:24:{s:2:\"id\";s:1:\"3\";s:5:\"alias\";s:7:\"service\";s:7:\"summary\";s:0:\"\";s:4:\"body\";s:0:\"\";s:5:\"catid\";s:1:\"2\";s:10:\"created_by\";s:3:\"602\";s:16:\"created_by_alias\";s:0:\"\";s:8:\"modified\";s:19:\"2016-11-12 06:24:19\";s:11:\"modified_by\";s:1:\"0\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":69:{s:14:\"article_layout\";s:9:\"_:default\";s:10:\"show_title\";s:1:\"1\";s:11:\"link_titles\";s:1:\"1\";s:10:\"show_intro\";s:1:\"1\";s:13:\"show_category\";s:1:\"1\";s:13:\"link_category\";s:1:\"1\";s:20:\"show_parent_category\";s:1:\"0\";s:20:\"link_parent_category\";s:1:\"0\";s:11:\"show_author\";s:1:\"1\";s:11:\"link_author\";s:1:\"0\";s:16:\"show_create_date\";s:1:\"0\";s:16:\"show_modify_date\";s:1:\"0\";s:17:\"show_publish_date\";s:1:\"1\";s:20:\"show_item_navigation\";s:1:\"1\";s:9:\"show_vote\";s:1:\"0\";s:13:\"show_readmore\";s:1:\"1\";s:19:\"show_readmore_title\";s:1:\"1\";s:14:\"readmore_limit\";s:3:\"100\";s:10:\"show_icons\";s:1:\"1\";s:15:\"show_print_icon\";s:1:\"1\";s:15:\"show_email_icon\";s:1:\"1\";s:9:\"show_hits\";s:1:\"1\";s:11:\"show_noauth\";s:1:\"0\";s:23:\"show_publishing_options\";s:1:\"1\";s:20:\"show_article_options\";s:1:\"1\";s:12:\"save_history\";s:1:\"1\";s:13:\"history_limit\";i:10;s:25:\"show_urls_images_frontend\";s:1:\"0\";s:24:\"show_urls_images_backend\";s:1:\"1\";s:7:\"targeta\";i:0;s:7:\"targetb\";i:0;s:7:\"targetc\";i:0;s:11:\"float_intro\";s:4:\"left\";s:14:\"float_fulltext\";s:4:\"left\";s:15:\"category_layout\";s:6:\"_:blog\";s:19:\"show_category_title\";s:1:\"0\";s:16:\"show_description\";s:1:\"0\";s:22:\"show_description_image\";s:1:\"0\";s:8:\"maxLevel\";s:1:\"1\";s:21:\"show_empty_categories\";s:1:\"0\";s:16:\"show_no_articles\";s:1:\"1\";s:16:\"show_subcat_desc\";s:1:\"1\";s:21:\"show_cat_num_articles\";s:1:\"0\";s:21:\"show_base_description\";s:1:\"1\";s:11:\"maxLevelcat\";s:2:\"-1\";s:25:\"show_empty_categories_cat\";s:1:\"0\";s:20:\"show_subcat_desc_cat\";s:1:\"1\";s:25:\"show_cat_num_articles_cat\";s:1:\"1\";s:20:\"num_leading_articles\";s:1:\"1\";s:18:\"num_intro_articles\";s:1:\"4\";s:11:\"num_columns\";s:1:\"2\";s:9:\"num_links\";s:1:\"4\";s:18:\"multi_column_order\";s:1:\"0\";s:24:\"show_subcategory_content\";s:1:\"0\";s:21:\"show_pagination_limit\";s:1:\"1\";s:12:\"filter_field\";s:4:\"hide\";s:13:\"show_headings\";s:1:\"1\";s:14:\"list_show_date\";s:1:\"0\";s:11:\"date_format\";s:0:\"\";s:14:\"list_show_hits\";s:1:\"1\";s:16:\"list_show_author\";s:1:\"1\";s:11:\"orderby_pri\";s:5:\"order\";s:11:\"orderby_sec\";s:5:\"rdate\";s:10:\"order_date\";s:9:\"published\";s:15:\"show_pagination\";s:1:\"2\";s:23:\"show_pagination_results\";s:1:\"1\";s:14:\"show_feed_link\";s:1:\"1\";s:12:\"feed_summary\";s:1:\"0\";s:11:\"post_format\";s:8:\"standard\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":4:{s:6:\"robots\";s:0:\"\";s:6:\"author\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"xreference\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"version\";s:1:\"1\";s:8:\"ordering\";s:1:\"2\";s:8:\"category\";s:13:\"Uncategorised\";s:9:\"cat_state\";s:1:\"1\";s:10:\"cat_access\";s:1:\"1\";s:4:\"slug\";s:9:\"3:service\";s:7:\"catslug\";s:15:\"2:uncategorised\";s:6:\"author\";s:10:\"Super User\";s:6:\"layout\";s:7:\"article\";s:4:\"path\";s:17:\"index.php/service\";s:10:\"metaauthor\";N;}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:7:\"metakey\";i:4;s:8:\"metadesc\";i:5;s:10:\"metaauthor\";i:6;s:6:\"author\";i:7;s:16:\"created_by_alias\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:4:{s:4:\"Type\";a:1:{s:7:\"Article\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:7:\"Article\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:6:\"Author\";a:1:{s:10:\"Super User\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:10:\"Super User\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Category\";a:1:{s:13:\"Uncategorised\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:13:\"Uncategorised\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:46:\"index.php?option=com_content&view=article&id=3\";s:5:\"route\";s:73:\"index.php?option=com_content&view=article&id=3:service&catid=2&Itemid=117\";s:5:\"title\";s:7:\"Service\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:0;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"2016-11-12 06:24:19\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:24:19\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:4;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('22', 'index.php?option=com_content&view=article&id=1', 'index.php?option=com_content&view=article&id=1:menu&catid=2&Itemid=101', 'Menu', '', '2016-11-14 20:30:05', 'b7bda04efc7aac7f7ab1165480386a1c', '1', '0', '1', '*', '2016-11-12 06:22:40', '0000-00-00 00:00:00', '2016-11-12 06:22:40', '0000-00-00 00:00:00', '0', '0', '4', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:24:{s:2:\"id\";s:1:\"1\";s:5:\"alias\";s:4:\"menu\";s:7:\"summary\";s:0:\"\";s:4:\"body\";s:0:\"\";s:5:\"catid\";s:1:\"2\";s:10:\"created_by\";s:3:\"602\";s:16:\"created_by_alias\";s:0:\"\";s:8:\"modified\";s:19:\"2016-11-12 06:22:40\";s:11:\"modified_by\";s:1:\"0\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":69:{s:14:\"article_layout\";s:9:\"_:default\";s:10:\"show_title\";s:1:\"1\";s:11:\"link_titles\";s:1:\"1\";s:10:\"show_intro\";s:1:\"1\";s:13:\"show_category\";s:1:\"1\";s:13:\"link_category\";s:1:\"1\";s:20:\"show_parent_category\";s:1:\"0\";s:20:\"link_parent_category\";s:1:\"0\";s:11:\"show_author\";s:1:\"1\";s:11:\"link_author\";s:1:\"0\";s:16:\"show_create_date\";s:1:\"0\";s:16:\"show_modify_date\";s:1:\"0\";s:17:\"show_publish_date\";s:1:\"1\";s:20:\"show_item_navigation\";s:1:\"1\";s:9:\"show_vote\";s:1:\"0\";s:13:\"show_readmore\";s:1:\"1\";s:19:\"show_readmore_title\";s:1:\"1\";s:14:\"readmore_limit\";s:3:\"100\";s:10:\"show_icons\";s:1:\"1\";s:15:\"show_print_icon\";s:1:\"1\";s:15:\"show_email_icon\";s:1:\"1\";s:9:\"show_hits\";s:1:\"1\";s:11:\"show_noauth\";s:1:\"0\";s:23:\"show_publishing_options\";s:1:\"1\";s:20:\"show_article_options\";s:1:\"1\";s:12:\"save_history\";s:1:\"1\";s:13:\"history_limit\";i:10;s:25:\"show_urls_images_frontend\";s:1:\"0\";s:24:\"show_urls_images_backend\";s:1:\"1\";s:7:\"targeta\";i:0;s:7:\"targetb\";i:0;s:7:\"targetc\";i:0;s:11:\"float_intro\";s:4:\"left\";s:14:\"float_fulltext\";s:4:\"left\";s:15:\"category_layout\";s:6:\"_:blog\";s:19:\"show_category_title\";s:1:\"0\";s:16:\"show_description\";s:1:\"0\";s:22:\"show_description_image\";s:1:\"0\";s:8:\"maxLevel\";s:1:\"1\";s:21:\"show_empty_categories\";s:1:\"0\";s:16:\"show_no_articles\";s:1:\"1\";s:16:\"show_subcat_desc\";s:1:\"1\";s:21:\"show_cat_num_articles\";s:1:\"0\";s:21:\"show_base_description\";s:1:\"1\";s:11:\"maxLevelcat\";s:2:\"-1\";s:25:\"show_empty_categories_cat\";s:1:\"0\";s:20:\"show_subcat_desc_cat\";s:1:\"1\";s:25:\"show_cat_num_articles_cat\";s:1:\"1\";s:20:\"num_leading_articles\";s:1:\"1\";s:18:\"num_intro_articles\";s:1:\"4\";s:11:\"num_columns\";s:1:\"2\";s:9:\"num_links\";s:1:\"4\";s:18:\"multi_column_order\";s:1:\"0\";s:24:\"show_subcategory_content\";s:1:\"0\";s:21:\"show_pagination_limit\";s:1:\"1\";s:12:\"filter_field\";s:4:\"hide\";s:13:\"show_headings\";s:1:\"1\";s:14:\"list_show_date\";s:1:\"0\";s:11:\"date_format\";s:0:\"\";s:14:\"list_show_hits\";s:1:\"1\";s:16:\"list_show_author\";s:1:\"1\";s:11:\"orderby_pri\";s:5:\"order\";s:11:\"orderby_sec\";s:5:\"rdate\";s:10:\"order_date\";s:9:\"published\";s:15:\"show_pagination\";s:1:\"2\";s:23:\"show_pagination_results\";s:1:\"1\";s:14:\"show_feed_link\";s:1:\"1\";s:12:\"feed_summary\";s:1:\"0\";s:11:\"post_format\";s:8:\"standard\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":4:{s:6:\"robots\";s:0:\"\";s:6:\"author\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"xreference\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"version\";s:1:\"1\";s:8:\"ordering\";s:1:\"3\";s:8:\"category\";s:13:\"Uncategorised\";s:9:\"cat_state\";s:1:\"1\";s:10:\"cat_access\";s:1:\"1\";s:4:\"slug\";s:6:\"1:menu\";s:7:\"catslug\";s:15:\"2:uncategorised\";s:6:\"author\";s:10:\"Super User\";s:6:\"layout\";s:7:\"article\";s:4:\"path\";s:32:\"index.php/2-uncategorised/1-menu\";s:10:\"metaauthor\";N;}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:7:\"metakey\";i:4;s:8:\"metadesc\";i:5;s:10:\"metaauthor\";i:6;s:6:\"author\";i:7;s:16:\"created_by_alias\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:4:{s:4:\"Type\";a:1:{s:7:\"Article\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:7:\"Article\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:6:\"Author\";a:1:{s:10:\"Super User\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:10:\"Super User\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Category\";a:1:{s:13:\"Uncategorised\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:13:\"Uncategorised\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:46:\"index.php?option=com_content&view=article&id=1\";s:5:\"route\";s:70:\"index.php?option=com_content&view=article&id=1:menu&catid=2&Itemid=101\";s:5:\"title\";s:4:\"Menu\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:0;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"2016-11-12 06:22:40\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:22:40\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:4;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('23', 'index.php?option=com_content&view=article&id=5', 'index.php?option=com_content&view=article&id=5:color-variation&Itemid=101', 'Color Variation', '', '2016-11-14 20:30:32', '2caed176957a00456f4f6c85c28d3295', '1', '1', '1', '*', '2016-11-12 06:46:21', '0000-00-00 00:00:00', '2016-11-12 06:46:21', '0000-00-00 00:00:00', '0', '0', '4', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:24:{s:2:\"id\";s:1:\"5\";s:5:\"alias\";s:15:\"color-variation\";s:7:\"summary\";s:0:\"\";s:4:\"body\";s:0:\"\";s:5:\"catid\";s:1:\"8\";s:10:\"created_by\";s:3:\"602\";s:16:\"created_by_alias\";s:0:\"\";s:8:\"modified\";s:19:\"2016-11-12 06:46:21\";s:11:\"modified_by\";s:1:\"0\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":69:{s:14:\"article_layout\";s:9:\"_:default\";s:10:\"show_title\";s:1:\"1\";s:11:\"link_titles\";s:1:\"1\";s:10:\"show_intro\";s:1:\"1\";s:13:\"show_category\";s:1:\"1\";s:13:\"link_category\";s:1:\"1\";s:20:\"show_parent_category\";s:1:\"0\";s:20:\"link_parent_category\";s:1:\"0\";s:11:\"show_author\";s:1:\"1\";s:11:\"link_author\";s:1:\"0\";s:16:\"show_create_date\";s:1:\"0\";s:16:\"show_modify_date\";s:1:\"0\";s:17:\"show_publish_date\";s:1:\"1\";s:20:\"show_item_navigation\";s:1:\"1\";s:9:\"show_vote\";s:1:\"0\";s:13:\"show_readmore\";s:1:\"1\";s:19:\"show_readmore_title\";s:1:\"1\";s:14:\"readmore_limit\";s:3:\"100\";s:10:\"show_icons\";s:1:\"1\";s:15:\"show_print_icon\";s:1:\"1\";s:15:\"show_email_icon\";s:1:\"1\";s:9:\"show_hits\";s:1:\"1\";s:11:\"show_noauth\";s:1:\"0\";s:23:\"show_publishing_options\";s:1:\"1\";s:20:\"show_article_options\";s:1:\"1\";s:12:\"save_history\";s:1:\"1\";s:13:\"history_limit\";i:10;s:25:\"show_urls_images_frontend\";s:1:\"0\";s:24:\"show_urls_images_backend\";s:1:\"1\";s:7:\"targeta\";i:0;s:7:\"targetb\";i:0;s:7:\"targetc\";i:0;s:11:\"float_intro\";s:4:\"left\";s:14:\"float_fulltext\";s:4:\"left\";s:15:\"category_layout\";s:6:\"_:blog\";s:19:\"show_category_title\";s:1:\"0\";s:16:\"show_description\";s:1:\"0\";s:22:\"show_description_image\";s:1:\"0\";s:8:\"maxLevel\";s:1:\"1\";s:21:\"show_empty_categories\";s:1:\"0\";s:16:\"show_no_articles\";s:1:\"1\";s:16:\"show_subcat_desc\";s:1:\"1\";s:21:\"show_cat_num_articles\";s:1:\"0\";s:21:\"show_base_description\";s:1:\"1\";s:11:\"maxLevelcat\";s:2:\"-1\";s:25:\"show_empty_categories_cat\";s:1:\"0\";s:20:\"show_subcat_desc_cat\";s:1:\"1\";s:25:\"show_cat_num_articles_cat\";s:1:\"1\";s:20:\"num_leading_articles\";s:1:\"1\";s:18:\"num_intro_articles\";s:1:\"4\";s:11:\"num_columns\";s:1:\"2\";s:9:\"num_links\";s:1:\"4\";s:18:\"multi_column_order\";s:1:\"0\";s:24:\"show_subcategory_content\";s:1:\"0\";s:21:\"show_pagination_limit\";s:1:\"1\";s:12:\"filter_field\";s:4:\"hide\";s:13:\"show_headings\";s:1:\"1\";s:14:\"list_show_date\";s:1:\"0\";s:11:\"date_format\";s:0:\"\";s:14:\"list_show_hits\";s:1:\"1\";s:16:\"list_show_author\";s:1:\"1\";s:11:\"orderby_pri\";s:5:\"order\";s:11:\"orderby_sec\";s:5:\"rdate\";s:10:\"order_date\";s:9:\"published\";s:15:\"show_pagination\";s:1:\"2\";s:23:\"show_pagination_results\";s:1:\"1\";s:14:\"show_feed_link\";s:1:\"1\";s:12:\"feed_summary\";s:1:\"0\";s:11:\"post_format\";s:8:\"standard\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":4:{s:6:\"robots\";s:0:\"\";s:6:\"author\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"xreference\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"version\";s:1:\"1\";s:8:\"ordering\";s:1:\"0\";s:8:\"category\";s:15:\"Color Variation\";s:9:\"cat_state\";s:2:\"-2\";s:10:\"cat_access\";s:1:\"1\";s:4:\"slug\";s:17:\"5:color-variation\";s:7:\"catslug\";s:17:\"8:color-variation\";s:6:\"author\";s:10:\"Super User\";s:6:\"layout\";s:7:\"article\";s:4:\"path\";s:30:\"index.php?id=5:color-variation\";s:10:\"metaauthor\";N;}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:7:\"metakey\";i:4;s:8:\"metadesc\";i:5;s:10:\"metaauthor\";i:6;s:6:\"author\";i:7;s:16:\"created_by_alias\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:4:{s:4:\"Type\";a:1:{s:7:\"Article\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:7:\"Article\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:6:\"Author\";a:1:{s:10:\"Super User\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:10:\"Super User\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Category\";a:1:{s:15:\"Color Variation\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:15:\"Color Variation\";s:5:\"state\";i:-2;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:46:\"index.php?option=com_content&view=article&id=5\";s:5:\"route\";s:73:\"index.php?option=com_content&view=article&id=5:color-variation&Itemid=101\";s:5:\"title\";s:15:\"Color Variation\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:1;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"2016-11-12 06:46:21\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 06:46:21\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:4;s:15:\"defaultLanguage\";s:5:\"en-GB\";}'),
('24', 'index.php?option=com_content&view=article&id=6', 'index.php?option=com_content&view=article&id=6:color-variation-2&Itemid=119', 'Color Variation', '', '2016-11-14 20:30:34', '4336884d9db059b0fc0a3a6bef2c56be', '1', '0', '1', '*', '2016-11-12 07:04:04', '0000-00-00 00:00:00', '2016-11-12 07:04:04', '0000-00-00 00:00:00', '0', '0', '4', 'O:19:\"FinderIndexerResult\":19:{s:11:\"\0*\0elements\";a:24:{s:2:\"id\";s:1:\"6\";s:5:\"alias\";s:17:\"color-variation-2\";s:7:\"summary\";s:0:\"\";s:4:\"body\";s:0:\"\";s:5:\"catid\";s:1:\"8\";s:10:\"created_by\";s:3:\"602\";s:16:\"created_by_alias\";s:0:\"\";s:8:\"modified\";s:19:\"2016-11-12 07:04:33\";s:11:\"modified_by\";s:3:\"602\";s:6:\"params\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":69:{s:14:\"article_layout\";s:9:\"_:default\";s:10:\"show_title\";s:1:\"1\";s:11:\"link_titles\";s:1:\"1\";s:10:\"show_intro\";s:1:\"1\";s:13:\"show_category\";s:1:\"1\";s:13:\"link_category\";s:1:\"1\";s:20:\"show_parent_category\";s:1:\"0\";s:20:\"link_parent_category\";s:1:\"0\";s:11:\"show_author\";s:1:\"1\";s:11:\"link_author\";s:1:\"0\";s:16:\"show_create_date\";s:1:\"0\";s:16:\"show_modify_date\";s:1:\"0\";s:17:\"show_publish_date\";s:1:\"1\";s:20:\"show_item_navigation\";s:1:\"1\";s:9:\"show_vote\";s:1:\"0\";s:13:\"show_readmore\";s:1:\"1\";s:19:\"show_readmore_title\";s:1:\"1\";s:14:\"readmore_limit\";s:3:\"100\";s:10:\"show_icons\";s:1:\"1\";s:15:\"show_print_icon\";s:1:\"1\";s:15:\"show_email_icon\";s:1:\"1\";s:9:\"show_hits\";s:1:\"1\";s:11:\"show_noauth\";s:1:\"0\";s:23:\"show_publishing_options\";s:1:\"1\";s:20:\"show_article_options\";s:1:\"1\";s:12:\"save_history\";s:1:\"1\";s:13:\"history_limit\";i:10;s:25:\"show_urls_images_frontend\";s:1:\"0\";s:24:\"show_urls_images_backend\";s:1:\"1\";s:7:\"targeta\";i:0;s:7:\"targetb\";i:0;s:7:\"targetc\";i:0;s:11:\"float_intro\";s:4:\"left\";s:14:\"float_fulltext\";s:4:\"left\";s:15:\"category_layout\";s:6:\"_:blog\";s:19:\"show_category_title\";s:1:\"0\";s:16:\"show_description\";s:1:\"0\";s:22:\"show_description_image\";s:1:\"0\";s:8:\"maxLevel\";s:1:\"1\";s:21:\"show_empty_categories\";s:1:\"0\";s:16:\"show_no_articles\";s:1:\"1\";s:16:\"show_subcat_desc\";s:1:\"1\";s:21:\"show_cat_num_articles\";s:1:\"0\";s:21:\"show_base_description\";s:1:\"1\";s:11:\"maxLevelcat\";s:2:\"-1\";s:25:\"show_empty_categories_cat\";s:1:\"0\";s:20:\"show_subcat_desc_cat\";s:1:\"1\";s:25:\"show_cat_num_articles_cat\";s:1:\"1\";s:20:\"num_leading_articles\";s:1:\"1\";s:18:\"num_intro_articles\";s:1:\"4\";s:11:\"num_columns\";s:1:\"2\";s:9:\"num_links\";s:1:\"4\";s:18:\"multi_column_order\";s:1:\"0\";s:24:\"show_subcategory_content\";s:1:\"0\";s:21:\"show_pagination_limit\";s:1:\"1\";s:12:\"filter_field\";s:4:\"hide\";s:13:\"show_headings\";s:1:\"1\";s:14:\"list_show_date\";s:1:\"0\";s:11:\"date_format\";s:0:\"\";s:14:\"list_show_hits\";s:1:\"1\";s:16:\"list_show_author\";s:1:\"1\";s:11:\"orderby_pri\";s:5:\"order\";s:11:\"orderby_sec\";s:5:\"rdate\";s:10:\"order_date\";s:9:\"published\";s:15:\"show_pagination\";s:1:\"2\";s:23:\"show_pagination_results\";s:1:\"1\";s:14:\"show_feed_link\";s:1:\"1\";s:12:\"feed_summary\";s:1:\"0\";s:11:\"post_format\";s:8:\"standard\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"metakey\";s:0:\"\";s:8:\"metadesc\";s:0:\"\";s:8:\"metadata\";O:24:\"Joomla\\Registry\\Registry\":3:{s:7:\"\0*\0data\";O:8:\"stdClass\":4:{s:6:\"robots\";s:0:\"\";s:6:\"author\";s:0:\"\";s:6:\"rights\";s:0:\"\";s:10:\"xreference\";s:0:\"\";}s:14:\"\0*\0initialized\";b:1;s:9:\"separator\";s:1:\".\";}s:7:\"version\";s:1:\"2\";s:8:\"ordering\";s:1:\"0\";s:8:\"category\";s:15:\"Color Variation\";s:9:\"cat_state\";s:2:\"-2\";s:10:\"cat_access\";s:1:\"1\";s:4:\"slug\";s:19:\"6:color-variation-2\";s:7:\"catslug\";s:17:\"8:color-variation\";s:6:\"author\";s:10:\"Super User\";s:6:\"layout\";s:7:\"article\";s:4:\"path\";s:26:\"index.php/color-variations\";s:10:\"metaauthor\";N;}s:15:\"\0*\0instructions\";a:5:{i:1;a:3:{i:0;s:5:\"title\";i:1;s:8:\"subtitle\";i:2;s:2:\"id\";}i:2;a:2:{i:0;s:7:\"summary\";i:1;s:4:\"body\";}i:3;a:8:{i:0;s:4:\"meta\";i:1;s:10:\"list_price\";i:2;s:10:\"sale_price\";i:3;s:7:\"metakey\";i:4;s:8:\"metadesc\";i:5;s:10:\"metaauthor\";i:6;s:6:\"author\";i:7;s:16:\"created_by_alias\";}i:4;a:2:{i:0;s:4:\"path\";i:1;s:5:\"alias\";}i:5;a:1:{i:0;s:8:\"comments\";}}s:11:\"\0*\0taxonomy\";a:4:{s:4:\"Type\";a:1:{s:7:\"Article\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:7:\"Article\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:6:\"Author\";a:1:{s:10:\"Super User\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:10:\"Super User\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}s:8:\"Category\";a:1:{s:15:\"Color Variation\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:15:\"Color Variation\";s:5:\"state\";i:-2;s:6:\"access\";i:1;}}s:8:\"Language\";a:1:{s:1:\"*\";O:7:\"JObject\":4:{s:10:\"\0*\0_errors\";a:0:{}s:5:\"title\";s:1:\"*\";s:5:\"state\";i:1;s:6:\"access\";i:1;}}}s:3:\"url\";s:46:\"index.php?option=com_content&view=article&id=6\";s:5:\"route\";s:75:\"index.php?option=com_content&view=article&id=6:color-variation-2&Itemid=119\";s:5:\"title\";s:15:\"Color Variation\";s:11:\"description\";s:0:\"\";s:9:\"published\";N;s:5:\"state\";i:0;s:6:\"access\";s:1:\"1\";s:8:\"language\";s:1:\"*\";s:18:\"publish_start_date\";s:19:\"2016-11-12 07:04:04\";s:16:\"publish_end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"start_date\";s:19:\"2016-11-12 07:04:04\";s:8:\"end_date\";s:19:\"0000-00-00 00:00:00\";s:10:\"list_price\";N;s:10:\"sale_price\";N;s:7:\"type_id\";i:4;s:15:\"defaultLanguage\";s:5:\"en-GB\";}');

DROP TABLE IF EXISTS `lal5d_finder_links_terms0`;
CREATE TABLE `lal5d_finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_terms0
(`link_id`, `term_id`, `weight`) VALUES 
('13', '3', '0.56004'),
('18', '3', '0.56004'),
('20', '3', '0.56004'),
('21', '3', '0.56004'),
('22', '3', '0.56004'),
('23', '3', '0.56004'),
('24', '3', '0.56004'),
('13', '6', '0.79992'),
('18', '6', '0.79992'),
('20', '6', '0.79992'),
('21', '6', '0.79992'),
('22', '6', '0.79992'),
('23', '6', '0.79992'),
('24', '6', '0.79992'),
('13', '7', '3.19992'),
('18', '7', '3.19992'),
('20', '7', '3.19992'),
('21', '7', '3.19992'),
('22', '7', '3.19992'),
('23', '7', '3.19992'),
('24', '7', '3.19992'),
('7', '37', '1.48'),
('8', '37', '1.48'),
('7', '38', '5.18'),
('8', '42', '5.18'),
('8', '43', '5.92'),
('21', '88', '1.72679');

DROP TABLE IF EXISTS `lal5d_finder_links_terms1`;
CREATE TABLE `lal5d_finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_terms1
(`link_id`, `term_id`, `weight`) VALUES 
('24', '94', '0.17');

DROP TABLE IF EXISTS `lal5d_finder_links_terms2`;
CREATE TABLE `lal5d_finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_terms2
(`link_id`, `term_id`, `weight`) VALUES 
('18', '79', '0.98679');

DROP TABLE IF EXISTS `lal5d_finder_links_terms3`;
CREATE TABLE `lal5d_finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lal5d_finder_links_terms4`;
CREATE TABLE `lal5d_finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_terms4
(`link_id`, `term_id`, `weight`) VALUES 
('5', '17', '1.23321'),
('7', '17', '1.23321'),
('8', '17', '1.23321'),
('9', '17', '1.23321'),
('10', '17', '1.23321'),
('11', '17', '1.23321'),
('12', '17', '1.23321'),
('13', '17', '1.23321'),
('23', '17', '1.63317'),
('24', '17', '1.63317'),
('5', '18', '5.55'),
('13', '18', '5.55'),
('23', '18', '7.35'),
('24', '18', '7.35'),
('5', '30', '0.63996'),
('7', '30', '0.63996'),
('8', '30', '0.63996'),
('9', '30', '0.63996'),
('10', '30', '0.63996'),
('11', '30', '0.63996'),
('12', '30', '0.63996'),
('7', '33', '0.17'),
('9', '50', '0.74'),
('10', '50', '0.74'),
('9', '51', '4.81'),
('10', '55', '4.81'),
('10', '56', '5.55'),
('20', '85', '1.72679'),
('24', '95', '3.1334');

DROP TABLE IF EXISTS `lal5d_finder_links_terms5`;
CREATE TABLE `lal5d_finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lal5d_finder_links_terms6`;
CREATE TABLE `lal5d_finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_terms6
(`link_id`, `term_id`, `weight`) VALUES 
('22', '91', '0.98679');

DROP TABLE IF EXISTS `lal5d_finder_links_terms7`;
CREATE TABLE `lal5d_finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_terms7
(`link_id`, `term_id`, `weight`) VALUES 
('13', '8', '1.04004'),
('18', '8', '1.04004'),
('20', '8', '1.04004'),
('21', '8', '1.04004'),
('22', '8', '1.04004'),
('13', '9', '0.64008'),
('18', '9', '0.64008'),
('20', '9', '0.64008'),
('21', '9', '0.64008'),
('22', '9', '0.64008'),
('23', '9', '0.64008'),
('24', '9', '0.64008');

DROP TABLE IF EXISTS `lal5d_finder_links_terms8`;
CREATE TABLE `lal5d_finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_terms8
(`link_id`, `term_id`, `weight`) VALUES 
('7', '4', '0.6666'),
('8', '4', '0.6666'),
('9', '4', '0.6666'),
('10', '4', '0.6666'),
('11', '4', '0.6666'),
('12', '4', '0.6666'),
('13', '4', '0.6666'),
('18', '4', '0.6666'),
('20', '4', '0.6666'),
('21', '4', '0.6666'),
('22', '4', '0.6666'),
('23', '4', '0.6666'),
('24', '4', '0.6666'),
('18', '78', '0.17');

DROP TABLE IF EXISTS `lal5d_finder_links_terms9`;
CREATE TABLE `lal5d_finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_terms9
(`link_id`, `term_id`, `weight`) VALUES 
('5', '19', '2.22'),
('13', '19', '2.22'),
('23', '19', '2.94'),
('24', '19', '2.94'),
('7', '34', '1.23321'),
('8', '34', '1.23321'),
('9', '34', '1.23321'),
('10', '34', '1.23321'),
('11', '34', '1.23321'),
('12', '34', '1.23321'),
('7', '35', '5.18'),
('7', '36', '5.92'),
('8', '41', '5.05679'),
('10', '41', '5.05679'),
('12', '41', '5.05679'),
('9', '48', '4.81'),
('9', '49', '5.55'),
('11', '58', '4.93321'),
('11', '59', '5.67321'),
('11', '60', '0.98679'),
('12', '60', '0.98679'),
('11', '61', '4.93321'),
('12', '65', '4.93321'),
('12', '66', '5.67321'),
('24', '96', '2.7334');

DROP TABLE IF EXISTS `lal5d_finder_links_termsa`;
CREATE TABLE `lal5d_finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_termsa
(`link_id`, `term_id`, `weight`) VALUES 
('20', '84', '0.17');

DROP TABLE IF EXISTS `lal5d_finder_links_termsb`;
CREATE TABLE `lal5d_finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lal5d_finder_links_termsc`;
CREATE TABLE `lal5d_finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_termsc
(`link_id`, `term_id`, `weight`) VALUES 
('5', '29', '0.17'),
('8', '40', '0.34'),
('9', '47', '0.34'),
('10', '54', '0.34'),
('11', '57', '0.34'),
('12', '64', '0.34'),
('13', '67', '0.17'),
('24', '67', '0.2'),
('22', '90', '0.17');

DROP TABLE IF EXISTS `lal5d_finder_links_termsd`;
CREATE TABLE `lal5d_finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_termsd
(`link_id`, `term_id`, `weight`) VALUES 
('5', '1', '0'),
('7', '1', '0'),
('8', '1', '0'),
('9', '1', '0'),
('10', '1', '0'),
('11', '1', '0'),
('12', '1', '0'),
('13', '1', '0'),
('18', '1', '0'),
('20', '1', '0'),
('21', '1', '0'),
('22', '1', '0'),
('23', '1', '0'),
('24', '1', '0');

DROP TABLE IF EXISTS `lal5d_finder_links_termse`;
CREATE TABLE `lal5d_finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_links_termse
(`link_id`, `term_id`, `weight`) VALUES 
('21', '87', '0.17'),
('23', '93', '0.17');

DROP TABLE IF EXISTS `lal5d_finder_links_termsf`;
CREATE TABLE `lal5d_finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lal5d_finder_taxonomy`;
CREATE TABLE `lal5d_finder_taxonomy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `state` (`state`),
  KEY `ordering` (`ordering`),
  KEY `access` (`access`),
  KEY `idx_parent_published` (`parent_id`,`state`,`access`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_taxonomy
(`id`, `parent_id`, `title`, `state`, `access`, `ordering`) VALUES 
('1', '0', 'ROOT', '0', '0', '0'),
('2', '1', 'Type', '1', '1', '0'),
('3', '2', 'Article', '1', '1', '0'),
('4', '1', 'Author', '1', '1', '0'),
('5', '4', 'Super User', '1', '1', '0'),
('6', '1', 'Category', '1', '1', '0'),
('7', '6', 'Uncategorised', '1', '1', '0'),
('8', '1', 'Language', '1', '1', '0'),
('9', '8', '*', '1', '1', '0'),
('10', '2', 'Category', '1', '1', '0'),
('12', '6', 'Color Variation', '0', '1', '0');

DROP TABLE IF EXISTS `lal5d_finder_taxonomy_map`;
CREATE TABLE `lal5d_finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`node_id`),
  KEY `link_id` (`link_id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_taxonomy_map
(`link_id`, `node_id`) VALUES 
('5', '9'),
('5', '10'),
('7', '9'),
('7', '10'),
('8', '9'),
('8', '10'),
('9', '9'),
('9', '10'),
('10', '9'),
('10', '10'),
('11', '9'),
('11', '10'),
('12', '9'),
('12', '10'),
('13', '3'),
('13', '5'),
('13', '7'),
('13', '9'),
('18', '3'),
('18', '5'),
('18', '7'),
('18', '9'),
('20', '3'),
('20', '5'),
('20', '7'),
('20', '9'),
('21', '3'),
('21', '5'),
('21', '7'),
('21', '9'),
('22', '3'),
('22', '5'),
('22', '7'),
('22', '9'),
('23', '3'),
('23', '5'),
('23', '9'),
('23', '12'),
('24', '3'),
('24', '5'),
('24', '9'),
('24', '12');

DROP TABLE IF EXISTS `lal5d_finder_terms`;
CREATE TABLE `lal5d_finder_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  `language` char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `idx_term` (`term`),
  KEY `idx_term_phrase` (`term`,`phrase`),
  KEY `idx_stem_phrase` (`stem`,`phrase`),
  KEY `idx_soundex_phrase` (`soundex`,`phrase`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_terms
(`term_id`, `term`, `stem`, `common`, `phrase`, `weight`, `soundex`, `links`, `language`) VALUES 
('1', '', '', '0', '0', '0', '', '16', '*'),
('3', 'article', 'article', '0', '0', '0.4667', 'A6324', '7', '*'),
('4', 'index', 'index', '0', '0', '0.3333', 'I532', '15', '*'),
('6', 'super', 'super', '0', '0', '0.3333', 'S160', '7', '*'),
('7', 'super user', 'super user', '0', '1', '1.3333', 'S1626', '7', '*'),
('8', 'uncategorised', 'uncategorised', '0', '0', '0.8667', 'U5232623', '5', '*'),
('9', 'user', 'user', '0', '0', '0.2667', 'U260', '7', '*'),
('17', 'color', 'color', '0', '0', '0.3333', 'C460', '12', '*'),
('18', 'color variation', 'color variation', '0', '1', '1.5', 'C461635', '5', '*'),
('19', 'variation', 'variation', '0', '0', '0.6', 'V635', '5', '*'),
('29', '8', '8', '0', '0', '0.1', '', '2', '*'),
('30', 'category', 'category', '0', '0', '0.5333', 'C326', '9', '*'),
('33', '9', '9', '0', '0', '0.1', '', '1', '*'),
('34', 'black', 'black', '0', '0', '0.3333', 'B420', '7', '*'),
('35', 'black silver', 'black silver', '0', '1', '1.4', 'B42416', '1', '*'),
('36', 'black silver color', 'black silver color', '0', '1', '1.6', 'B42416246', '1', '*'),
('37', 'silver', 'silver', '0', '0', '0.4', 'S416', '2', '*'),
('38', 'silver color', 'silver color', '0', '1', '1.4', 'S416246', '1', '*'),
('40', '10', '10', '0', '0', '0.2', '', '1', '*'),
('41', 'black color', 'black color', '0', '1', '1.3667', 'B4246', '4', '*'),
('42', 'silver black', 'silver black', '0', '1', '1.4', 'S416142', '1', '*'),
('43', 'silver black color', 'silver black color', '0', '1', '1.6', 'S41614246', '1', '*'),
('47', '11', '11', '0', '0', '0.2', '', '1', '*'),
('48', 'black red', 'black red', '0', '1', '1.3', 'B4263', '1', '*'),
('49', 'black red color', 'black red color', '0', '1', '1.5', 'B4263246', '1', '*'),
('50', 'red', 'red', '0', '0', '0.2', 'R300', '2', '*'),
('51', 'red color', 'red color', '0', '1', '1.3', 'R3246', '1', '*'),
('54', '12', '12', '0', '0', '0.2', '', '1', '*'),
('55', 'red black', 'red black', '0', '1', '1.3', 'R3142', '1', '*'),
('56', 'red black color', 'red black color', '0', '1', '1.5', 'R314246', '1', '*'),
('57', '13', '13', '0', '0', '0.2', '', '1', '*'),
('58', 'black blue', 'black blue', '0', '1', '1.3333', 'B4214', '1', '*'),
('59', 'black blue color', 'black blue color', '0', '1', '1.5333', 'B4214246', '1', '*'),
('60', 'blue', 'blue', '0', '0', '0.2667', 'B400', '3', '*'),
('61', 'blue color', 'blue color', '0', '1', '1.3333', 'B4246', '1', '*'),
('64', '14', '14', '0', '0', '0.2', '', '2', '*'),
('65', 'blue black', 'blue black', '0', '1', '1.3333', 'B4142', '2', '*'),
('66', 'blue black color', 'blue black color', '0', '1', '1.5333', 'B414246', '2', '*'),
('67', '2', '2', '0', '0', '0.1', '', '2', '*'),
('78', '7', '7', '0', '0', '0.1', '', '1', '*'),
('79', 'home', 'home', '0', '0', '0.2667', 'H500', '1', '*'),
('84', '4', '4', '0', '0', '0.1', '', '1', '*'),
('85', 'contact', 'contact', '0', '0', '0.4667', 'C5323', '1', '*'),
('87', '3', '3', '0', '0', '0.1', '', '1', '*'),
('88', 'service', 'service', '0', '0', '0.4667', 'S612', '1', '*'),
('90', '1', '1', '0', '0', '0.1', '', '1', '*'),
('91', 'menu', 'menu', '0', '0', '0.2667', 'M000', '1', '*'),
('93', '5', '5', '0', '0', '0.1', '', '1', '*'),
('94', '6', '6', '0', '0', '0.1', '', '1', '*'),
('95', 'color variation 2', 'color variation 2', '0', '1', '1.5667', 'C461635', '1', '*');

INSERT INTO lal5d_finder_terms
(`term_id`, `term`, `stem`, `common`, `phrase`, `weight`, `soundex`, `links`, `language`) VALUES 
('96', 'variation 2', 'variation 2', '0', '1', '1.3667', 'V635', '1', '*');

DROP TABLE IF EXISTS `lal5d_finder_terms_common`;
CREATE TABLE `lal5d_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL,
  KEY `idx_word_lang` (`term`,`language`),
  KEY `idx_lang` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_terms_common
(`term`, `language`) VALUES 
('a', 'en'),
('about', 'en'),
('after', 'en'),
('ago', 'en'),
('all', 'en'),
('am', 'en'),
('an', 'en'),
('and', 'en'),
('ani', 'en'),
('any', 'en'),
('are', 'en'),
('aren\'t', 'en'),
('as', 'en'),
('at', 'en'),
('be', 'en'),
('but', 'en'),
('by', 'en'),
('for', 'en'),
('from', 'en'),
('get', 'en'),
('go', 'en'),
('how', 'en'),
('if', 'en'),
('in', 'en'),
('into', 'en'),
('is', 'en'),
('isn\'t', 'en'),
('it', 'en'),
('its', 'en'),
('me', 'en'),
('more', 'en'),
('most', 'en'),
('must', 'en'),
('my', 'en'),
('new', 'en'),
('no', 'en'),
('none', 'en'),
('not', 'en'),
('noth', 'en'),
('nothing', 'en'),
('of', 'en'),
('off', 'en'),
('often', 'en'),
('old', 'en'),
('on', 'en'),
('onc', 'en'),
('once', 'en'),
('onli', 'en'),
('only', 'en'),
('or', 'en');

INSERT INTO lal5d_finder_terms_common
(`term`, `language`) VALUES 
('other', 'en'),
('our', 'en'),
('ours', 'en'),
('out', 'en'),
('over', 'en'),
('page', 'en'),
('she', 'en'),
('should', 'en'),
('small', 'en'),
('so', 'en'),
('some', 'en'),
('than', 'en'),
('thank', 'en'),
('that', 'en'),
('the', 'en'),
('their', 'en'),
('theirs', 'en'),
('them', 'en'),
('then', 'en'),
('there', 'en'),
('these', 'en'),
('they', 'en'),
('this', 'en'),
('those', 'en'),
('thus', 'en'),
('time', 'en'),
('times', 'en'),
('to', 'en'),
('too', 'en'),
('true', 'en'),
('under', 'en'),
('until', 'en'),
('up', 'en'),
('upon', 'en'),
('use', 'en'),
('user', 'en'),
('users', 'en'),
('veri', 'en'),
('version', 'en'),
('very', 'en'),
('via', 'en'),
('want', 'en'),
('was', 'en'),
('way', 'en'),
('were', 'en'),
('what', 'en'),
('when', 'en'),
('where', 'en'),
('whi', 'en'),
('which', 'en');

INSERT INTO lal5d_finder_terms_common
(`term`, `language`) VALUES 
('who', 'en'),
('whom', 'en'),
('whose', 'en'),
('why', 'en'),
('wide', 'en'),
('will', 'en'),
('with', 'en'),
('within', 'en'),
('without', 'en'),
('would', 'en'),
('yes', 'en'),
('yet', 'en'),
('you', 'en'),
('your', 'en'),
('yours', 'en');

DROP TABLE IF EXISTS `lal5d_finder_tokens`;
CREATE TABLE `lal5d_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `language` char(3) NOT NULL DEFAULT '',
  KEY `idx_word` (`term`),
  KEY `idx_context` (`context`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lal5d_finder_tokens_aggregate`;
CREATE TABLE `lal5d_finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  `language` char(3) NOT NULL DEFAULT '',
  KEY `token` (`term`),
  KEY `keyword_id` (`term_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `lal5d_finder_types`;
CREATE TABLE `lal5d_finder_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO lal5d_finder_types
(`id`, `title`, `mime`) VALUES 
('1', 'Tag', ''),
('2', 'Category', ''),
('3', 'Contact', ''),
('4', 'Article', ''),
('6', 'News Feed', '');

DROP TABLE IF EXISTS `lal5d_flippingbook_books`;
CREATE TABLE `lal5d_flippingbook_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access` int(10) NOT NULL,
  `alias` text NOT NULL,
  `allow_pages_unload` tinyint(1) NOT NULL,
  `always_opened` tinyint(1) NOT NULL,
  `auto_flip_size` int(4) NOT NULL,
  `background_color` varchar(10) NOT NULL,
  `background_image` varchar(255) NOT NULL,
  `background_image_placement` varchar(10) NOT NULL,
  `book_height` varchar(6) NOT NULL,
  `book_width` varchar(6) NOT NULL,
  `book_size` varchar(4) NOT NULL,
  `category_id` int(6) NOT NULL,
  `center_book` tinyint(1) NOT NULL,
  `checked_out` int(11) NOT NULL,
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `direction` varchar(6) NOT NULL,
  `download_size` varchar(100) NOT NULL,
  `download_title` varchar(100) NOT NULL,
  `download_url` varchar(255) NOT NULL,
  `dynamic_shadows_depth` varchar(5) NOT NULL,
  `dynamic_scaling` tinyint(1) NOT NULL,
  `emailIcon` tinyint(1) NOT NULL,
  `first_last_buttons` tinyint(1) NOT NULL,
  `first_page` int(4) NOT NULL,
  `flash_height` varchar(6) NOT NULL,
  `flash_width` varchar(6) NOT NULL,
  `flip_corner_style` varchar(20) NOT NULL,
  `frame_color` varchar(10) NOT NULL,
  `frame_width` int(4) NOT NULL,
  `fullscreen_enabled` tinyint(1) NOT NULL,
  `fullscreen_hint` text NOT NULL,
  `go_to_page_field` tinyint(1) NOT NULL,
  `hardcover` tinyint(1) NOT NULL,
  `hits` int(11) NOT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `navigation_bar` varchar(255) NOT NULL,
  `navigation_bar_placement` varchar(10) NOT NULL,
  `new_window_height` int(4) NOT NULL,
  `new_window_width` int(4) NOT NULL,
  `open_book_in` int(4) NOT NULL,
  `ordering` int(6) NOT NULL,
  `page_background_color` varchar(10) NOT NULL,
  `preview_image` varchar(255) NOT NULL,
  `print_enabled` tinyint(1) NOT NULL,
  `printIcon` tinyint(1) NOT NULL,
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL,
  `scale_content` tinyint(1) NOT NULL,
  `show_book_description` tinyint(1) NOT NULL,
  `show_book_title` tinyint(1) NOT NULL,
  `show_pages_description` tinyint(1) NOT NULL,
  `show_slide_show_button` tinyint(4) NOT NULL,
  `show_zoom_hint` tinyint(1) NOT NULL,
  `slideshow_auto_play` tinyint(1) NOT NULL,
  `slideshow_button` tinyint(1) NOT NULL,
  `slideshow_display_duration` int(5) NOT NULL,
  `sound_control_button` int(1) NOT NULL,
  `static_shadows_depth` varchar(5) NOT NULL,
  `static_shadows_type` varchar(15) NOT NULL,
  `title` text NOT NULL,
  `transparent_pages` tinyint(1) NOT NULL,
  `zoom_enabled` tinyint(1) NOT NULL,
  `zoom_image_height` int(5) NOT NULL,
  `zoom_image_width` int(5) NOT NULL,
  `zoom_ui_color` varchar(10) NOT NULL,
  `zooming_method` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_flippingbook_books
(`id`, `access`, `alias`, `allow_pages_unload`, `always_opened`, `auto_flip_size`, `background_color`, `background_image`, `background_image_placement`, `book_height`, `book_width`, `book_size`, `category_id`, `center_book`, `checked_out`, `checked_out_time`, `created`, `created_by`, `created_by_alias`, `description`, `direction`, `download_size`, `download_title`, `download_url`, `dynamic_shadows_depth`, `dynamic_scaling`, `emailIcon`, `first_last_buttons`, `first_page`, `flash_height`, `flash_width`, `flip_corner_style`, `frame_color`, `frame_width`, `fullscreen_enabled`, `fullscreen_hint`, `go_to_page_field`, `hardcover`, `hits`, `language`, `modified`, `navigation_bar`, `navigation_bar_placement`, `new_window_height`, `new_window_width`, `open_book_in`, `ordering`, `page_background_color`, `preview_image`, `print_enabled`, `printIcon`, `publish_up`, `publish_down`, `state`, `scale_content`, `show_book_description`, `show_book_title`, `show_pages_description`, `show_slide_show_button`, `show_zoom_hint`, `slideshow_auto_play`, `slideshow_button`, `slideshow_display_duration`, `sound_control_button`, `static_shadows_depth`, `static_shadows_type`, `title`, `transparent_pages`, `zoom_enabled`, `zoom_image_height`, `zoom_image_width`, `zoom_ui_color`, `zooming_method`) VALUES 
('1', '1', 'flippingbook-in-action', '0', '0', '75', 'dedede', 'flippingbook/abstract_background_blue.jpg', 'fit', '400', '300', '90', '1', '1', '0', '2011-01-01 00:00:00', '2011-01-01 00:00:00', '0', '', '<p>This sample book demonstrates several ways of using the component.<br /> FlippingBook engine works with <strong>JPG, PNG, GIF and SWF</strong> (Flash) files. The JPG is convenient for creating picture albums, PNG or GIF format - for text, screenshots, drafts. The SWF format is convenient for presentations with animation, video, links etc.<em> You can modify this text in administration back-end  (Components > FlippingBook > Manage Books > FlippingBook In Action  > Description).</em></p>', 'LTR', '100 Kb', 'Download Book', 'http://localhost/my-book.pdf', '2', '1', '1', '1', '1', '500', '100%', 'manually', 'FFFFFF', '0', '1', '', '1', '1', '670', '', '2011-01-01 00:00:00', 'navigation.swf', 'bottom', '600', '800', '1', '1', 'EEEEEE', 'images/flippingbook/book_preview.png', '1', '1', '2012-02-10 10:10:10', '2012-02-10 10:10:10', '1', '1', '1', '1', '1', '1', '1', '0', '1', '5000', '1', '1', 'Asymmetric', 'FlippingBook In Action', '0', '1', '1600', '1200', '8f9ea6', '0');

DROP TABLE IF EXISTS `lal5d_flippingbook_categories`;
CREATE TABLE `lal5d_flippingbook_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `alias` text NOT NULL,
  `checked_out` int(11) NOT NULL,
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `columns` int(2) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `emailIcon` tinyint(1) NOT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(6) NOT NULL,
  `preview_image` text NOT NULL,
  `printIcon` tinyint(1) NOT NULL,
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL,
  `show_title` tinyint(1) NOT NULL,
  `title` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_flippingbook_categories
(`id`, `access`, `alias`, `checked_out`, `checked_out_time`, `columns`, `created`, `created_by`, `created_by_alias`, `description`, `emailIcon`, `language`, `modified`, `ordering`, `preview_image`, `printIcon`, `publish_up`, `publish_down`, `state`, `show_title`, `title`) VALUES 
('1', '1', 'default-category', '0', '0000-00-00 00:00:00', '2', '2012-02-10 10:10:10', '0', '', '<p>Category description.</p>', '1', '', '2012-02-10 10:10:10', '1', 'images/flippingbook/book_preview.png', '1', '2013-10-10 10:10:10', '2020-02-10 10:10:10', '1', '1', 'Default Category');

DROP TABLE IF EXISTS `lal5d_flippingbook_config`;
CREATE TABLE `lal5d_flippingbook_config` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_flippingbook_config
(`id`, `name`, `value`) VALUES 
('1', 'version', '3.1.0'),
('2', 'categoryListTitle', 'FlippingBook Categories'),
('3', 'closeSpeed', '3'),
('4', 'columns', '2'),
('5', 'dropShadowEnabled', '1'),
('6', 'emailIcon', '1'),
('7', 'flipSound', 'newspaper.mp3'),
('8', 'gotoSpeed', '3'),
('9', 'hardcoverSound', 'photo_album.mp3'),
('10', 'moveSpeed', '2'),
('11', 'preloaderType', 'Progress Bar'),
('12', 'printIcon', '1'),
('13', 'rigidPageSpeed', '5'),
('14', 'theme', 'white.css'),
('15', 'zoomOnClick', '1');

DROP TABLE IF EXISTS `lal5d_flippingbook_pages`;
CREATE TABLE `lal5d_flippingbook_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `book_id` int(4) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `file` varchar(255) NOT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `link_url` text NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `zoom_height` int(4) NOT NULL DEFAULT '800',
  `zoom_url` text NOT NULL,
  `zoom_width` int(4) NOT NULL DEFAULT '600',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_flippingbook_pages
(`id`, `access`, `book_id`, `checked_out`, `checked_out_time`, `created`, `created_by`, `created_by_alias`, `description`, `file`, `language`, `link_url`, `modified`, `ordering`, `state`, `zoom_height`, `zoom_url`, `zoom_width`) VALUES 
('1', '1', '1', '0', '0000-00-00 00:00:00', '2012-02-03 10:10:10', '0', '', '<p><strong>Page 1. New features:</strong><br />- Dynamic book scaling<br />- SEO version. HTML version for search engine indexing, non-flash computers and mobile devices<br />- RTL books support<br />- Ability to bind a desired page to a menu item<br /><em>You can modify this text in administration back-end (Components > FlippingBook > Manage Pages > page properties > Description).</em></p>', 'flippingbook/my-book_01.swf', '', '', '2012-02-10 10:10:10', '1', '1', '800', '', '600'),
('2', '1', '1', '0', '0000-00-00 00:00:00', '2012-02-03 10:10:11', '0', '', '<p><strong>Page 2. Create your own web-publications.</strong> There?s nothing easier than creating a web-magazine, newspaper or booklet now. The zooming function enables your visitors to view even the smallest text. The batch adding function helps create books with several mouse-clicks.</p>', 'flippingbook/my-book_02.jpg', '', '', '2012-02-10 10:10:10', '2', '1', '800', 'flippingbook/my-book_zoom_02.jpg', '600'),
('3', '1', '1', '0', '0000-00-00 00:00:00', '2012-02-03 10:10:12', '0', '', '<p><strong>Page 3. New navigation bar</strong> is based on the flash technology. You can download the navigation bar source file from our web-site and change its look with the help of Adobe Flash. Navigation panel helps you switch to the full-screen mode, zoom and print pages, find the needed page quickly and even download the pre-prepared offline version of the book in the pdf-format, for example.</p>', 'flippingbook/my-book_03.jpg', '', '', '2012-02-10 10:10:10', '3', '1', '800', 'flippingbook/my-book_zoom_03.jpg', '600'),
('4', '1', '1', '0', '0000-00-00 00:00:00', '2012-02-03 10:10:13', '0', '', '<p><strong>Page 4-5.</strong> Many people prefer selecting the products by printed catalogues instead of browsing through many trivial web-pages. By using our FlippingBook technology you can create an illusion of having a 3D catalogue before you.<br />You can attach individual link that will be displayed on the navigation bar to each page. This feature allows you to place the Buy Now button leading to the online shop under each page, or Download button that enables visitors to save the file attached to the page.<br />If you want to set one description for a whole spread ? just leave a blank description field for one page.</p>', 'flippingbook/my-book_04.jpg', '', '/product-in-a-shop.html', '2012-02-10 10:10:10', '4', '1', '800', 'flippingbook/my-book_zoom_04.jpg', '600'),
('5', '1', '1', '0', '0000-00-00 00:00:00', '2012-02-03 10:10:14', '0', '', '', 'flippingbook/my-book_05.jpg', '', '/product-in-a-shop.html', '2012-02-10 10:10:10', '5', '1', '800', 'flippingbook/my-book_zoom_05.jpg', '600'),
('6', '1', '1', '0', '0000-00-00 00:00:00', '2012-02-03 10:10:15', '0', '', '<p><strong>Page 6.</strong> Create photo albums that attract attention, surprise your visitors! You do not have to be a computer expert or a web-designer to create photo albums. This component is very easy to use: all you need is to create images of the right size, upload them to the server and place them in the book.</p>', 'flippingbook/my-book_06.jpg', '', '', '2012-02-10 10:10:10', '6', '1', '800', 'flippingbook/my-book_zoom_06.jpg', '600'),
('7', '1', '1', '0', '0000-00-00 00:00:00', '2012-02-03 10:10:16', '0', '', '<p><strong>Page 7.</strong> Portfolio created with the help of FlippingBook technology will impress your visitors and potential customers and stay in their memory for a long time. For example, if you are a web-designer, you can place a screenshot of a web-site on a page of your <a href=\"http://page-flip-tools.com\">page flip</a> presentation and place the link into the page description field.</p>', 'flippingbook/my-book_07.jpg', '', 'http://page-flip-tools.com', '2012-02-10 10:10:10', '7', '1', '800', 'flippingbook/my-book_zoom_07.jpg', '600'),
('8', '1', '1', '0', '0000-00-00 00:00:00', '2012-02-03 10:10:17', '0', '', '<p><strong>Page 8.</strong> If you are experiencing problems with FlippingBook, feel free to contact us. In your message, please describe your problem (or attach the screenshot), detail your order number, the email address that you used for the order and site URL with FlippingBook installed. You can find contact information on our site.</p>', 'flippingbook/my-book_08.jpg', '', '', '2012-02-10 10:10:10', '8', '1', '800', 'flippingbook/my-book_zoom_08.jpg', '600');

DROP TABLE IF EXISTS `lal5d_imageshow_external_source_picasa`;
CREATE TABLE `lal5d_imageshow_external_source_picasa` (
  `external_source_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `external_source_profile_title` varchar(255) DEFAULT NULL,
  `picasa_username` varchar(255) DEFAULT '',
  `picasa_thumbnail_size` char(30) DEFAULT '144',
  `picasa_image_size` char(30) DEFAULT '1024',
  PRIMARY KEY (`external_source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_images`;
CREATE TABLE `lal5d_imageshow_images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `showlist_id` int(11) NOT NULL,
  `image_extid` varchar(255) DEFAULT NULL,
  `album_extid` varchar(255) DEFAULT NULL,
  `image_small` varchar(255) DEFAULT NULL,
  `image_medium` varchar(255) DEFAULT NULL,
  `image_big` text,
  `image_title` varchar(255) DEFAULT NULL,
  `image_alt_text` text,
  `image_description` text,
  `image_link` varchar(255) DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `custom_data` tinyint(1) DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `image_size` varchar(25) DEFAULT NULL,
  `exif_data` text,
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_log`;
CREATE TABLE `lal5d_imageshow_log` (
  `log_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `result` varchar(255) DEFAULT NULL,
  `screen` varchar(100) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `time_created` datetime DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_showcase`;
CREATE TABLE `lal5d_imageshow_showcase` (
  `showcase_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `showcase_title` varchar(255) DEFAULT NULL,
  `published` tinyint(1) DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `general_overall_width` char(30) DEFAULT NULL,
  `general_overall_height` char(30) DEFAULT NULL,
  `date_created` datetime DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`showcase_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_showlist`;
CREATE TABLE `lal5d_imageshow_showlist` (
  `showlist_id` int(11) NOT NULL AUTO_INCREMENT,
  `showlist_title` varchar(255) DEFAULT NULL,
  `published` tinyint(1) DEFAULT '0',
  `override_title` tinyint(1) DEFAULT '0',
  `override_description` tinyint(1) DEFAULT '0',
  `override_link` tinyint(1) DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `access` tinyint(3) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL,
  `description` text,
  `showlist_link` text,
  `alter_autid` int(11) DEFAULT '0',
  `date_create` datetime DEFAULT NULL,
  `image_source_type` varchar(45) DEFAULT '',
  `image_source_name` varchar(45) DEFAULT '',
  `image_source_profile_id` int(11) DEFAULT '0',
  `authorization_status` tinyint(1) DEFAULT '0',
  `date_modified` datetime DEFAULT '0000-00-00 00:00:00',
  `image_loading_order` char(30) DEFAULT NULL,
  `show_exif_data` char(100) DEFAULT '',
  PRIMARY KEY (`showlist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_source_profile`;
CREATE TABLE `lal5d_imageshow_source_profile` (
  `external_source_profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `external_source_id` int(11) NOT NULL,
  PRIMARY KEY (`external_source_profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_theme_carousel`;
CREATE TABLE `lal5d_imageshow_theme_carousel` (
  `theme_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `image_source` char(150) DEFAULT 'thumbnails',
  `image_width` char(150) DEFAULT '',
  `image_height` char(150) DEFAULT '',
  `image_border_thickness` char(150) DEFAULT '5',
  `image_border_color` char(150) DEFAULT '',
  `view_angle` char(150) DEFAULT '0',
  `transparency` char(150) DEFAULT '50',
  `scale` char(150) DEFAULT '35',
  `diameter` char(150) DEFAULT '50',
  `animation_duration` char(150) DEFAULT '0.6',
  `click_action` char(150) DEFAULT 'show_original_image',
  `open_link_in` char(150) DEFAULT 'current_browser',
  `orientation` char(150) DEFAULT 'horizontal',
  `enable_drag_action` char(150) DEFAULT 'no',
  `show_caption` char(150) DEFAULT 'yes',
  `caption_background_color` char(150) DEFAULT '',
  `caption_opacity` char(150) DEFAULT '75',
  `caption_show_title` char(150) DEFAULT 'yes',
  `caption_title_css` text,
  `caption_show_description` char(150) DEFAULT 'yes',
  `caption_description_length_limitation` char(150) DEFAULT '50',
  `caption_description_css` text,
  `navigation_presentation` char(150) DEFAULT 'show',
  `auto_play` char(150) DEFAULT 'no',
  `slide_timing` char(150) DEFAULT '3',
  `pause_on_mouse_over` char(150) DEFAULT 'yes',
  PRIMARY KEY (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_theme_classic_flash`;
CREATE TABLE `lal5d_imageshow_theme_classic_flash` (
  `theme_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `imgpanel_presentation_mode` char(30) DEFAULT '0',
  `imgpanel_img_transition_type_fit` char(30) DEFAULT '',
  `imgpanel_img_click_action_fit` char(30) DEFAULT '',
  `imgpanel_img_open_link_in_fit` char(30) DEFAULT 'new-browser',
  `imgpanel_img_transition_type_expand` char(30) DEFAULT '',
  `imgpanel_img_motion_type_expand` char(30) DEFAULT '',
  `imgpanel_img_zooming_type_expand` char(30) DEFAULT 'center',
  `imgpanel_img_click_action_expand` char(30) DEFAULT '',
  `imgpanel_img_open_link_in_expand` char(30) DEFAULT 'new-browser',
  `imgpanel_img_show_image_shadow_fit` char(30) DEFAULT 'yes',
  `imgpanel_bg_type` char(30) DEFAULT '',
  `imgpanel_bg_value` char(255) DEFAULT NULL,
  `imgpanel_show_watermark` char(30) DEFAULT 'no',
  `imgpanel_watermark_path` char(255) DEFAULT NULL,
  `imgpanel_watermark_position` char(30) DEFAULT '',
  `imgpanel_watermark_offset` char(30) DEFAULT NULL,
  `imgpanel_watermark_opacity` char(30) DEFAULT NULL,
  `imgpanel_show_overlay_effect` char(30) DEFAULT 'no',
  `imgpanel_overlay_effect_type` char(30) DEFAULT NULL,
  `imgpanel_show_inner_shawdow` char(30) DEFAULT 'yes',
  `imgpanel_inner_shawdow_color` char(30) DEFAULT NULL,
  `thumbpanel_show_panel` char(30) DEFAULT NULL,
  `thumbpanel_panel_position` char(30) DEFAULT '',
  `thumbpanel_collapsible_position` char(30) DEFAULT 'yes',
  `thumbpanel_thumb_browsing_mode` char(30) DEFAULT '',
  `thumbpanel_show_thumb_status` char(30) DEFAULT 'yes',
  `thumbpanel_active_state_color` char(30) DEFAULT NULL,
  `thumbpanel_presentation_mode` char(30) DEFAULT '',
  `thumbpanel_border` char(30) DEFAULT NULL,
  `thumbpanel_enable_big_thumb` char(30) DEFAULT 'yes',
  `thumbpanel_big_thumb_size` char(30) DEFAULT NULL,
  `thumbpanel_thumb_row` char(30) DEFAULT NULL,
  `thumbpanel_thumb_width` char(30) DEFAULT NULL,
  `thumbpanel_thumb_height` char(30) DEFAULT NULL,
  `thumbpanel_thumb_opacity` char(30) DEFAULT '50',
  `thumbpanel_big_thumb_color` char(30) DEFAULT NULL,
  `thumbpanel_thumb_border` char(30) DEFAULT NULL,
  `thumbpanel_thumnail_panel_color` char(30) DEFAULT NULL,
  `thumbpanel_thumnail_normal_state` char(30) DEFAULT NULL,
  `infopanel_panel_position` char(30) DEFAULT '',
  `infopanel_presentation` char(30) DEFAULT NULL,
  `infopanel_bg_color_fill` char(30) DEFAULT NULL,
  `infopanel_panel_click_action` char(30) DEFAULT NULL,
  `infopanel_open_link_in` char(30) DEFAULT 'new-browser',
  `infopanel_show_title` char(30) DEFAULT 'yes',
  `infopanel_title_css` char(250) DEFAULT NULL,
  `infopanel_show_des` char(30) DEFAULT 'yes',
  `infopanel_des_lenght_limitation` char(30) DEFAULT '',
  `infopanel_des_css` char(250) DEFAULT NULL,
  `infopanel_show_link` char(30) DEFAULT 'no',
  `infopanel_link_css` char(250) DEFAULT NULL,
  `toolbarpanel_panel_position` char(30) DEFAULT '',
  `toolbarpanel_presentation` char(30) DEFAULT '0',
  `toolbarpanel_show_image_navigation` char(30) DEFAULT 'yes',
  `toolbarpanel_slideshow_player` char(30) DEFAULT 'yes',
  `toolbarpanel_show_fullscreen_switcher` char(30) DEFAULT 'yes',
  `toolbarpanel_show_tooltip` char(30) DEFAULT 'no',
  `slideshow_hide_thumb_panel` char(30) DEFAULT 'yes',
  `slideshow_slide_timing` char(50) DEFAULT NULL,
  `slideshow_hide_image_navigation` char(30) DEFAULT 'yes',
  `slideshow_auto_play` char(30) DEFAULT 'no',
  `slideshow_show_status` char(30) DEFAULT 'yes',
  `slideshow_enable_ken_burn_effect` char(30) DEFAULT 'yes',
  `slideshow_looping` char(30) DEFAULT 'yes',
  `general_round_corner_radius` char(30) DEFAULT '',
  `general_border_color` char(30) DEFAULT '',
  `general_background_color` char(30) DEFAULT '',
  `general_border_stroke` char(30) DEFAULT '',
  PRIMARY KEY (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_theme_classic_javascript`;
CREATE TABLE `lal5d_imageshow_theme_classic_javascript` (
  `theme_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `imgpanel_presentation_mode` char(30) DEFAULT '0',
  `imgpanel_img_click_action_fit` char(30) DEFAULT '',
  `imgpanel_img_open_link_in_fit` char(30) DEFAULT 'new-browser',
  `imgpanel_img_click_action_expand` char(30) DEFAULT '',
  `imgpanel_img_open_link_in_expand` char(30) DEFAULT 'new-browser',
  `imgpanel_bg_type` char(30) DEFAULT '',
  `imgpanel_bg_value` char(255) DEFAULT NULL,
  `thumbpanel_show_panel` char(30) DEFAULT NULL,
  `thumbpanel_panel_position` char(30) DEFAULT '',
  `thumbpanel_active_state_color` char(30) DEFAULT NULL,
  `thumbpanel_thumnail_normal_state` char(30) DEFAULT NULL,
  `thumbpanel_border` char(30) DEFAULT NULL,
  `thumbpanel_thumb_width` char(30) DEFAULT NULL,
  `thumbpanel_thumb_height` char(30) DEFAULT NULL,
  `thumbpanel_thumnail_panel_color` char(30) DEFAULT NULL,
  `infopanel_panel_position` char(30) DEFAULT '',
  `infopanel_presentation` char(30) DEFAULT NULL,
  `infopanel_bg_color_fill` char(30) DEFAULT NULL,
  `infopanel_panel_click_action` char(30) DEFAULT NULL,
  `infopanel_open_link_in` char(30) DEFAULT 'new-browser',
  `infopanel_show_title` char(30) DEFAULT 'yes',
  `infopanel_title_css` char(250) DEFAULT NULL,
  `infopanel_show_des` char(30) DEFAULT 'yes',
  `infopanel_des_lenght_limitation` char(30) DEFAULT '',
  `infopanel_des_css` char(250) DEFAULT NULL,
  `infopanel_show_link` char(30) DEFAULT 'no',
  `infopanel_link_css` char(250) DEFAULT NULL,
  `toolbarpanel_presentation` char(30) DEFAULT '0',
  `toolbarpanel_show_counter` char(30) DEFAULT 'no',
  `slideshow_slide_timing` char(50) DEFAULT NULL,
  `slideshow_auto_play` char(30) DEFAULT 'no',
  `slideshow_looping` char(30) DEFAULT 'yes',
  `general_round_corner_radius` char(30) DEFAULT '',
  `general_border_color` char(30) DEFAULT '',
  `general_background_color` char(30) DEFAULT '',
  `general_border_stroke` char(30) DEFAULT '',
  `infopanel_show_link_title` char(30) DEFAULT 'no',
  `infopanel_show_link_title_in` char(30) DEFAULT 'new-browser',
  PRIMARY KEY (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_theme_classic_parameters`;
CREATE TABLE `lal5d_imageshow_theme_classic_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `general_swf_library` tinyint(1) DEFAULT '0',
  `root_url` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_theme_flow`;
CREATE TABLE `lal5d_imageshow_theme_flow` (
  `theme_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `image_source` char(150) DEFAULT 'thumbnails',
  `image_width` char(150) DEFAULT '150',
  `image_height` char(150) DEFAULT '150',
  `image_border_thickness` char(150) DEFAULT '3',
  `image_border_rounded_corner` char(150) DEFAULT '2',
  `image_border_color` char(150) DEFAULT '',
  `image_effect` char(150) DEFAULT 'yes',
  `transparency` char(150) DEFAULT '50',
  `background_type` char(150) DEFAULT 'transparent',
  `background_color` char(150) DEFAULT '',
  `container_side_fade` char(150) DEFAULT 'white',
  `animation_duration` char(150) DEFAULT '1',
  `click_action` char(150) DEFAULT 'show_original_image',
  `open_link_in` char(150) DEFAULT 'current_browser',
  `orientation` char(150) DEFAULT 'horizontal',
  `enable_keyboard_action` char(150) DEFAULT 'yes',
  `enable_mouse_wheel_action` char(150) DEFAULT 'yes',
  `show_caption` char(150) DEFAULT 'yes',
  `caption_background_color` char(150) DEFAULT '',
  `caption_opacity` char(150) DEFAULT '75',
  `caption_show_title` char(150) DEFAULT 'yes',
  `caption_title_css` text,
  `caption_show_description` char(150) DEFAULT 'yes',
  `caption_description_length_limitation` char(150) DEFAULT '50',
  `caption_description_css` text,
  `auto_play` char(150) DEFAULT 'no',
  `slide_timing` char(150) DEFAULT '3',
  `pause_on_mouse_over` char(150) DEFAULT 'yes',
  PRIMARY KEY (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_theme_grid`;
CREATE TABLE `lal5d_imageshow_theme_grid` (
  `theme_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `image_source` char(150) NOT NULL DEFAULT 'thumbnail',
  `show_caption` char(150) DEFAULT 'yes',
  `caption_show_description` char(150) DEFAULT 'yes',
  `show_close` char(150) DEFAULT 'yes',
  `show_thumbs` char(150) DEFAULT 'yes',
  `click_action` char(150) DEFAULT 'show_original_image',
  `open_link_in` char(150) DEFAULT 'current_browser',
  `img_layout` char(5) DEFAULT 'fixed',
  `background_color` char(30) DEFAULT '',
  `thumbnail_width` int(11) DEFAULT '50',
  `thumbnail_height` int(11) DEFAULT '50',
  `thumbnail_space` int(11) DEFAULT '10',
  `thumbnail_border` int(11) DEFAULT '3',
  `thumbnail_rounded_corner` int(11) DEFAULT '3',
  `thumbnail_border_color` char(30) DEFAULT '',
  `thumbnail_shadow` char(1) DEFAULT '1',
  `container_height_type` char(150) DEFAULT 'inherited',
  `container_transparent_background` char(150) DEFAULT 'no',
  `auto_play` char(150) DEFAULT 'no',
  `slide_timing` char(150) DEFAULT '3',
  `item_per_page` char(150) DEFAULT '3',
  `navigation_type` char(150) DEFAULT 'show_all',
  PRIMARY KEY (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_theme_profile`;
CREATE TABLE `lal5d_imageshow_theme_profile` (
  `theme_id` int(11) NOT NULL DEFAULT '0',
  `showcase_id` int(11) NOT NULL DEFAULT '0',
  `theme_name` varchar(255) NOT NULL DEFAULT '',
  `theme_style_name` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_theme_slider`;
CREATE TABLE `lal5d_imageshow_theme_slider` (
  `theme_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `img_transition_effect` char(30) DEFAULT 'random',
  `img_transparent_background` char(150) DEFAULT 'no',
  `toolbar_navigation_arrows_presentation` char(30) DEFAULT 'show-on-mouse-over',
  `toolbar_slideshow_player_presentation` char(30) DEFAULT 'hide',
  `caption_show_caption` char(30) DEFAULT 'yes',
  `caption_title_css` text,
  `caption_description_css` text,
  `caption_link_css` text,
  `caption_caption_opacity` char(30) DEFAULT '75',
  `caption_title_show` char(30) DEFAULT 'yes',
  `caption_description_show` char(30) DEFAULT 'yes',
  `caption_link_show` char(30) DEFAULT 'no',
  `caption_position` char(150) DEFAULT 'bottom',
  `slideshow_slide_timming` int(11) DEFAULT '6',
  `slideshow_pause_on_mouseover` char(30) DEFAULT 'yes',
  `slideshow_auto_play` char(30) DEFAULT 'yes',
  `thumnail_panel_position` char(30) DEFAULT 'right',
  `thumbnail_panel_presentation` char(30) DEFAULT 'show',
  `thumbnail_presentation_mode` char(30) DEFAULT 'numbers',
  `thumbnail_active_state_color` char(30) DEFAULT '',
  `click_action` char(150) DEFAULT 'no_action',
  `open_link_in` char(150) DEFAULT 'current_browser',
  `transition_speed` char(150) DEFAULT '1',
  PRIMARY KEY (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_imageshow_theme_strip`;
CREATE TABLE `lal5d_imageshow_theme_strip` (
  `theme_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `slideshow_sliding_speed` char(150) NOT NULL DEFAULT '500',
  `image_orientation` char(150) NOT NULL DEFAULT 'horizontal',
  `image_width` char(150) NOT NULL DEFAULT '130',
  `image_height` char(150) NOT NULL DEFAULT '130',
  `image_space` char(150) NOT NULL DEFAULT '10',
  `image_border` char(150) NOT NULL DEFAULT '3',
  `image_rounded_corner` char(150) NOT NULL DEFAULT '3',
  `image_shadow` char(150) NOT NULL DEFAULT 'no_shadow',
  `image_border_color` char(150) NOT NULL DEFAULT '',
  `image_click_action` char(150) NOT NULL DEFAULT 'no-action',
  `image_source` char(150) NOT NULL DEFAULT 'thumbnail',
  `show_caption` char(150) NOT NULL DEFAULT 'yes',
  `caption_background_color` char(150) NOT NULL DEFAULT '',
  `caption_opacity` char(150) NOT NULL DEFAULT '75',
  `caption_show_title` char(150) NOT NULL DEFAULT 'yes',
  `caption_title_css` text NOT NULL,
  `caption_show_description` char(150) NOT NULL DEFAULT 'yes',
  `caption_description_length_limitation` char(150) NOT NULL DEFAULT '50',
  `caption_description_css` text NOT NULL,
  `container_type` char(150) NOT NULL DEFAULT 'elastislide-default',
  `container_border_color` char(150) NOT NULL DEFAULT '',
  `container_border` char(150) NOT NULL DEFAULT '1',
  `container_round_corner` char(150) NOT NULL DEFAULT '0',
  `container_background_color` char(150) NOT NULL DEFAULT '',
  `container_side_fade` char(150) NOT NULL DEFAULT 'white',
  `open_link_in` char(150) DEFAULT 'current_browser',
  `slideshow_auto_play` char(150) DEFAULT 'no',
  `slideshow_delay_time` char(150) DEFAULT '3000',
  PRIMARY KEY (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_easyslider_config`;
CREATE TABLE `lal5d_jsn_easyslider_config` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_easyslider_messages`;
CREATE TABLE `lal5d_jsn_easyslider_messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_screen` varchar(150) DEFAULT NULL,
  `published` tinyint(1) DEFAULT '1',
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`msg_id`),
  UNIQUE KEY `message` (`msg_screen`,`ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_easyslider_sliders`;
CREATE TABLE `lal5d_jsn_easyslider_sliders` (
  `slider_id` int(11) NOT NULL AUTO_INCREMENT,
  `slider_title` varchar(255) NOT NULL,
  `slider_data` longtext,
  `published` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `access` int(11) NOT NULL,
  PRIMARY KEY (`slider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_imageshow_config`;
CREATE TABLE `lal5d_jsn_imageshow_config` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO lal5d_jsn_imageshow_config
(`name`, `value`) VALUES 
('live_update_notification', '1');

DROP TABLE IF EXISTS `lal5d_jsn_imageshow_messages`;
CREATE TABLE `lal5d_jsn_imageshow_messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_screen` varchar(150) DEFAULT NULL,
  `published` tinyint(1) DEFAULT '1',
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_jsn_imageshow_messages
(`msg_id`, `msg_screen`, `published`, `ordering`) VALUES 
('1', 'LAUNCH_PAD', '1', '1'),
('2', 'LAUNCH_PAD', '1', '2'),
('3', 'SHOWLISTS', '1', '1');

DROP TABLE IF EXISTS `lal5d_jsn_mobilize_config`;
CREATE TABLE `lal5d_jsn_mobilize_config` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_mobilize_design`;
CREATE TABLE `lal5d_jsn_mobilize_design` (
  `design_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`design_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_mobilize_messages`;
CREATE TABLE `lal5d_jsn_mobilize_messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_screen` varchar(150) DEFAULT NULL,
  `published` tinyint(1) DEFAULT '1',
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`msg_id`),
  UNIQUE KEY `message` (`msg_screen`,`ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_mobilize_os`;
CREATE TABLE `lal5d_jsn_mobilize_os` (
  `os_id` int(11) NOT NULL AUTO_INCREMENT,
  `os_value` varchar(255) NOT NULL,
  `os_type` varchar(50) NOT NULL,
  `os_title` varchar(255) NOT NULL,
  `os_order` int(11) NOT NULL,
  PRIMARY KEY (`os_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_jsn_mobilize_os
(`os_id`, `os_value`, `os_type`, `os_title`, `os_order`) VALUES 
('1', '{\"ios\":[\"6\",\"<\"]}', 'ios', 'iOS 6.x and bellow', '1'),
('2', '{\"ios\":[\"7\"]}', 'ios', 'iOS 7.x', '2'),
('3', '{\"android\":[\"2\"]}', 'android', 'Android 2.2 - 2.3', '4'),
('4', '{\"android\":[\"4\"]}', 'android', 'Android 4.x', '5'),
('5', '{\"wmobilie\":[\"6\",\"<\"]}', 'wmobilie', 'Windows Mobile 6.x and bellow', '6'),
('6', '{\"wmobilie\":[\"7\"]}', 'wmobilie', 'Windows Mobile 7.x', '7'),
('7', '{\"wmobilie\":[\"8\"]}', 'wmobilie', 'Windows Mobile 8.x', '8'),
('8', '{\"blackberry\":[\"5\",\"<\"]}', 'blackberry', 'BlackBerry 5.x and bellow', '9'),
('9', '{\"blackberry\":[\"6\",\"7\"]}', 'blackberry', 'BlackBerry 6x - 7x', '10'),
('10', '{\"blackberry\":[\"10\"]}', 'blackberry', 'BlackBerry 10x', '11'),
('11', 'other', 'other', 'Other', '12'),
('12', '{\"ios\":[\"8\",\">\"]}', 'ios', 'iOS 8.x and above', '3');

DROP TABLE IF EXISTS `lal5d_jsn_mobilize_os_support`;
CREATE TABLE `lal5d_jsn_mobilize_os_support` (
  `support_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_id` int(11) NOT NULL,
  `os_id` int(11) NOT NULL,
  PRIMARY KEY (`support_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_mobilize_profiles`;
CREATE TABLE `lal5d_jsn_mobilize_profiles` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_title` varchar(255) NOT NULL,
  `profile_description` text NOT NULL,
  `profile_state` int(11) NOT NULL,
  `profile_minify` varchar(50) NOT NULL,
  `profile_optimize_images` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `profile_device` varchar(10) NOT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_pagebuilder_config`;
CREATE TABLE `lal5d_jsn_pagebuilder_config` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO lal5d_jsn_pagebuilder_config
(`name`, `value`) VALUES 
('live_update_notification', '1');

DROP TABLE IF EXISTS `lal5d_jsn_pagebuilder_content_custom_css`;
CREATE TABLE `lal5d_jsn_pagebuilder_content_custom_css` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content` bigint(20) unsigned NOT NULL DEFAULT '0',
  `css_key` varchar(255) DEFAULT NULL,
  `css_value` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_pagebuilder_messages`;
CREATE TABLE `lal5d_jsn_pagebuilder_messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_screen` varchar(150) DEFAULT NULL,
  `published` tinyint(1) DEFAULT '1',
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`msg_id`),
  UNIQUE KEY `message` (`msg_screen`,`ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_poweradmin_config`;
CREATE TABLE `lal5d_jsn_poweradmin_config` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_poweradmin_favourite`;
CREATE TABLE `lal5d_jsn_poweradmin_favourite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `icon` text NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_poweradmin_history`;
CREATE TABLE `lal5d_jsn_poweradmin_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `object_key` varchar(255) NOT NULL,
  `object_id` int(11) NOT NULL,
  `component` varchar(255) NOT NULL,
  `list_page` varchar(255) NOT NULL,
  `list_page_params` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` tinytext NOT NULL,
  `form` text NOT NULL,
  `form_hash` varchar(32) NOT NULL,
  `params` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `css` varchar(100) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `visited` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_poweradmin_menu_assets`;
CREATE TABLE `lal5d_jsn_poweradmin_menu_assets` (
  `menuId` int(16) NOT NULL,
  `assets` text,
  `type` enum('css','js') NOT NULL DEFAULT 'css',
  `legacy` tinyint(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_tplframework_megamenu`;
CREATE TABLE `lal5d_jsn_tplframework_megamenu` (
  `megamenu_id` int(11) NOT NULL AUTO_INCREMENT,
  `style_id` int(11) DEFAULT NULL,
  `language_code` varchar(250) DEFAULT NULL,
  `menu_type` varchar(250) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` mediumtext,
  PRIMARY KEY (`megamenu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_uniform_config`;
CREATE TABLE `lal5d_jsn_uniform_config` (
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_uniform_emails`;
CREATE TABLE `lal5d_jsn_uniform_emails` (
  `email_id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `email_name` varchar(70) DEFAULT NULL,
  `email_address` varchar(255) NOT NULL,
  `email_state` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_uniform_fields`;
CREATE TABLE `lal5d_jsn_uniform_fields` (
  `field_id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL,
  `field_type` varchar(45) NOT NULL,
  `field_identifier` varchar(255) NOT NULL,
  `field_title` varchar(255) DEFAULT NULL,
  `field_instructions` text,
  `field_position` varchar(50) NOT NULL,
  `field_ordering` int(10) unsigned NOT NULL DEFAULT '0',
  `field_settings` text,
  PRIMARY KEY (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_uniform_form_pages`;
CREATE TABLE `lal5d_jsn_uniform_form_pages` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `form_id` int(11) NOT NULL,
  `page_content` longtext NOT NULL,
  `page_template` longtext NOT NULL,
  `page_container` longtext NOT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_uniform_forms`;
CREATE TABLE `lal5d_jsn_uniform_forms` (
  `form_id` int(11) NOT NULL AUTO_INCREMENT,
  `form_title` varchar(255) NOT NULL,
  `form_description` text,
  `form_layout` varchar(50) NOT NULL,
  `form_theme` varchar(45) NOT NULL,
  `form_style` text,
  `form_notify_submitter` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `form_post_action` tinyint(1) unsigned NOT NULL COMMENT '1 = Redirect to URL; 2 = Redirect to Menu Item; 3 = Show Article; 4 = Show custom message',
  `form_post_action_data` text NOT NULL,
  `form_captcha` tinyint(1) unsigned NOT NULL,
  `form_payment_type` varchar(255) NOT NULL DEFAULT '',
  `form_state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `form_access` int(11) NOT NULL,
  `form_created_by` int(10) unsigned NOT NULL,
  `form_created_at` datetime DEFAULT NULL,
  `form_modified_by` int(10) unsigned DEFAULT '0',
  `form_modified_at` datetime DEFAULT NULL,
  `form_checked_out` int(10) unsigned DEFAULT '0',
  `form_checked_out_time` datetime DEFAULT NULL,
  `form_submission_cout` int(11) NOT NULL,
  `form_last_submitted` datetime NOT NULL,
  `form_submitter` varchar(255) NOT NULL,
  `form_type` int(11) NOT NULL,
  `form_settings` longtext NOT NULL,
  `form_edit_submission` int(11) NOT NULL,
  `form_view_submission` int(11) NOT NULL DEFAULT '0',
  `form_view_submission_access` int(11) NOT NULL DEFAULT '0',
  `form_meta_keywords` text NOT NULL,
  `form_meta_desc` text NOT NULL,
  `form_meta_title` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `form_script_display` text NOT NULL,
  `form_script_on_process` text NOT NULL,
  `form_script_on_processed` text NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_uniform_messages`;
CREATE TABLE `lal5d_jsn_uniform_messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_screen` varchar(150) DEFAULT '',
  `published` tinyint(1) DEFAULT '1',
  `ordering` int(11) DEFAULT '0',
  PRIMARY KEY (`msg_id`),
  UNIQUE KEY `message` (`msg_screen`,`ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_uniform_submission_data`;
CREATE TABLE `lal5d_jsn_uniform_submission_data` (
  `submission_data_id` int(11) NOT NULL AUTO_INCREMENT,
  `submission_id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `field_type` varchar(45) NOT NULL,
  `submission_data_value` longtext NOT NULL,
  PRIMARY KEY (`submission_data_id`),
  KEY `submission_data_id` (`submission_data_id`),
  KEY `submission_id` (`submission_id`),
  KEY `form_id` (`form_id`),
  KEY `field_id` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_uniform_submissions`;
CREATE TABLE `lal5d_jsn_uniform_submissions` (
  `submission_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `submission_form_location` text NOT NULL,
  `submission_ip` varchar(40) NOT NULL,
  `submission_country` varchar(45) NOT NULL,
  `submission_country_code` varchar(4) NOT NULL,
  `submission_browser` varchar(45) NOT NULL,
  `submission_browser_version` varchar(20) NOT NULL,
  `submission_browser_agent` varchar(255) NOT NULL,
  `submission_os` varchar(45) NOT NULL,
  `submission_created_by` int(10) unsigned NOT NULL COMMENT '0 = Guest',
  `submission_created_at` datetime NOT NULL,
  `submission_state` tinyint(1) unsigned NOT NULL COMMENT '-1 = Trashed; 0 = Unpublish; 1 = Published',
  PRIMARY KEY (`submission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_jsn_uniform_templates`;
CREATE TABLE `lal5d_jsn_uniform_templates` (
  `template_id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL,
  `template_notify_to` tinyint(1) NOT NULL COMMENT '0 = Send to submitter; 1 = Send to added emails',
  `template_from` varchar(75) NOT NULL,
  `template_from_name` varchar(255) NOT NULL,
  `template_reply_to` varchar(75) NOT NULL,
  `template_subject` varchar(255) NOT NULL,
  `template_message` longtext NOT NULL,
  `template_attach` text NOT NULL,
  PRIMARY KEY (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_languages`;
CREATE TABLE `lal5d_languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `lang_code` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_native` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sef` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sitename` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_access` (`access`),
  KEY `idx_ordering` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_languages
(`lang_id`, `asset_id`, `lang_code`, `title`, `title_native`, `sef`, `image`, `description`, `metakey`, `metadesc`, `sitename`, `published`, `access`, `ordering`) VALUES 
('1', '0', 'en-GB', 'English (UK)', 'English (UK)', 'en', 'en_gb', '', '', '', '', '1', '1', '1');

DROP TABLE IF EXISTS `lal5d_menu`;
CREATE TABLE `lal5d_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`(100),`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`(100)),
  KEY `idx_path` (`path`(100)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_menu
(`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES 
('1', '', 'Menu_Item_Root', 'root', '', '', '', '', '1', '0', '0', '0', '0', '0000-00-00 00:00:00', '0', '0', '', '0', '', '0', '151', '0', '*', '0'),
('2', 'menu', 'com_banners', 'Banners', '', 'Banners', 'index.php?option=com_banners', 'component', '0', '1', '1', '4', '0', '0000-00-00 00:00:00', '0', '0', 'class:banners', '0', '', '1', '10', '0', '*', '1'),
('3', 'menu', 'com_banners', 'Banners', '', 'Banners/Banners', 'index.php?option=com_banners', 'component', '0', '2', '2', '4', '0', '0000-00-00 00:00:00', '0', '0', 'class:banners', '0', '', '2', '3', '0', '*', '1'),
('4', 'menu', 'com_banners_categories', 'Categories', '', 'Banners/Categories', 'index.php?option=com_categories&extension=com_banners', 'component', '0', '2', '2', '6', '0', '0000-00-00 00:00:00', '0', '0', 'class:banners-cat', '0', '', '4', '5', '0', '*', '1'),
('5', 'menu', 'com_banners_clients', 'Clients', '', 'Banners/Clients', 'index.php?option=com_banners&view=clients', 'component', '0', '2', '2', '4', '0', '0000-00-00 00:00:00', '0', '0', 'class:banners-clients', '0', '', '6', '7', '0', '*', '1'),
('6', 'menu', 'com_banners_tracks', 'Tracks', '', 'Banners/Tracks', 'index.php?option=com_banners&view=tracks', 'component', '0', '2', '2', '4', '0', '0000-00-00 00:00:00', '0', '0', 'class:banners-tracks', '0', '', '8', '9', '0', '*', '1'),
('7', 'menu', 'com_contact', 'Contacts', '', 'Contacts', 'index.php?option=com_contact', 'component', '0', '1', '1', '8', '0', '0000-00-00 00:00:00', '0', '0', 'class:contact', '0', '', '11', '16', '0', '*', '1'),
('8', 'menu', 'com_contact_contacts', 'Contacts', '', 'Contacts/Contacts', 'index.php?option=com_contact', 'component', '0', '7', '2', '8', '0', '0000-00-00 00:00:00', '0', '0', 'class:contact', '0', '', '12', '13', '0', '*', '1'),
('9', 'menu', 'com_contact_categories', 'Categories', '', 'Contacts/Categories', 'index.php?option=com_categories&extension=com_contact', 'component', '0', '7', '2', '6', '0', '0000-00-00 00:00:00', '0', '0', 'class:contact-cat', '0', '', '14', '15', '0', '*', '1'),
('10', 'menu', 'com_messages', 'Messaging', '', 'Messaging', 'index.php?option=com_messages', 'component', '0', '1', '1', '15', '0', '0000-00-00 00:00:00', '0', '0', 'class:messages', '0', '', '17', '20', '0', '*', '1'),
('11', 'menu', 'com_messages_add', 'New Private Message', '', 'Messaging/New Private Message', 'index.php?option=com_messages&task=message.add', 'component', '0', '10', '2', '15', '0', '0000-00-00 00:00:00', '0', '0', 'class:messages-add', '0', '', '18', '19', '0', '*', '1'),
('13', 'menu', 'com_newsfeeds', 'News Feeds', '', 'News Feeds', 'index.php?option=com_newsfeeds', 'component', '0', '1', '1', '17', '0', '0000-00-00 00:00:00', '0', '0', 'class:newsfeeds', '0', '', '21', '26', '0', '*', '1'),
('14', 'menu', 'com_newsfeeds_feeds', 'Feeds', '', 'News Feeds/Feeds', 'index.php?option=com_newsfeeds', 'component', '0', '13', '2', '17', '0', '0000-00-00 00:00:00', '0', '0', 'class:newsfeeds', '0', '', '22', '23', '0', '*', '1'),
('15', 'menu', 'com_newsfeeds_categories', 'Categories', '', 'News Feeds/Categories', 'index.php?option=com_categories&extension=com_newsfeeds', 'component', '0', '13', '2', '6', '0', '0000-00-00 00:00:00', '0', '0', 'class:newsfeeds-cat', '0', '', '24', '25', '0', '*', '1'),
('16', 'menu', 'com_redirect', 'Redirect', '', 'Redirect', 'index.php?option=com_redirect', 'component', '0', '1', '1', '24', '0', '0000-00-00 00:00:00', '0', '0', 'class:redirect', '0', '', '27', '28', '0', '*', '1'),
('17', 'menu', 'com_search', 'Basic Search', '', 'Basic Search', 'index.php?option=com_search', 'component', '0', '1', '1', '19', '0', '0000-00-00 00:00:00', '0', '0', 'class:search', '0', '', '29', '30', '0', '*', '1'),
('18', 'menu', 'com_finder', 'Smart Search', '', 'Smart Search', 'index.php?option=com_finder', 'component', '0', '1', '1', '27', '0', '0000-00-00 00:00:00', '0', '0', 'class:finder', '0', '', '31', '32', '0', '*', '1'),
('19', 'menu', 'com_joomlaupdate', 'Joomla! Update', '', 'Joomla! Update', 'index.php?option=com_joomlaupdate', 'component', '1', '1', '1', '28', '0', '0000-00-00 00:00:00', '0', '0', 'class:joomlaupdate', '0', '', '33', '34', '0', '*', '1'),
('20', 'main', 'com_tags', 'Tags', '', 'Tags', 'index.php?option=com_tags', 'component', '0', '1', '1', '29', '0', '0000-00-00 00:00:00', '0', '1', 'class:tags', '0', '', '35', '36', '0', '', '1'),
('21', 'main', 'com_postinstall', 'Post-installation messages', '', 'Post-installation messages', 'index.php?option=com_postinstall', 'component', '0', '1', '1', '32', '0', '0000-00-00 00:00:00', '0', '1', 'class:postinstall', '0', '', '37', '38', '0', '*', '1'),
('101', 'mainmenu', 'Home', 'home', '', 'home', 'index.php?option=com_content&view=featured', 'component', '1', '1', '1', '22', '0', '0000-00-00 00:00:00', '0', '1', '', '0', '{\"featured_categories\":[\"\"],\"layout_type\":\"blog\",\"num_leading_articles\":\"1\",\"num_intro_articles\":\"3\",\"num_columns\":\"3\",\"num_links\":\"0\",\"multi_column_order\":\"1\",\"orderby_pri\":\"\",\"orderby_sec\":\"front\",\"order_date\":\"\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"1\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":1,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}', '39', '40', '1', '*', '0'),
('102', 'main', 'COM_VIRTUEMART', 'com-virtuemart', '', 'com-virtuemart', 'index.php?option=com_virtuemart', 'component', '0', '1', '1', '10000', '0', '0000-00-00 00:00:00', '0', '1', '../components/com_virtuemart/assets/images/vmgeneral/menu_icon.png', '0', '{}', '41', '66', '0', '', '1'),
('103', 'main', 'COM_VIRTUEMART_CONTROL_PANEL', 'com-virtuemart-control-panel', '', 'com-virtuemart/com-virtuemart-control-panel', 'index.php?option=com_virtuemart&view=virtuemart', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-report.png', '0', '{}', '42', '43', '0', '', '1'),
('104', 'main', 'COM_VIRTUEMART_MENU_CATEGORIES', 'com-virtuemart-menu-categories', '', 'com-virtuemart/com-virtuemart-menu-categories', 'index.php?option=com_virtuemart&view=category', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-categories.png', '0', '{}', '44', '45', '0', '', '1'),
('105', 'main', 'COM_VIRTUEMART_MENU_PRODUCTS', 'com-virtuemart-menu-products', '', 'com-virtuemart/com-virtuemart-menu-products', 'index.php?option=com_virtuemart&view=product', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-products.png', '0', '{}', '46', '47', '0', '', '1'),
('106', 'main', 'COM_VIRTUEMART_MENU_ORDERS', 'com-virtuemart-menu-orders', '', 'com-virtuemart/com-virtuemart-menu-orders', 'index.php?option=com_virtuemart&view=orders', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-orders.png', '0', '{}', '48', '49', '0', '', '1'),
('107', 'main', 'COM_VIRTUEMART_MENU_REPORT', 'com-virtuemart-menu-report', '', 'com-virtuemart/com-virtuemart-menu-report', 'index.php?option=com_virtuemart&view=report', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-report.png', '0', '{}', '50', '51', '0', '', '1'),
('108', 'main', 'COM_VIRTUEMART_MENU_USERS', 'com-virtuemart-menu-users', '', 'com-virtuemart/com-virtuemart-menu-users', 'index.php?option=com_virtuemart&view=user', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-shoppers.png', '0', '{}', '52', '53', '0', '', '1'),
('109', 'main', 'COM_VIRTUEMART_MENU_MANUFACTURERS', 'com-virtuemart-menu-manufacturers', '', 'com-virtuemart/com-virtuemart-menu-manufacturers', 'index.php?option=com_virtuemart&view=manufacturer', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-manufacturers.png', '0', '{}', '54', '55', '0', '', '1'),
('110', 'main', 'COM_VIRTUEMART_MENU_STORE', 'com-virtuemart-menu-store', '', 'com-virtuemart/com-virtuemart-menu-store', 'index.php?option=com_virtuemart&view=user&task=editshop', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-shop.png', '0', '{}', '56', '57', '0', '', '1'),
('111', 'main', 'COM_VIRTUEMART_MENU_MEDIAFILES', 'com-virtuemart-menu-mediafiles', '', 'com-virtuemart/com-virtuemart-menu-mediafiles', 'index.php?option=com_virtuemart&view=media', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-media.png', '0', '{}', '58', '59', '0', '', '1'),
('112', 'main', 'COM_VIRTUEMART_MENU_SHIPMENTMETHODS', 'com-virtuemart-menu-shipmentmethods', '', 'com-virtuemart/com-virtuemart-menu-shipmentmethods', 'index.php?option=com_virtuemart&view=shipmentmethod', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-shipmentmethods.png', '0', '{}', '60', '61', '0', '', '1'),
('113', 'main', 'COM_VIRTUEMART_MENU_PAYMENTMETHODS', 'com-virtuemart-menu-paymentmethods', '', 'com-virtuemart/com-virtuemart-menu-paymentmethods', 'index.php?option=com_virtuemart&view=paymentmethod', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-paymentmethods.png', '0', '{}', '62', '63', '0', '', '1'),
('114', 'main', 'COM_VIRTUEMART_MENU_CONFIGURATION', 'com-virtuemart-menu-configuration', '', 'com-virtuemart/com-virtuemart-menu-configuration', 'index.php?option=com_virtuemart&view=config', 'component', '0', '102', '2', '10000', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_virtuemart/assets/images/icon_16/menu-icon16-config.png', '0', '{}', '64', '65', '0', '', '1'),
('115', 'main', 'VirtueMart AIO', 'virtuemart-aio', '', 'virtuemart-aio', 'index.php?option=com_virtuemart_allinone', 'component', '0', '1', '1', '10001', '0', '0000-00-00 00:00:00', '0', '1', 'class:component', '0', '{}', '67', '68', '0', '', '1'),
('116', 'mainmenu', 'Color Variation', 'color-variation', '', 'color-variation', 'index.php?option=com_content&view=article&id=2', 'component', '-2', '1', '1', '22', '0', '0000-00-00 00:00:00', '0', '1', ' ', '0', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"dropdown_position\":\"right\",\"showmenutitle\":\"1\",\"icon\":\"\",\"class\":\"\",\"enable_page_title\":\"0\",\"page_title_alt\":\"\",\"page_subtitle\":\"\",\"page_title_bg_color\":\"\",\"page_title_bg_image\":\"\"}', '69', '70', '0', '*', '0'),
('117', 'mainmenu', 'Service', 'service', '', 'service', 'index.php?option=com_content&view=article&id=3', 'component', '1', '1', '1', '22', '0', '0000-00-00 00:00:00', '0', '1', ' ', '0', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"dropdown_position\":\"right\",\"showmenutitle\":\"1\",\"icon\":\"\",\"class\":\"\",\"enable_page_title\":\"0\",\"page_title_alt\":\"\",\"page_subtitle\":\"\",\"page_title_bg_color\":\"\",\"page_title_bg_image\":\"\"}', '71', '72', '0', '*', '0'),
('118', 'mainmenu', 'Contact', 'contact', '', 'contact', 'index.php?option=com_content&view=article&id=4', 'component', '1', '1', '1', '22', '0', '0000-00-00 00:00:00', '0', '1', ' ', '0', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"dropdown_position\":\"right\",\"showmenutitle\":\"1\",\"icon\":\"\",\"class\":\"\",\"enable_page_title\":\"0\",\"page_title_alt\":\"\",\"page_subtitle\":\"\",\"page_title_bg_color\":\"\",\"page_title_bg_image\":\"\"}', '73', '74', '0', '*', '0'),
('119', 'mainmenu', 'Color Variations', 'color-variations', '', 'color-variations', 'index.php?option=com_content&view=article&id=6', 'component', '1', '1', '1', '22', '0', '0000-00-00 00:00:00', '0', '1', ' ', '0', '{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"info_block_show_title\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0,\"dropdown_position\":\"right\",\"showmenutitle\":\"1\",\"icon\":\"\",\"class\":\"\",\"enable_page_title\":\"0\",\"page_title_alt\":\"\",\"page_subtitle\":\"\",\"page_title_bg_color\":\"\",\"page_title_bg_image\":\"\"}', '75', '76', '0', '*', '0'),
('120', 'main', 'COM_FLIPPINGBOOK_MENU', 'com-flippingbook-menu', '', 'com-flippingbook-menu', 'index.php?option=com_flippingbook', 'component', '0', '1', '1', '10040', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_flippingbook/images/icon_fb.png', '0', '{}', '77', '90', '0', '', '1'),
('121', 'main', 'COM_CONFIGURATION_MENU', 'com-configuration-menu', '', 'com-flippingbook-menu/com-configuration-menu', 'index.php?option=com_flippingbook&view=configuration', 'component', '0', '120', '2', '10040', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_flippingbook/images/icon_config.png', '0', '{}', '78', '79', '0', '', '1'),
('122', 'main', 'COM_MANAGE_CATEGORIES_MENU', 'com-manage-categories-menu', '', 'com-flippingbook-menu/com-manage-categories-menu', 'index.php?option=com_flippingbook&view=categories', 'component', '0', '120', '2', '10040', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_flippingbook/images/icon_cm.png', '0', '{}', '80', '81', '0', '', '1'),
('123', 'main', 'COM_MANAGE_BOOKS_MENU', 'com-manage-books-menu', '', 'com-flippingbook-menu/com-manage-books-menu', 'index.php?option=com_flippingbook&view=books', 'component', '0', '120', '2', '10040', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_flippingbook/images/icon_bm.png', '0', '{}', '82', '83', '0', '', '1'),
('124', 'main', 'COM_MANAGE_PAGES_MENU', 'com-manage-pages-menu', '', 'com-flippingbook-menu/com-manage-pages-menu', 'index.php?option=com_flippingbook&view=pages', 'component', '0', '120', '2', '10040', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_flippingbook/images/icon_pm.png', '0', '{}', '84', '85', '0', '', '1'),
('125', 'main', 'COM_BATCH_ADDING_PAGES_MENU', 'com-batch-adding-pages-menu', '', 'com-flippingbook-menu/com-batch-adding-pages-menu', 'index.php?option=com_flippingbook&view=batchaddingpages', 'component', '0', '120', '2', '10040', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_flippingbook/images/icon_batch.png', '0', '{}', '86', '87', '0', '', '1'),
('126', 'main', 'COM_MANAGE_FILES_MENU', 'com-manage-files-menu', '', 'com-flippingbook-menu/com-manage-files-menu', 'index.php?option=com_flippingbook&view=filemanager', 'component', '0', '120', '2', '10040', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_flippingbook/images/icon_fm.png', '0', '{}', '88', '89', '0', '', '1'),
('128', 'main', 'COM_AKEEBA', 'com-akeeba', '', 'com-akeeba', 'index.php?option=com_akeeba', 'component', '1', '1', '1', '10041', '0', '0000-00-00 00:00:00', '0', '1', '../media/com_akeeba/icons/akeeba-16.png', '0', '{}', '91', '92', '0', '', '1'),
('139', 'main', 'COM_PAGEBUILDER', 'com-pagebuilder', '', 'com-pagebuilder', 'index.php?option=com_pagebuilder', 'component', '0', '1', '1', '10057', '0', '0000-00-00 00:00:00', '0', '1', 'class:component', '0', '{}', '93', '100', '0', '', '1'),
('140', 'main', 'COM_PAGEBUILDER_PAGE_MANAGER', 'com-pagebuilder-page-manager', '', 'com-pagebuilder/com-pagebuilder-page-manager', 'index.php?option=com_pagebuilder&view=manager', 'component', '0', '139', '2', '10057', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_pagebuilder/assets/images/icons-16/icon-monitor.png', '0', '{}', '94', '95', '0', '', '1'),
('141', 'main', 'COM_PAGEBUILDER_CONFIGURATION', 'com-pagebuilder-configuration', '', 'com-pagebuilder/com-pagebuilder-configuration', 'index.php?option=com_pagebuilder&view=configuration', 'component', '0', '139', '2', '10057', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_pagebuilder/assets/images/icons-16/icon-cog.png', '0', '{}', '96', '97', '0', '', '1');

INSERT INTO lal5d_menu
(`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES 
('142', 'main', 'COM_PAGEBUILDER_ABOUT', 'com-pagebuilder-about', '', 'com-pagebuilder/com-pagebuilder-about', 'index.php?option=com_pagebuilder&view=about', 'component', '0', '139', '2', '10057', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_poweradmin/assets/images/icons-16/icon-star.png', '0', '{}', '98', '99', '0', '', '1'),
('143', 'main', 'COM_IMAGESHOW', 'com-imageshow', '', 'com-imageshow', 'index.php?option=com_imageshow', 'component', '0', '1', '1', '10046', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_imageshow/assets/images/icons-16/icon-picture.png', '0', '{}', '101', '112', '0', '', '1'),
('144', 'main', 'LAUNCH_PAD', 'launch-pad', '', 'com-imageshow/launch-pad', 'index.php?option=com_imageshow', 'component', '0', '143', '2', '10046', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_imageshow/assets/images/icons-16/icon-off.png', '0', '{}', '102', '103', '0', '', '1'),
('145', 'main', 'SHOWLISTS', 'showlists', '', 'com-imageshow/showlists', 'index.php?option=com_imageshow&controller=showlist', 'component', '0', '143', '2', '10046', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_imageshow/assets/images/icons-16/icon-file.png', '0', '{}', '104', '105', '0', '', '1'),
('146', 'main', 'SHOWCASES', 'showcases', '', 'com-imageshow/showcases', 'index.php?option=com_imageshow&controller=showcase', 'component', '0', '143', '2', '10046', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_imageshow/assets/images/icons-16/icon-monitor.png', '0', '{}', '106', '107', '0', '', '1'),
('147', 'main', 'CONFIGURATION_AND_MAINTENANCE', 'configuration-and-maintenance', '', 'com-imageshow/configuration-and-maintenance', 'index.php?option=com_imageshow&controller=maintenance&type=configs', 'component', '0', '143', '2', '10046', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_imageshow/assets/images/icons-16/icon-cog.png', '0', '{}', '108', '109', '0', '', '1'),
('148', 'main', 'ABOUT', 'about', '', 'com-imageshow/about', 'index.php?option=com_imageshow&controller=about', 'component', '0', '143', '2', '10046', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_imageshow/assets/images/icons-16/icon-star.png', '0', '{}', '110', '111', '0', '', '1'),
('149', 'main', 'JSN_POWERADMIN_MENU_TEXT', 'jsn-poweradmin-menu-text', '', 'jsn-poweradmin-menu-text', 'index.php?option=com_poweradmin', 'component', '0', '1', '1', '10071', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_poweradmin/assets/images/icons-16/icon-wrench.png', '0', '{}', '113', '122', '0', '', '1'),
('150', 'main', 'JSN_POWERADMIN_MENU_RAWMODE_TEXT', 'jsn-poweradmin-menu-rawmode-text', '', 'jsn-poweradmin-menu-text/jsn-poweradmin-menu-rawmode-text', 'index.php?option=com_poweradmin&view=rawmode', 'component', '0', '149', '2', '10071', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_poweradmin/assets/images/icons-16/icon-monitor.png', '0', '{}', '114', '115', '0', '', '1'),
('151', 'main', 'JSN_POWERADMIN_MENU_SITESEARCH_TEXT', 'jsn-poweradmin-menu-sitesearch-text', '', 'jsn-poweradmin-menu-text/jsn-poweradmin-menu-sitesearch-text', 'index.php?option=com_poweradmin&task=search.query', 'component', '0', '149', '2', '10071', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_poweradmin/assets/images/icons-16/icon-search.png', '0', '{}', '116', '117', '0', '', '1'),
('152', 'main', 'JSN_POWERADMIN_MENU_CONFIGURATION_TEXT', 'jsn-poweradmin-menu-configuration-text', '', 'jsn-poweradmin-menu-text/jsn-poweradmin-menu-configuration-text', 'index.php?option=com_poweradmin&view=configuration', 'component', '0', '149', '2', '10071', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_poweradmin/assets/images/icons-16/icon-cog.png', '0', '{}', '118', '119', '0', '', '1'),
('153', 'main', 'JSN_POWERADMIN_MENU_ABOUT_TEXT', 'jsn-poweradmin-menu-about-text', '', 'jsn-poweradmin-menu-text/jsn-poweradmin-menu-about-text', 'index.php?option=com_poweradmin&view=about', 'component', '0', '149', '2', '10071', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_poweradmin/assets/images/icons-16/icon-star.png', '0', '{}', '120', '121', '0', '', '1'),
('154', 'main', 'JSN_UNIFORM_MENU_TEXT', 'jsn-uniform-menu-text', '', 'jsn-uniform-menu-text', 'index.php?option=com_uniform', 'component', '0', '1', '1', '10079', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_uniform/assets/images/icons-16/icon-uniform.png', '0', '{}', '123', '134', '0', '', '1'),
('155', 'main', 'JSN_UNIFORM_MENU_FORMS_TEXT', 'jsn-uniform-menu-forms-text', '', 'jsn-uniform-menu-text/jsn-uniform-menu-forms-text', 'index.php?option=com_uniform&view=forms', 'component', '0', '154', '2', '10079', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_uniform/assets/images/icons-16/icon-forms.png', '0', '{}', '124', '125', '0', '', '1'),
('156', 'main', 'JSN_UNIFORM_MENU_SUBMISSIONS_TEXT', 'jsn-uniform-menu-submissions-text', '', 'jsn-uniform-menu-text/jsn-uniform-menu-submissions-text', 'index.php?option=com_uniform&view=submissions', 'component', '0', '154', '2', '10079', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_uniform/assets/images/icons-16/icon-submissions.png', '0', '{}', '126', '127', '0', '', '1'),
('157', 'main', 'JSN_UNIFORM_MENU_INTEGRATION_TEXT', 'jsn-uniform-menu-integration-text', '', 'jsn-uniform-menu-text/jsn-uniform-menu-integration-text', 'index.php?option=com_uniform&view=integration', 'component', '0', '154', '2', '10079', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_uniform/assets/images/icons-16/icon-integration.png', '0', '{}', '128', '129', '0', '', '1'),
('158', 'main', 'JSN_UNIFORM_MENU_CONFIGURATION_TEXT', 'jsn-uniform-menu-configuration-text', '', 'jsn-uniform-menu-text/jsn-uniform-menu-configuration-text', 'index.php?option=com_uniform&view=configuration', 'component', '0', '154', '2', '10079', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_uniform/assets/images/icons-16/icon-cog.png', '0', '{}', '130', '131', '0', '', '1'),
('159', 'main', 'JSN_UNIFORM_MENU_ABOUT_TEXT', 'jsn-uniform-menu-about-text', '', 'jsn-uniform-menu-text/jsn-uniform-menu-about-text', 'index.php?option=com_uniform&view=about', 'component', '0', '154', '2', '10079', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_uniform/assets/images/icons-16/icon-about.png', '0', '{}', '132', '133', '0', '', '1'),
('160', 'main', 'JSN_MOBILIZE_MENU_TEXT', 'jsn-mobilize-menu-text', '', 'jsn-mobilize-menu-text', 'index.php?option=com_mobilize', 'component', '0', '1', '1', '10084', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_mobilize/assets/images/icon-mobilize.png', '0', '{}', '135', '142', '0', '', '1'),
('161', 'main', 'JSN_MOBILIZE_SUB_MENU_MOBILIZATION_TEXT', 'jsn-mobilize-sub-menu-mobilization-text', '', 'jsn-mobilize-menu-text/jsn-mobilize-sub-menu-mobilization-text', 'index.php?option=com_mobilize&view=profiles', 'component', '0', '160', '2', '10084', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_mobilize/assets/images/icons-16/icon-mobilize.png', '0', '{}', '136', '137', '0', '', '1'),
('162', 'main', 'JSN_MOBILIZE_SUB_MENU_CONFIGURARTION_TEXT', 'jsn-mobilize-sub-menu-configurartion-text', '', 'jsn-mobilize-menu-text/jsn-mobilize-sub-menu-configurartion-text', 'index.php?option=com_mobilize&view=configuration', 'component', '0', '160', '2', '10084', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_mobilize/assets/images/icons-16/icon-cog.png', '0', '{}', '138', '139', '0', '', '1'),
('163', 'main', 'JSN_MOBILIZE_SUB_MENU_ABOUT_TEXT', 'jsn-mobilize-sub-menu-about-text', '', 'jsn-mobilize-menu-text/jsn-mobilize-sub-menu-about-text', 'index.php?option=com_mobilize&view=about', 'component', '0', '160', '2', '10084', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_mobilize/assets/images/icons-16/icon-about.png', '0', '{}', '140', '141', '0', '', '1'),
('164', 'main', 'JSN_EASYSLIDER_MENU_TEXT', 'jsn-easyslider-menu-text', '', 'jsn-easyslider-menu-text', 'index.php?option=com_easyslider', 'component', '0', '1', '1', '10087', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_easyslider/assets/images/icon-easyslider.png', '0', '{}', '143', '150', '0', '', '1'),
('165', 'main', 'JSN_EASYSLIDER_MENU_SLIDERS_TEXT', 'jsn-easyslider-menu-sliders-text', '', 'jsn-easyslider-menu-text/jsn-easyslider-menu-sliders-text', 'index.php?option=com_easyslider&view=sliders', 'component', '0', '164', '2', '10087', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_easyslider/assets/images/icons-16/icon-items.png', '0', '{}', '144', '145', '0', '', '1'),
('166', 'main', 'JSN_EASYSLIDER_MENU_CONFIGURARTION_TEXT', 'jsn-easyslider-menu-configurartion-text', '', 'jsn-easyslider-menu-text/jsn-easyslider-menu-configurartion-text', 'index.php?option=com_easyslider&view=configuration', 'component', '0', '164', '2', '10087', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_easyslider/assets/images/icons-16/icon-configuration.png', '0', '{}', '146', '147', '0', '', '1'),
('167', 'main', 'JSN_EASYSLIDER_MENU_ABOUT_TEXT', 'jsn-easyslider-menu-about-text', '', 'jsn-easyslider-menu-text/jsn-easyslider-menu-about-text', 'index.php?option=com_easyslider&view=about', 'component', '0', '164', '2', '10087', '0', '0000-00-00 00:00:00', '0', '1', 'components/com_easyslider/assets/images/icons-16/icon-about.png', '0', '{}', '148', '149', '0', '', '1');

DROP TABLE IF EXISTS `lal5d_menu_types`;
CREATE TABLE `lal5d_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `menutype` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(48) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_menu_types
(`id`, `asset_id`, `menutype`, `title`, `description`) VALUES 
('1', '0', 'mainmenu', 'Main Menu', 'The main menu for the site');

DROP TABLE IF EXISTS `lal5d_messages`;
CREATE TABLE `lal5d_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_messages_cfg`;
CREATE TABLE `lal5d_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cfg_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_modules`;
CREATE TABLE `lal5d_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_modules
(`id`, `asset_id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES 
('1', '39', 'Main Menu', '', '', '1', 'position-7', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_menu', '1', '1', '{\"menutype\":\"mainmenu\",\"startLevel\":\"0\",\"endLevel\":\"0\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"\",\"moduleclass_sfx\":\"_menu\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}', '0', '*'),
('2', '40', 'Login', '', '', '1', 'login', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_login', '1', '1', '', '1', '*'),
('3', '41', 'Popular Articles', '', '', '3', 'cpanel', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_popular', '3', '1', '{\"count\":\"5\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}', '1', '*'),
('4', '42', 'Recently Added Articles', '', '', '4', 'cpanel', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_latest', '3', '1', '{\"count\":\"5\",\"ordering\":\"c_dsc\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}', '1', '*'),
('8', '43', 'Toolbar', '', '', '1', 'toolbar', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_toolbar', '3', '1', '', '1', '*'),
('9', '44', 'Quick Icons', '', '', '1', 'icon', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_quickicon', '3', '1', '', '1', '*'),
('10', '45', 'Logged-in Users', '', '', '2', 'cpanel', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_logged', '3', '1', '{\"count\":\"5\",\"name\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}', '1', '*'),
('12', '46', 'Admin Menu', '', '', '1', 'menu', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_menu', '3', '1', '{\"layout\":\"\",\"moduleclass_sfx\":\"\",\"shownew\":\"1\",\"showhelp\":\"1\",\"cache\":\"0\"}', '1', '*'),
('13', '47', 'Admin Submenu', '', '', '1', 'submenu', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_submenu', '3', '1', '', '1', '*'),
('14', '48', 'User Status', '', '', '2', 'status', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_status', '3', '1', '', '1', '*'),
('15', '49', 'Title', '', '', '1', 'title', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_title', '3', '1', '', '1', '*'),
('16', '50', 'Login Form', '', '', '7', 'position-7', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_login', '1', '1', '{\"greeting\":\"1\",\"name\":\"0\"}', '0', '*'),
('17', '51', 'Breadcrumbs', '', '', '1', 'position-2', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_breadcrumbs', '1', '1', '{\"moduleclass_sfx\":\"\",\"showHome\":\"1\",\"homeText\":\"\",\"showComponent\":\"1\",\"separator\":\"\",\"cache\":\"0\",\"cache_time\":\"0\",\"cachemode\":\"itemid\"}', '0', '*'),
('79', '52', 'Multilanguage status', '', '', '1', 'status', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 'mod_multilangstatus', '3', '1', '{\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}', '1', '*'),
('86', '53', 'Joomla Version', '', '', '1', 'footer', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_version', '3', '1', '{\"format\":\"short\",\"product\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}', '1', '*'),
('87', '57', 'VM - Administrator Module', '', '', '5', 'menu', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_vmmenu', '3', '1', '', '1', '*'),
('88', '58', 'VM - Currencies Selector', '', '', '5', 'position-4', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_virtuemart_currencies', '1', '1', '', '0', '*'),
('89', '59', 'VM - Featured products', '', '', '3', 'position-4', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_virtuemart_product', '1', '1', '', '0', '*'),
('90', '60', 'VM - Search in Shop', '', '', '2', 'position-4', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_virtuemart_search', '1', '1', '', '0', '*'),
('91', '61', 'VM - Manufacturer', '', '', '8', 'position-4', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_virtuemart_manufacturer', '1', '1', '', '0', '*'),
('92', '62', 'VM - Shopping cart', '', '', '0', 'position-4', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_virtuemart_cart', '1', '1', '', '0', '*'),
('93', '63', 'VM - Category', '', '', '4', 'position-4', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_virtuemart_category', '1', '1', '', '0', '*'),
('94', '64', 'menu', '', '', '1', '', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_menu', '1', '1', '{\"menutype\":\"mainmenu\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', '0', '*'),
('95', '82', 'JSN ImageShow', '', '', '0', '', '0', '0000-00-00 00:00:00', '2016-11-14 15:13:05', '0000-00-00 00:00:00', '1', 'mod_imageshow', '1', '1', '', '0', '*'),
('96', '83', 'JSN imageshow Quick Icons', '', '', '0', 'cpanel', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_imageshow_quickicon', '1', '1', '', '1', '*'),
('97', '85', 'Google Analytics Dashboard', '', '', '0', '', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 'mod_ga_dash', '1', '1', '', '1', '*'),
('98', '86', 'GTranslate', '', '', '0', '', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 'mod_gtranslate', '1', '1', '', '0', '*'),
('99', '88', 'menu', '', '', '1', 'mainmenu', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_menu', '1', '1', '{\"menutype\":\"mainmenu\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}', '0', '*'),
('100', '90', 'JSN PowerAdmin Quick Icons', '', '', '0', 'cpanel', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_poweradmin', '1', '1', '', '1', '*'),
('101', '92', 'JSN UniForm', '', '', '0', '', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', 'mod_uniform', '1', '1', '', '0', '*'),
('102', '95', 'mod_easyslider', '', '', '0', '', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', 'mod_easyslider', '1', '1', '', '0', '*');

DROP TABLE IF EXISTS `lal5d_modules_menu`;
CREATE TABLE `lal5d_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_modules_menu
(`moduleid`, `menuid`) VALUES 
('1', '0'),
('2', '0'),
('3', '0'),
('4', '0'),
('6', '0'),
('7', '0'),
('8', '0'),
('9', '0'),
('10', '0'),
('12', '0'),
('13', '0'),
('14', '0'),
('15', '0'),
('16', '0'),
('17', '0'),
('79', '0'),
('86', '0'),
('87', '0'),
('88', '0'),
('89', '0'),
('90', '0'),
('91', '0'),
('92', '0'),
('93', '0'),
('94', '0'),
('96', '0'),
('99', '0'),
('100', '0');

DROP TABLE IF EXISTS `lal5d_newsfeeds`;
CREATE TABLE `lal5d_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `link` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_overrider`;
CREATE TABLE `lal5d_overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `string` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_postinstall_messages`;
CREATE TABLE `lal5d_postinstall_messages` (
  `postinstall_message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `extension_id` bigint(20) NOT NULL DEFAULT '700' COMMENT 'FK to #__extensions',
  `title_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Lang key for the title',
  `description_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Lang key for description',
  `action_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language_extension` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'com_postinstall' COMMENT 'Extension holding lang keys',
  `language_client_id` tinyint(3) NOT NULL DEFAULT '1',
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'link' COMMENT 'Message type - message, link, action',
  `action_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'RAD URI to the PHP file containing action method',
  `action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'Action method name or URL',
  `condition_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'RAD URI to file holding display condition method',
  `condition_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Display condition method, must return boolean',
  `version_introduced` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '3.2.0' COMMENT 'Version when this message was introduced',
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`postinstall_message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_postinstall_messages
(`postinstall_message_id`, `extension_id`, `title_key`, `description_key`, `action_key`, `language_extension`, `language_client_id`, `type`, `action_file`, `action`, `condition_file`, `condition_method`, `version_introduced`, `enabled`) VALUES 
('1', '700', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_TITLE', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_BODY', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_ACTION', 'plg_twofactorauth_totp', '1', 'action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_condition', '3.2.0', '1'),
('2', '700', 'COM_CPANEL_WELCOME_BEGINNERS_TITLE', 'COM_CPANEL_WELCOME_BEGINNERS_MESSAGE', '', 'com_cpanel', '1', 'message', '', '', '', '', '3.2.0', '1'),
('3', '700', 'COM_CPANEL_MSG_STATS_COLLECTION_TITLE', 'COM_CPANEL_MSG_STATS_COLLECTION_BODY', '', 'com_cpanel', '1', 'message', '', '', 'admin://components/com_admin/postinstall/statscollection.php', 'admin_postinstall_statscollection_condition', '3.5.0', '1'),
('4', '700', 'PLG_SYSTEM_UPDATENOTIFICATION_POSTINSTALL_UPDATECACHETIME', 'PLG_SYSTEM_UPDATENOTIFICATION_POSTINSTALL_UPDATECACHETIME_BODY', 'PLG_SYSTEM_UPDATENOTIFICATION_POSTINSTALL_UPDATECACHETIME_ACTION', 'plg_system_updatenotification', '1', 'action', 'site://plugins/system/updatenotification/postinstall/updatecachetime.php', 'updatecachetime_postinstall_action', 'site://plugins/system/updatenotification/postinstall/updatecachetime.php', 'updatecachetime_postinstall_condition', '3.6.3', '1');

DROP TABLE IF EXISTS `lal5d_redirect_links`;
CREATE TABLE `lal5d_redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_url` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `header` smallint(3) NOT NULL DEFAULT '301',
  PRIMARY KEY (`id`),
  KEY `idx_old_url` (`old_url`(100)),
  KEY `idx_link_modifed` (`modified_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_schemas`;
CREATE TABLE `lal5d_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_schemas
(`extension_id`, `version_id`) VALUES 
('700', '3.6.3-2016-08-16'),
('10046', '4.8.7'),
('10054', '1.3.9'),
('10066', '1.1.9'),
('10067', '1.2.3'),
('10068', '1.0.1'),
('10069', '1.0.0'),
('10070', '1.0.6'),
('10071', '2.1.0'),
('10079', '4.0.3'),
('10084', '1.2.1'),
('10087', '1.0.0');

DROP TABLE IF EXISTS `lal5d_session`;
CREATE TABLE `lal5d_session` (
  `session_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data` mediumtext COLLATE utf8mb4_unicode_ci,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_session
(`session_id`, `client_id`, `guest`, `time`, `data`, `userid`, `username`) VALUES 
('cdkvd3196ihrpscql5622q9d47', '1', '0', '1479138304', 'joomla|s:2564:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjozOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjI6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjo0OntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjM6e3M6NzoiY291bnRlciI7aTo3NjtzOjU6InRva2VuIjtzOjMyOiJlMlZZZVJpMXN3VklwTnNPZkF5SW9GZXAwYUowaDliVyI7czo1OiJ0aW1lciI7Tzo4OiJzdGRDbGFzcyI6Mzp7czo1OiJzdGFydCI7aToxNDc5MTM0MjQ2O3M6NDoibGFzdCI7aToxNDc5MTM4MTU0O3M6Mzoibm93IjtpOjE0NzkxMzgyNTQ7fX1zOjg6InJlZ2lzdHJ5IjtPOjI0OiJKb29tbGFcUmVnaXN0cnlcUmVnaXN0cnkiOjM6e3M6NzoiACoAZGF0YSI7Tzo4OiJzdGRDbGFzcyI6ODp7czo5OiJjb21fbWVudXMiO086ODoic3RkQ2xhc3MiOjE6e3M6NToiaXRlbXMiO086ODoic3RkQ2xhc3MiOjM6e3M6ODoibWVudXR5cGUiO3M6ODoibWFpbm1lbnUiO3M6MTA6ImxpbWl0c3RhcnQiO2k6MDtzOjQ6Imxpc3QiO2E6NDp7czo5OiJkaXJlY3Rpb24iO3M6MzoiYXNjIjtzOjU6ImxpbWl0IjtzOjI6IjIwIjtzOjg6Im9yZGVyaW5nIjtzOjU6ImEubGZ0IjtzOjU6InN0YXJ0IjtkOjA7fX19czoxMToiY29tX2NvbnRlbnQiO086ODoic3RkQ2xhc3MiOjE6e3M6NDoiZWRpdCI7Tzo4OiJzdGRDbGFzcyI6MTp7czo3OiJhcnRpY2xlIjtPOjg6InN0ZENsYXNzIjoxOntzOjQ6ImRhdGEiO047fX19czoxNDoiY29tX2NhdGVnb3JpZXMiO086ODoic3RkQ2xhc3MiOjE6e3M6MTA6ImNhdGVnb3JpZXMiO086ODoic3RkQ2xhc3MiOjE6e3M6NzoiY29udGVudCI7Tzo4OiJzdGRDbGFzcyI6Mjp7czo2OiJmaWx0ZXIiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiZXh0ZW5zaW9uIjtzOjExOiJjb21fY29udGVudCI7fXM6NDoibGlzdCI7YTo0OntzOjk6ImRpcmVjdGlvbiI7czozOiJhc2MiO3M6NToibGltaXQiO3M6MjoiMjAiO3M6ODoib3JkZXJpbmciO3M6NToiYS5sZnQiO3M6NToic3RhcnQiO2Q6MDt9fX19czoxMToiY29tX21vZHVsZXMiO086ODoic3RkQ2xhc3MiOjI6e3M6NDoiZWRpdCI7Tzo4OiJzdGRDbGFzcyI6MTp7czo2OiJtb2R1bGUiO086ODoic3RkQ2xhc3MiOjE6e3M6NDoiZGF0YSI7Tjt9fXM6MzoiYWRkIjtPOjg6InN0ZENsYXNzIjoxOntzOjY6Im1vZHVsZSI7Tzo4OiJzdGRDbGFzcyI6Mjp7czoxMjoiZXh0ZW5zaW9uX2lkIjtOO3M6NjoicGFyYW1zIjtOO319fXM6MTM6ImNvbV90ZW1wbGF0ZXMiO086ODoic3RkQ2xhc3MiOjE6e3M6NDoiZWRpdCI7Tzo4OiJzdGRDbGFzcyI6MTp7czo1OiJzdHlsZSI7Tzo4OiJzdGRDbGFzcyI6Mjp7czoyOiJpZCI7YToxOntpOjA7aToxMjt9czo0OiJkYXRhIjtOO319fXM6MzoianNuIjtPOjg6InN0ZENsYXNzIjoxOntzOjg6InRlbXBsYXRlIjtPOjg6InN0ZENsYXNzIjoyOntzOjE4OiJtYXhDb21wcmVzc2lvblNpemUiO2k6MTAwO3M6MTQ6ImNhY2hlRGlyZWN0b3J5IjtzOjY6ImNhY2hlLyI7fX1zOjY6ImpzbnRwbCI7Tzo4OiJzdGRDbGFzcyI6MTp7czo5OiJpbnN0YWxsZXIiO086ODoic3RkQ2xhc3MiOjE6e3M6ODoiY3VzdG9tZXIiO086ODoic3RkQ2xhc3MiOjE6e3M6ODoidXNlcm5hbWUiO3M6MDoiIjt9fX1zOjIxOiJqc24tdHBsZnctYmFja3VwLWRvbmUiO2k6MDt9czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MTtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9czo0OiJ1c2VyIjtPOjU6IkpVc2VyIjoxOntzOjI6ImlkIjtzOjM6IjYwMiI7fXM6MTE6ImFwcGxpY2F0aW9uIjtPOjg6InN0ZENsYXNzIjoxOntzOjU6InF1ZXVlIjtOO319czoxNDoiX19qc25pbWFnZXNob3ciO086ODoic3RkQ2xhc3MiOjE6e3M6MTA6InByZXZlcnNpb24iO3M6NToiNC45LjMiO319czoxNDoiACoAaW5pdGlhbGl6ZWQiO2I6MDtzOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";', '602', 'thushara.sandakelum');

DROP TABLE IF EXISTS `lal5d_tags`;
CREATE TABLE `lal5d_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `urls` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tag_idx` (`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`(100)),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`(100)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_tags
(`id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `created_by_alias`, `modified_user_id`, `modified_time`, `images`, `urls`, `hits`, `language`, `version`, `publish_up`, `publish_down`) VALUES 
('1', '0', '0', '1', '0', '', 'ROOT', 'root', '', '', '1', '0', '0000-00-00 00:00:00', '1', '', '', '', '', '602', '2011-01-01 00:00:01', '', '0', '0000-00-00 00:00:00', '', '', '0', '*', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

DROP TABLE IF EXISTS `lal5d_template_styles`;
CREATE TABLE `lal5d_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_template_styles
(`id`, `template`, `client_id`, `home`, `title`, `params`) VALUES 
('4', 'beez3', '0', '0', 'Beez3 - Default', '{\"wrapperSmall\":\"53\",\"wrapperLarge\":\"72\",\"logo\":\"images\\/joomla_black.png\",\"sitetitle\":\"Joomla!\",\"sitedescription\":\"Open Source Content Management\",\"navposition\":\"left\",\"templatecolor\":\"personal\",\"html5\":\"0\"}'),
('5', 'hathor', '1', '0', 'Hathor - Default', '{\"showSiteName\":\"0\",\"colourChoice\":\"\",\"boldText\":\"0\"}'),
('7', 'protostar', '0', '0', 'protostar - Default', '{\"templateColor\":\"\",\"logoFile\":\"\",\"googleFont\":\"1\",\"googleFontName\":\"Open+Sans\",\"fluidContainer\":\"0\"}'),
('8', 'isis', '1', '1', 'isis - Default', '{\"templateColor\":\"\",\"logoFile\":\"\"}'),
('9', 'bestshop', '0', '1', 'BestShop - Default', '{\"sticky_header\":\"1\",\"boxed_layout\":\"0\",\"page_loader\":\"1\",\"logo_type\":\"image\",\"logo_position\":\"logo\",\"body_bg_repeat\":\"inherit\",\"body_bg_size\":\"inherit\",\"body_bg_attachment\":\"inherit\",\"body_bg_position\":\"0 0\",\"enabled_copyright\":\"1\",\"copyright_position\":\"footer1\",\"copyright\":\"\\u00a9 2015 Your Company. All Rights Reserved. Designed By JoomShaper\",\"show_social_icons\":\"1\",\"social_position\":\"top1\",\"enable_contactinfo\":\"1\",\"contact_position\":\"top2\",\"contact_phone\":\"+228 872 4444\",\"contact_time\":\"Mon - Sat: 09.00 - 19.00\",\"contact_email\":\"contact@email.com\",\"comingsoon_mode\":\"0\",\"comingsoon_title\":\"Coming Soon Title\",\"comingsoon_date\":\"5-10-2018\",\"comingsoon_content\":\"Coming soon content\",\"preset\":\"preset1\",\"preset1_bg\":\"#ffffff\",\"preset1_text\":\"#000000\",\"preset1_major\":\"#26aae1\",\"preset2_bg\":\"#ffffff\",\"preset2_text\":\"#000000\",\"preset2_major\":\"#3d449a\",\"preset3_bg\":\"#ffffff\",\"preset3_text\":\"#000000\",\"preset3_major\":\"#2bb673\",\"preset4_bg\":\"#ffffff\",\"preset4_text\":\"#000000\",\"preset4_major\":\"#eb4947\",\"menu\":\"mainmenu\",\"menu_type\":\"mega_offcanvas\",\"menu_animation\":\"menu-fade\",\"enable_body_font\":\"1\",\"body_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"300\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h1_font\":\"1\",\"h1_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"800\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h2_font\":\"1\",\"h2_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"600\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h3_font\":\"1\",\"h3_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"regular\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h4_font\":\"1\",\"h4_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"regular\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h5_font\":\"1\",\"h5_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"600\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_h6_font\":\"1\",\"h6_font\":\"{\\\"fontFamily\\\":\\\"Open Sans\\\",\\\"fontWeight\\\":\\\"600\\\",\\\"fontSubset\\\":\\\"latin\\\",\\\"fontSize\\\":\\\"\\\"}\",\"enable_navigation_font\":\"0\",\"enable_custom_font\":\"0\",\"compress_css\":\"0\",\"compress_js\":\"0\",\"lessoption\":\"0\",\"show_post_format\":\"1\",\"commenting_engine\":\"disabled\",\"disqus_devmode\":\"0\",\"intensedebate_acc\":\"\",\"fb_width\":\"500\",\"fb_cpp\":\"10\",\"comments_count\":\"0\",\"social_share\":\"1\",\"image_small\":\"0\",\"image_small_size\":\"100X100\",\"image_thumbnail\":\"1\",\"image_thumbnail_size\":\"200X200\",\"image_medium\":\"0\",\"image_medium_size\":\"300X300\",\"image_large\":\"0\",\"image_large_size\":\"600X600\",\"blog_list_image\":\"default\"}'),
('10', 'rt_vehicles', '0', '0', 'RT Vehicles - Default', '{\"logo\":\"templates\\/rt_vehicles\\/images\\/logo.png\"}'),
('11', 'jsn_dome_free', '0', '0', 'JSN Dome FREE - Default', '[]'),
('12', 'jsn_reta_free', '0', '0', 'JSN Reta FREE - Default', '[]'),
('13', 'wt_blank_free', '0', '0', 'wt_blank_free - Default', '{\"config\":\"\"}'),
('14', 'jsn_mobilize', '0', '0', 'JSN Mobilize - Default', '{}');

DROP TABLE IF EXISTS `lal5d_ucm_base`;
CREATE TABLE `lal5d_ucm_base` (
  `ucm_id` int(10) unsigned NOT NULL,
  `ucm_item_id` int(10) NOT NULL,
  `ucm_type_id` int(11) NOT NULL,
  `ucm_language_id` int(11) NOT NULL,
  PRIMARY KEY (`ucm_id`),
  KEY `idx_ucm_item_id` (`ucm_item_id`),
  KEY `idx_ucm_type_id` (`ucm_type_id`),
  KEY `idx_ucm_language_id` (`ucm_language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_ucm_content`;
CREATE TABLE `lal5d_ucm_content` (
  `core_content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `core_type_alias` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `core_body` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_checked_out_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_access` int(10) unsigned NOT NULL DEFAULT '0',
  `core_params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_publish_up` datetime NOT NULL,
  `core_publish_down` datetime NOT NULL,
  `core_content_item_id` int(10) unsigned DEFAULT NULL COMMENT 'ID from the individual type table',
  `asset_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `core_images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_urls` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `core_version` int(10) unsigned NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_metadesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_catid` int(10) unsigned NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`core_content_id`),
  KEY `tag_idx` (`core_state`,`core_access`),
  KEY `idx_access` (`core_access`),
  KEY `idx_alias` (`core_alias`(100)),
  KEY `idx_language` (`core_language`),
  KEY `idx_title` (`core_title`(100)),
  KEY `idx_modified_time` (`core_modified_time`),
  KEY `idx_created_time` (`core_created_time`),
  KEY `idx_content_type` (`core_type_alias`(100)),
  KEY `idx_core_modified_user_id` (`core_modified_user_id`),
  KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`),
  KEY `idx_core_created_user_id` (`core_created_user_id`),
  KEY `idx_core_type_id` (`core_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Contains core content data in name spaced fields';

DROP TABLE IF EXISTS `lal5d_ucm_history`;
CREATE TABLE `lal5d_ucm_history` (
  `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ucm_item_id` int(10) unsigned NOT NULL,
  `ucm_type_id` int(10) unsigned NOT NULL,
  `version_note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Optional version name',
  `save_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `character_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of characters in this version.',
  `sha1_hash` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'SHA1 hash of the version_data column.',
  `version_data` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'json-encoded string of version data',
  `keep_forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=auto delete; 1=keep',
  PRIMARY KEY (`version_id`),
  KEY `idx_ucm_item_id` (`ucm_type_id`,`ucm_item_id`),
  KEY `idx_save_date` (`save_date`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_ucm_history
(`version_id`, `ucm_item_id`, `ucm_type_id`, `version_note`, `save_date`, `editor_user_id`, `character_count`, `sha1_hash`, `version_data`, `keep_forever`) VALUES 
('1', '1', '1', '', '2016-11-12 06:22:40', '602', '1882', '7c8179790fcd7eccbc3a5399f96d2ead23bae825', '{\"id\":1,\"asset_id\":65,\"title\":\"Menu\",\"alias\":\"menu\",\"introtext\":\"\",\"fulltext\":\"\",\"state\":1,\"catid\":\"2\",\"created\":\"2016-11-12 06:22:40\",\"created_by\":\"602\",\"created_by_alias\":\"\",\"modified\":\"2016-11-12 06:22:40\",\"modified_by\":null,\"checked_out\":null,\"checked_out_time\":null,\"publish_up\":\"2016-11-12 06:22:40\",\"publish_down\":\"0000-00-00 00:00:00\",\"images\":\"{\\\"image_intro\\\":\\\"\\\",\\\"float_intro\\\":\\\"\\\",\\\"image_intro_alt\\\":\\\"\\\",\\\"image_intro_caption\\\":\\\"\\\",\\\"image_fulltext\\\":\\\"\\\",\\\"float_fulltext\\\":\\\"\\\",\\\"image_fulltext_alt\\\":\\\"\\\",\\\"image_fulltext_caption\\\":\\\"\\\"}\",\"urls\":\"{\\\"urla\\\":false,\\\"urlatext\\\":\\\"\\\",\\\"targeta\\\":\\\"\\\",\\\"urlb\\\":false,\\\"urlbtext\\\":\\\"\\\",\\\"targetb\\\":\\\"\\\",\\\"urlc\\\":false,\\\"urlctext\\\":\\\"\\\",\\\"targetc\\\":\\\"\\\"}\",\"attribs\":\"{\\\"show_title\\\":\\\"\\\",\\\"link_titles\\\":\\\"\\\",\\\"show_tags\\\":\\\"\\\",\\\"show_intro\\\":\\\"\\\",\\\"info_block_position\\\":\\\"\\\",\\\"info_block_show_title\\\":\\\"\\\",\\\"show_category\\\":\\\"\\\",\\\"link_category\\\":\\\"\\\",\\\"show_parent_category\\\":\\\"\\\",\\\"link_parent_category\\\":\\\"\\\",\\\"show_author\\\":\\\"\\\",\\\"link_author\\\":\\\"\\\",\\\"show_create_date\\\":\\\"\\\",\\\"show_modify_date\\\":\\\"\\\",\\\"show_publish_date\\\":\\\"\\\",\\\"show_item_navigation\\\":\\\"\\\",\\\"show_icons\\\":\\\"\\\",\\\"show_print_icon\\\":\\\"\\\",\\\"show_email_icon\\\":\\\"\\\",\\\"show_vote\\\":\\\"\\\",\\\"show_hits\\\":\\\"\\\",\\\"show_noauth\\\":\\\"\\\",\\\"urls_position\\\":\\\"\\\",\\\"alternative_readmore\\\":\\\"\\\",\\\"article_layout\\\":\\\"\\\",\\\"show_publishing_options\\\":\\\"\\\",\\\"show_article_options\\\":\\\"\\\",\\\"show_urls_images_backend\\\":\\\"\\\",\\\"show_urls_images_frontend\\\":\\\"\\\",\\\"spfeatured_image\\\":\\\"\\\",\\\"post_format\\\":\\\"standard\\\",\\\"gallery\\\":\\\"\\\",\\\"audio\\\":\\\"\\\",\\\"video\\\":\\\"\\\",\\\"link_title\\\":\\\"\\\",\\\"link_url\\\":\\\"\\\",\\\"quote_text\\\":\\\"\\\",\\\"quote_author\\\":\\\"\\\",\\\"post_status\\\":\\\"\\\"}\",\"version\":1,\"ordering\":null,\"metakey\":\"\",\"metadesc\":\"\",\"access\":\"1\",\"hits\":null,\"metadata\":\"{\\\"robots\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"rights\\\":\\\"\\\",\\\"xreference\\\":\\\"\\\"}\",\"featured\":\"0\",\"language\":\"*\",\"xreference\":\"\"}', '0'),
('2', '2', '1', '', '2016-11-12 06:23:48', '602', '1904', '7371866fa58e9087691bdecd56991dc001749318', '{\"id\":2,\"asset_id\":66,\"title\":\"Color Variation\",\"alias\":\"color-variation\",\"introtext\":\"\",\"fulltext\":\"\",\"state\":1,\"catid\":\"2\",\"created\":\"2016-11-12 06:23:48\",\"created_by\":\"602\",\"created_by_alias\":\"\",\"modified\":\"2016-11-12 06:23:48\",\"modified_by\":null,\"checked_out\":null,\"checked_out_time\":null,\"publish_up\":\"2016-11-12 06:23:48\",\"publish_down\":\"0000-00-00 00:00:00\",\"images\":\"{\\\"image_intro\\\":\\\"\\\",\\\"float_intro\\\":\\\"\\\",\\\"image_intro_alt\\\":\\\"\\\",\\\"image_intro_caption\\\":\\\"\\\",\\\"image_fulltext\\\":\\\"\\\",\\\"float_fulltext\\\":\\\"\\\",\\\"image_fulltext_alt\\\":\\\"\\\",\\\"image_fulltext_caption\\\":\\\"\\\"}\",\"urls\":\"{\\\"urla\\\":false,\\\"urlatext\\\":\\\"\\\",\\\"targeta\\\":\\\"\\\",\\\"urlb\\\":false,\\\"urlbtext\\\":\\\"\\\",\\\"targetb\\\":\\\"\\\",\\\"urlc\\\":false,\\\"urlctext\\\":\\\"\\\",\\\"targetc\\\":\\\"\\\"}\",\"attribs\":\"{\\\"show_title\\\":\\\"\\\",\\\"link_titles\\\":\\\"\\\",\\\"show_tags\\\":\\\"\\\",\\\"show_intro\\\":\\\"\\\",\\\"info_block_position\\\":\\\"\\\",\\\"info_block_show_title\\\":\\\"\\\",\\\"show_category\\\":\\\"\\\",\\\"link_category\\\":\\\"\\\",\\\"show_parent_category\\\":\\\"\\\",\\\"link_parent_category\\\":\\\"\\\",\\\"show_author\\\":\\\"\\\",\\\"link_author\\\":\\\"\\\",\\\"show_create_date\\\":\\\"\\\",\\\"show_modify_date\\\":\\\"\\\",\\\"show_publish_date\\\":\\\"\\\",\\\"show_item_navigation\\\":\\\"\\\",\\\"show_icons\\\":\\\"\\\",\\\"show_print_icon\\\":\\\"\\\",\\\"show_email_icon\\\":\\\"\\\",\\\"show_vote\\\":\\\"\\\",\\\"show_hits\\\":\\\"\\\",\\\"show_noauth\\\":\\\"\\\",\\\"urls_position\\\":\\\"\\\",\\\"alternative_readmore\\\":\\\"\\\",\\\"article_layout\\\":\\\"\\\",\\\"show_publishing_options\\\":\\\"\\\",\\\"show_article_options\\\":\\\"\\\",\\\"show_urls_images_backend\\\":\\\"\\\",\\\"show_urls_images_frontend\\\":\\\"\\\",\\\"spfeatured_image\\\":\\\"\\\",\\\"post_format\\\":\\\"standard\\\",\\\"gallery\\\":\\\"\\\",\\\"audio\\\":\\\"\\\",\\\"video\\\":\\\"\\\",\\\"link_title\\\":\\\"\\\",\\\"link_url\\\":\\\"\\\",\\\"quote_text\\\":\\\"\\\",\\\"quote_author\\\":\\\"\\\",\\\"post_status\\\":\\\"\\\"}\",\"version\":1,\"ordering\":null,\"metakey\":\"\",\"metadesc\":\"\",\"access\":\"1\",\"hits\":null,\"metadata\":\"{\\\"robots\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"rights\\\":\\\"\\\",\\\"xreference\\\":\\\"\\\"}\",\"featured\":\"0\",\"language\":\"*\",\"xreference\":\"\"}', '0'),
('3', '3', '1', '', '2016-11-12 06:24:19', '602', '1888', '91274d2c94e90ff2e9a1ebb1ecd3edd8400a53d3', '{\"id\":3,\"asset_id\":67,\"title\":\"Service\",\"alias\":\"service\",\"introtext\":\"\",\"fulltext\":\"\",\"state\":1,\"catid\":\"2\",\"created\":\"2016-11-12 06:24:19\",\"created_by\":\"602\",\"created_by_alias\":\"\",\"modified\":\"2016-11-12 06:24:19\",\"modified_by\":null,\"checked_out\":null,\"checked_out_time\":null,\"publish_up\":\"2016-11-12 06:24:19\",\"publish_down\":\"0000-00-00 00:00:00\",\"images\":\"{\\\"image_intro\\\":\\\"\\\",\\\"float_intro\\\":\\\"\\\",\\\"image_intro_alt\\\":\\\"\\\",\\\"image_intro_caption\\\":\\\"\\\",\\\"image_fulltext\\\":\\\"\\\",\\\"float_fulltext\\\":\\\"\\\",\\\"image_fulltext_alt\\\":\\\"\\\",\\\"image_fulltext_caption\\\":\\\"\\\"}\",\"urls\":\"{\\\"urla\\\":false,\\\"urlatext\\\":\\\"\\\",\\\"targeta\\\":\\\"\\\",\\\"urlb\\\":false,\\\"urlbtext\\\":\\\"\\\",\\\"targetb\\\":\\\"\\\",\\\"urlc\\\":false,\\\"urlctext\\\":\\\"\\\",\\\"targetc\\\":\\\"\\\"}\",\"attribs\":\"{\\\"show_title\\\":\\\"\\\",\\\"link_titles\\\":\\\"\\\",\\\"show_tags\\\":\\\"\\\",\\\"show_intro\\\":\\\"\\\",\\\"info_block_position\\\":\\\"\\\",\\\"info_block_show_title\\\":\\\"\\\",\\\"show_category\\\":\\\"\\\",\\\"link_category\\\":\\\"\\\",\\\"show_parent_category\\\":\\\"\\\",\\\"link_parent_category\\\":\\\"\\\",\\\"show_author\\\":\\\"\\\",\\\"link_author\\\":\\\"\\\",\\\"show_create_date\\\":\\\"\\\",\\\"show_modify_date\\\":\\\"\\\",\\\"show_publish_date\\\":\\\"\\\",\\\"show_item_navigation\\\":\\\"\\\",\\\"show_icons\\\":\\\"\\\",\\\"show_print_icon\\\":\\\"\\\",\\\"show_email_icon\\\":\\\"\\\",\\\"show_vote\\\":\\\"\\\",\\\"show_hits\\\":\\\"\\\",\\\"show_noauth\\\":\\\"\\\",\\\"urls_position\\\":\\\"\\\",\\\"alternative_readmore\\\":\\\"\\\",\\\"article_layout\\\":\\\"\\\",\\\"show_publishing_options\\\":\\\"\\\",\\\"show_article_options\\\":\\\"\\\",\\\"show_urls_images_backend\\\":\\\"\\\",\\\"show_urls_images_frontend\\\":\\\"\\\",\\\"spfeatured_image\\\":\\\"\\\",\\\"post_format\\\":\\\"standard\\\",\\\"gallery\\\":\\\"\\\",\\\"audio\\\":\\\"\\\",\\\"video\\\":\\\"\\\",\\\"link_title\\\":\\\"\\\",\\\"link_url\\\":\\\"\\\",\\\"quote_text\\\":\\\"\\\",\\\"quote_author\\\":\\\"\\\",\\\"post_status\\\":\\\"\\\"}\",\"version\":1,\"ordering\":null,\"metakey\":\"\",\"metadesc\":\"\",\"access\":\"1\",\"hits\":null,\"metadata\":\"{\\\"robots\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"rights\\\":\\\"\\\",\\\"xreference\\\":\\\"\\\"}\",\"featured\":\"0\",\"language\":\"*\",\"xreference\":\"\"}', '0'),
('4', '4', '1', '', '2016-11-12 06:24:42', '602', '1888', 'c22cb7b47dccfa1dcb593a28e99789045e0cee88', '{\"id\":4,\"asset_id\":68,\"title\":\"Contact\",\"alias\":\"contact\",\"introtext\":\"\",\"fulltext\":\"\",\"state\":1,\"catid\":\"2\",\"created\":\"2016-11-12 06:24:42\",\"created_by\":\"602\",\"created_by_alias\":\"\",\"modified\":\"2016-11-12 06:24:42\",\"modified_by\":null,\"checked_out\":null,\"checked_out_time\":null,\"publish_up\":\"2016-11-12 06:24:42\",\"publish_down\":\"0000-00-00 00:00:00\",\"images\":\"{\\\"image_intro\\\":\\\"\\\",\\\"float_intro\\\":\\\"\\\",\\\"image_intro_alt\\\":\\\"\\\",\\\"image_intro_caption\\\":\\\"\\\",\\\"image_fulltext\\\":\\\"\\\",\\\"float_fulltext\\\":\\\"\\\",\\\"image_fulltext_alt\\\":\\\"\\\",\\\"image_fulltext_caption\\\":\\\"\\\"}\",\"urls\":\"{\\\"urla\\\":false,\\\"urlatext\\\":\\\"\\\",\\\"targeta\\\":\\\"\\\",\\\"urlb\\\":false,\\\"urlbtext\\\":\\\"\\\",\\\"targetb\\\":\\\"\\\",\\\"urlc\\\":false,\\\"urlctext\\\":\\\"\\\",\\\"targetc\\\":\\\"\\\"}\",\"attribs\":\"{\\\"show_title\\\":\\\"\\\",\\\"link_titles\\\":\\\"\\\",\\\"show_tags\\\":\\\"\\\",\\\"show_intro\\\":\\\"\\\",\\\"info_block_position\\\":\\\"\\\",\\\"info_block_show_title\\\":\\\"\\\",\\\"show_category\\\":\\\"\\\",\\\"link_category\\\":\\\"\\\",\\\"show_parent_category\\\":\\\"\\\",\\\"link_parent_category\\\":\\\"\\\",\\\"show_author\\\":\\\"\\\",\\\"link_author\\\":\\\"\\\",\\\"show_create_date\\\":\\\"\\\",\\\"show_modify_date\\\":\\\"\\\",\\\"show_publish_date\\\":\\\"\\\",\\\"show_item_navigation\\\":\\\"\\\",\\\"show_icons\\\":\\\"\\\",\\\"show_print_icon\\\":\\\"\\\",\\\"show_email_icon\\\":\\\"\\\",\\\"show_vote\\\":\\\"\\\",\\\"show_hits\\\":\\\"\\\",\\\"show_noauth\\\":\\\"\\\",\\\"urls_position\\\":\\\"\\\",\\\"alternative_readmore\\\":\\\"\\\",\\\"article_layout\\\":\\\"\\\",\\\"show_publishing_options\\\":\\\"\\\",\\\"show_article_options\\\":\\\"\\\",\\\"show_urls_images_backend\\\":\\\"\\\",\\\"show_urls_images_frontend\\\":\\\"\\\",\\\"spfeatured_image\\\":\\\"\\\",\\\"post_format\\\":\\\"standard\\\",\\\"gallery\\\":\\\"\\\",\\\"audio\\\":\\\"\\\",\\\"video\\\":\\\"\\\",\\\"link_title\\\":\\\"\\\",\\\"link_url\\\":\\\"\\\",\\\"quote_text\\\":\\\"\\\",\\\"quote_author\\\":\\\"\\\",\\\"post_status\\\":\\\"\\\"}\",\"version\":1,\"ordering\":null,\"metakey\":\"\",\"metadesc\":\"\",\"access\":\"1\",\"hits\":null,\"metadata\":\"{\\\"robots\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"rights\\\":\\\"\\\",\\\"xreference\\\":\\\"\\\"}\",\"featured\":\"0\",\"language\":\"*\",\"xreference\":\"\"}', '0'),
('5', '8', '5', '', '2016-11-12 06:44:12', '602', '567', 'aad20574d24ea5f36eb17b45aa55ac47e0261d91', '{\"id\":8,\"asset_id\":70,\"parent_id\":\"1\",\"lft\":\"11\",\"rgt\":12,\"level\":1,\"path\":null,\"extension\":\"com_content\",\"title\":\"Color Variation\",\"alias\":\"color-variation\",\"note\":\"\",\"description\":\"\",\"published\":\"1\",\"checked_out\":null,\"checked_out_time\":null,\"access\":\"1\",\"params\":\"{\\\"category_layout\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_alt\\\":\\\"\\\"}\",\"metadesc\":\"\",\"metakey\":\"\",\"metadata\":\"{\\\"author\\\":\\\"\\\",\\\"robots\\\":\\\"\\\"}\",\"created_user_id\":\"602\",\"created_time\":\"2016-11-12 06:44:12\",\"modified_user_id\":null,\"modified_time\":\"2016-11-12 06:44:12\",\"hits\":\"0\",\"language\":\"*\",\"version\":null}', '0'),
('6', '5', '1', '', '2016-11-12 06:46:21', '602', '1904', 'f9b8ecac09d3aea7f8765958c57612afb650b6f4', '{\"id\":5,\"asset_id\":71,\"title\":\"Color Variation\",\"alias\":\"color-variation\",\"introtext\":\"\",\"fulltext\":\"\",\"state\":1,\"catid\":\"8\",\"created\":\"2016-11-12 06:46:21\",\"created_by\":\"602\",\"created_by_alias\":\"\",\"modified\":\"2016-11-12 06:46:21\",\"modified_by\":null,\"checked_out\":null,\"checked_out_time\":null,\"publish_up\":\"2016-11-12 06:46:21\",\"publish_down\":\"0000-00-00 00:00:00\",\"images\":\"{\\\"image_intro\\\":\\\"\\\",\\\"float_intro\\\":\\\"\\\",\\\"image_intro_alt\\\":\\\"\\\",\\\"image_intro_caption\\\":\\\"\\\",\\\"image_fulltext\\\":\\\"\\\",\\\"float_fulltext\\\":\\\"\\\",\\\"image_fulltext_alt\\\":\\\"\\\",\\\"image_fulltext_caption\\\":\\\"\\\"}\",\"urls\":\"{\\\"urla\\\":false,\\\"urlatext\\\":\\\"\\\",\\\"targeta\\\":\\\"\\\",\\\"urlb\\\":false,\\\"urlbtext\\\":\\\"\\\",\\\"targetb\\\":\\\"\\\",\\\"urlc\\\":false,\\\"urlctext\\\":\\\"\\\",\\\"targetc\\\":\\\"\\\"}\",\"attribs\":\"{\\\"show_title\\\":\\\"\\\",\\\"link_titles\\\":\\\"\\\",\\\"show_tags\\\":\\\"\\\",\\\"show_intro\\\":\\\"\\\",\\\"info_block_position\\\":\\\"\\\",\\\"info_block_show_title\\\":\\\"\\\",\\\"show_category\\\":\\\"\\\",\\\"link_category\\\":\\\"\\\",\\\"show_parent_category\\\":\\\"\\\",\\\"link_parent_category\\\":\\\"\\\",\\\"show_author\\\":\\\"\\\",\\\"link_author\\\":\\\"\\\",\\\"show_create_date\\\":\\\"\\\",\\\"show_modify_date\\\":\\\"\\\",\\\"show_publish_date\\\":\\\"\\\",\\\"show_item_navigation\\\":\\\"\\\",\\\"show_icons\\\":\\\"\\\",\\\"show_print_icon\\\":\\\"\\\",\\\"show_email_icon\\\":\\\"\\\",\\\"show_vote\\\":\\\"\\\",\\\"show_hits\\\":\\\"\\\",\\\"show_noauth\\\":\\\"\\\",\\\"urls_position\\\":\\\"\\\",\\\"alternative_readmore\\\":\\\"\\\",\\\"article_layout\\\":\\\"\\\",\\\"show_publishing_options\\\":\\\"\\\",\\\"show_article_options\\\":\\\"\\\",\\\"show_urls_images_backend\\\":\\\"\\\",\\\"show_urls_images_frontend\\\":\\\"\\\",\\\"spfeatured_image\\\":\\\"\\\",\\\"post_format\\\":\\\"standard\\\",\\\"gallery\\\":\\\"\\\",\\\"audio\\\":\\\"\\\",\\\"video\\\":\\\"\\\",\\\"link_title\\\":\\\"\\\",\\\"link_url\\\":\\\"\\\",\\\"quote_text\\\":\\\"\\\",\\\"quote_author\\\":\\\"\\\",\\\"post_status\\\":\\\"\\\"}\",\"version\":1,\"ordering\":null,\"metakey\":\"\",\"metadesc\":\"\",\"access\":\"1\",\"hits\":null,\"metadata\":\"{\\\"robots\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"rights\\\":\\\"\\\",\\\"xreference\\\":\\\"\\\"}\",\"featured\":\"0\",\"language\":\"*\",\"xreference\":\"\"}', '0'),
('7', '9', '7', '', '2016-11-12 06:48:19', '602', '575', 'c6619d73000ed7cddeddaec97a69c1049c99e774', '{\"id\":9,\"asset_id\":72,\"parent_id\":\"1\",\"lft\":\"13\",\"rgt\":14,\"level\":1,\"path\":null,\"extension\":\"com_newsfeeds\",\"title\":\"Black Silver Color\",\"alias\":\"black-silver-color\",\"note\":\"\",\"description\":\"\",\"published\":\"1\",\"checked_out\":null,\"checked_out_time\":null,\"access\":\"1\",\"params\":\"{\\\"category_layout\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_alt\\\":\\\"\\\"}\",\"metadesc\":\"\",\"metakey\":\"\",\"metadata\":\"{\\\"author\\\":\\\"\\\",\\\"robots\\\":\\\"\\\"}\",\"created_user_id\":\"602\",\"created_time\":\"2016-11-12 06:48:19\",\"modified_user_id\":null,\"modified_time\":\"2016-11-12 06:48:19\",\"hits\":\"0\",\"language\":\"*\",\"version\":null}', '0'),
('8', '10', '7', '', '2016-11-12 06:48:46', '602', '576', '1e2e8b4eb9dd13c71ca7b60879fb68165b0e9922', '{\"id\":10,\"asset_id\":73,\"parent_id\":\"1\",\"lft\":\"15\",\"rgt\":16,\"level\":1,\"path\":null,\"extension\":\"com_newsfeeds\",\"title\":\"Silver Black Color\",\"alias\":\"silver-black-color\",\"note\":\"\",\"description\":\"\",\"published\":\"1\",\"checked_out\":null,\"checked_out_time\":null,\"access\":\"1\",\"params\":\"{\\\"category_layout\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_alt\\\":\\\"\\\"}\",\"metadesc\":\"\",\"metakey\":\"\",\"metadata\":\"{\\\"author\\\":\\\"\\\",\\\"robots\\\":\\\"\\\"}\",\"created_user_id\":\"602\",\"created_time\":\"2016-11-12 06:48:46\",\"modified_user_id\":null,\"modified_time\":\"2016-11-12 06:48:46\",\"hits\":\"0\",\"language\":\"*\",\"version\":null}', '0'),
('9', '11', '7', '', '2016-11-12 06:56:22', '602', '570', '7ec9f6d88a75b666f6859b67331962fff1870349', '{\"id\":11,\"asset_id\":74,\"parent_id\":\"1\",\"lft\":\"17\",\"rgt\":18,\"level\":1,\"path\":null,\"extension\":\"com_newsfeeds\",\"title\":\"Black Red Color\",\"alias\":\"black-red-color\",\"note\":\"\",\"description\":\"\",\"published\":\"1\",\"checked_out\":null,\"checked_out_time\":null,\"access\":\"1\",\"params\":\"{\\\"category_layout\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_alt\\\":\\\"\\\"}\",\"metadesc\":\"\",\"metakey\":\"\",\"metadata\":\"{\\\"author\\\":\\\"\\\",\\\"robots\\\":\\\"\\\"}\",\"created_user_id\":\"602\",\"created_time\":\"2016-11-12 06:56:22\",\"modified_user_id\":null,\"modified_time\":\"2016-11-12 06:56:22\",\"hits\":\"0\",\"language\":\"*\",\"version\":null}', '0'),
('10', '12', '7', '', '2016-11-12 06:57:01', '602', '570', '480a98402e1233ee37adde7db7062276d4fa8c38', '{\"id\":12,\"asset_id\":75,\"parent_id\":\"1\",\"lft\":\"19\",\"rgt\":20,\"level\":1,\"path\":null,\"extension\":\"com_newsfeeds\",\"title\":\"Red Black Color\",\"alias\":\"red-black-color\",\"note\":\"\",\"description\":\"\",\"published\":\"1\",\"checked_out\":null,\"checked_out_time\":null,\"access\":\"1\",\"params\":\"{\\\"category_layout\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_alt\\\":\\\"\\\"}\",\"metadesc\":\"\",\"metakey\":\"\",\"metadata\":\"{\\\"author\\\":\\\"\\\",\\\"robots\\\":\\\"\\\"}\",\"created_user_id\":\"602\",\"created_time\":\"2016-11-12 06:57:01\",\"modified_user_id\":null,\"modified_time\":\"2016-11-12 06:57:01\",\"hits\":\"0\",\"language\":\"*\",\"version\":null}', '0'),
('11', '13', '7', '', '2016-11-12 06:58:22', '602', '572', 'f8cbe70a1d132ee26b8702db6c728fadacb102ea', '{\"id\":13,\"asset_id\":76,\"parent_id\":\"1\",\"lft\":\"21\",\"rgt\":22,\"level\":1,\"path\":null,\"extension\":\"com_newsfeeds\",\"title\":\"Black Blue Color\",\"alias\":\"black-blue-color\",\"note\":\"\",\"description\":\"\",\"published\":\"1\",\"checked_out\":null,\"checked_out_time\":null,\"access\":\"1\",\"params\":\"{\\\"category_layout\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_alt\\\":\\\"\\\"}\",\"metadesc\":\"\",\"metakey\":\"\",\"metadata\":\"{\\\"author\\\":\\\"\\\",\\\"robots\\\":\\\"\\\"}\",\"created_user_id\":\"602\",\"created_time\":\"2016-11-12 06:58:22\",\"modified_user_id\":null,\"modified_time\":\"2016-11-12 06:58:22\",\"hits\":\"0\",\"language\":\"*\",\"version\":null}', '0'),
('12', '14', '7', '', '2016-11-12 06:58:45', '602', '572', '2da28149db9dbf66af769f236984c42f95034c92', '{\"id\":14,\"asset_id\":77,\"parent_id\":\"1\",\"lft\":\"23\",\"rgt\":24,\"level\":1,\"path\":null,\"extension\":\"com_newsfeeds\",\"title\":\"Blue Black Color\",\"alias\":\"blue-black-color\",\"note\":\"\",\"description\":\"\",\"published\":\"1\",\"checked_out\":null,\"checked_out_time\":null,\"access\":\"1\",\"params\":\"{\\\"category_layout\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_alt\\\":\\\"\\\"}\",\"metadesc\":\"\",\"metakey\":\"\",\"metadata\":\"{\\\"author\\\":\\\"\\\",\\\"robots\\\":\\\"\\\"}\",\"created_user_id\":\"602\",\"created_time\":\"2016-11-12 06:58:45\",\"modified_user_id\":null,\"modified_time\":\"2016-11-12 06:58:45\",\"hits\":\"0\",\"language\":\"*\",\"version\":null}', '0'),
('13', '6', '1', '', '2016-11-12 07:04:04', '602', '1906', 'f220e4c7d0ee9d0a2bdd65374a1e1b0cc3357728', '{\"id\":6,\"asset_id\":78,\"title\":\"Color Variation\",\"alias\":\"color-variation-2\",\"introtext\":\"\",\"fulltext\":\"\",\"state\":1,\"catid\":\"2\",\"created\":\"2016-11-12 07:04:04\",\"created_by\":\"602\",\"created_by_alias\":\"\",\"modified\":\"2016-11-12 07:04:04\",\"modified_by\":null,\"checked_out\":null,\"checked_out_time\":null,\"publish_up\":\"2016-11-12 07:04:04\",\"publish_down\":\"0000-00-00 00:00:00\",\"images\":\"{\\\"image_intro\\\":\\\"\\\",\\\"float_intro\\\":\\\"\\\",\\\"image_intro_alt\\\":\\\"\\\",\\\"image_intro_caption\\\":\\\"\\\",\\\"image_fulltext\\\":\\\"\\\",\\\"float_fulltext\\\":\\\"\\\",\\\"image_fulltext_alt\\\":\\\"\\\",\\\"image_fulltext_caption\\\":\\\"\\\"}\",\"urls\":\"{\\\"urla\\\":false,\\\"urlatext\\\":\\\"\\\",\\\"targeta\\\":\\\"\\\",\\\"urlb\\\":false,\\\"urlbtext\\\":\\\"\\\",\\\"targetb\\\":\\\"\\\",\\\"urlc\\\":false,\\\"urlctext\\\":\\\"\\\",\\\"targetc\\\":\\\"\\\"}\",\"attribs\":\"{\\\"show_title\\\":\\\"\\\",\\\"link_titles\\\":\\\"\\\",\\\"show_tags\\\":\\\"\\\",\\\"show_intro\\\":\\\"\\\",\\\"info_block_position\\\":\\\"\\\",\\\"info_block_show_title\\\":\\\"\\\",\\\"show_category\\\":\\\"\\\",\\\"link_category\\\":\\\"\\\",\\\"show_parent_category\\\":\\\"\\\",\\\"link_parent_category\\\":\\\"\\\",\\\"show_author\\\":\\\"\\\",\\\"link_author\\\":\\\"\\\",\\\"show_create_date\\\":\\\"\\\",\\\"show_modify_date\\\":\\\"\\\",\\\"show_publish_date\\\":\\\"\\\",\\\"show_item_navigation\\\":\\\"\\\",\\\"show_icons\\\":\\\"\\\",\\\"show_print_icon\\\":\\\"\\\",\\\"show_email_icon\\\":\\\"\\\",\\\"show_vote\\\":\\\"\\\",\\\"show_hits\\\":\\\"\\\",\\\"show_noauth\\\":\\\"\\\",\\\"urls_position\\\":\\\"\\\",\\\"alternative_readmore\\\":\\\"\\\",\\\"article_layout\\\":\\\"\\\",\\\"show_publishing_options\\\":\\\"\\\",\\\"show_article_options\\\":\\\"\\\",\\\"show_urls_images_backend\\\":\\\"\\\",\\\"show_urls_images_frontend\\\":\\\"\\\",\\\"spfeatured_image\\\":\\\"\\\",\\\"post_format\\\":\\\"standard\\\",\\\"gallery\\\":\\\"\\\",\\\"audio\\\":\\\"\\\",\\\"video\\\":\\\"\\\",\\\"link_title\\\":\\\"\\\",\\\"link_url\\\":\\\"\\\",\\\"quote_text\\\":\\\"\\\",\\\"quote_author\\\":\\\"\\\",\\\"post_status\\\":\\\"\\\"}\",\"version\":1,\"ordering\":null,\"metakey\":\"\",\"metadesc\":\"\",\"access\":\"1\",\"hits\":null,\"metadata\":\"{\\\"robots\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"rights\\\":\\\"\\\",\\\"xreference\\\":\\\"\\\"}\",\"featured\":\"0\",\"language\":\"*\",\"xreference\":\"\"}', '0'),
('14', '6', '1', '', '2016-11-12 07:04:33', '602', '1925', 'dd67f6c0aacbdd8ec909a282bc684b5499870987', '{\"id\":6,\"asset_id\":\"78\",\"title\":\"Color Variation\",\"alias\":\"color-variation-2\",\"introtext\":\"\",\"fulltext\":\"\",\"state\":1,\"catid\":\"8\",\"created\":\"2016-11-12 07:04:04\",\"created_by\":\"602\",\"created_by_alias\":\"\",\"modified\":\"2016-11-12 07:04:33\",\"modified_by\":\"602\",\"checked_out\":\"602\",\"checked_out_time\":\"2016-11-12 07:04:19\",\"publish_up\":\"2016-11-12 07:04:04\",\"publish_down\":\"0000-00-00 00:00:00\",\"images\":\"{\\\"image_intro\\\":\\\"\\\",\\\"float_intro\\\":\\\"\\\",\\\"image_intro_alt\\\":\\\"\\\",\\\"image_intro_caption\\\":\\\"\\\",\\\"image_fulltext\\\":\\\"\\\",\\\"float_fulltext\\\":\\\"\\\",\\\"image_fulltext_alt\\\":\\\"\\\",\\\"image_fulltext_caption\\\":\\\"\\\"}\",\"urls\":\"{\\\"urla\\\":false,\\\"urlatext\\\":\\\"\\\",\\\"targeta\\\":\\\"\\\",\\\"urlb\\\":false,\\\"urlbtext\\\":\\\"\\\",\\\"targetb\\\":\\\"\\\",\\\"urlc\\\":false,\\\"urlctext\\\":\\\"\\\",\\\"targetc\\\":\\\"\\\"}\",\"attribs\":\"{\\\"show_title\\\":\\\"\\\",\\\"link_titles\\\":\\\"\\\",\\\"show_tags\\\":\\\"\\\",\\\"show_intro\\\":\\\"\\\",\\\"info_block_position\\\":\\\"\\\",\\\"info_block_show_title\\\":\\\"\\\",\\\"show_category\\\":\\\"\\\",\\\"link_category\\\":\\\"\\\",\\\"show_parent_category\\\":\\\"\\\",\\\"link_parent_category\\\":\\\"\\\",\\\"show_author\\\":\\\"\\\",\\\"link_author\\\":\\\"\\\",\\\"show_create_date\\\":\\\"\\\",\\\"show_modify_date\\\":\\\"\\\",\\\"show_publish_date\\\":\\\"\\\",\\\"show_item_navigation\\\":\\\"\\\",\\\"show_icons\\\":\\\"\\\",\\\"show_print_icon\\\":\\\"\\\",\\\"show_email_icon\\\":\\\"\\\",\\\"show_vote\\\":\\\"\\\",\\\"show_hits\\\":\\\"\\\",\\\"show_noauth\\\":\\\"\\\",\\\"urls_position\\\":\\\"\\\",\\\"alternative_readmore\\\":\\\"\\\",\\\"article_layout\\\":\\\"\\\",\\\"show_publishing_options\\\":\\\"\\\",\\\"show_article_options\\\":\\\"\\\",\\\"show_urls_images_backend\\\":\\\"\\\",\\\"show_urls_images_frontend\\\":\\\"\\\",\\\"spfeatured_image\\\":\\\"\\\",\\\"post_format\\\":\\\"standard\\\",\\\"gallery\\\":\\\"\\\",\\\"audio\\\":\\\"\\\",\\\"video\\\":\\\"\\\",\\\"link_title\\\":\\\"\\\",\\\"link_url\\\":\\\"\\\",\\\"quote_text\\\":\\\"\\\",\\\"quote_author\\\":\\\"\\\",\\\"post_status\\\":\\\"\\\"}\",\"version\":2,\"ordering\":\"0\",\"metakey\":\"\",\"metadesc\":\"\",\"access\":\"1\",\"hits\":\"0\",\"metadata\":\"{\\\"robots\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"rights\\\":\\\"\\\",\\\"xreference\\\":\\\"\\\"}\",\"featured\":\"0\",\"language\":\"*\",\"xreference\":\"\"}', '0'),
('15', '1', '9', '', '2016-11-14 04:32:40', '602', '729', '22bd993bb11ac24338aa51a390b15553eed3c40f', '{\"id\":1,\"cid\":\"0\",\"type\":\"0\",\"name\":\"banner1\",\"alias\":\"banner1\",\"imptotal\":0,\"impmade\":\"0\",\"clicks\":\"0\",\"clickurl\":false,\"state\":\"1\",\"catid\":\"3\",\"description\":\"\",\"custombannercode\":\"\",\"sticky\":\"0\",\"ordering\":1,\"metakey\":\"\",\"params\":\"{\\\"imageurl\\\":\\\"images\\\\\\/banners\\\\\\/main_vis.jpg\\\",\\\"width\\\":\\\"\\\",\\\"height\\\":\\\"\\\",\\\"alt\\\":\\\"\\\"}\",\"own_prefix\":\"0\",\"metakey_prefix\":\"\",\"purchase_type\":\"-1\",\"track_clicks\":\"0\",\"track_impressions\":\"0\",\"checked_out\":null,\"checked_out_time\":null,\"publish_up\":\"0000-00-00 00:00:00\",\"publish_down\":\"0000-00-00 00:00:00\",\"reset\":\"2016-12-14 00:00:00\",\"created\":\"2016-11-14 04:32:40\",\"language\":\"*\",\"created_by\":\"602\",\"created_by_alias\":\"\",\"modified\":\"0000-00-00 00:00:00\",\"modified_by\":null,\"version\":1}', '0'),
('16', '7', '1', '', '2016-11-14 14:57:40', '602', '1882', '8926ac092d3869659e06b8d5096f9ec2e59c299d', '{\"id\":7,\"asset_id\":87,\"title\":\"Home\",\"alias\":\"home\",\"introtext\":\"\",\"fulltext\":\"\",\"state\":1,\"catid\":\"2\",\"created\":\"2016-11-14 14:57:40\",\"created_by\":\"602\",\"created_by_alias\":\"\",\"modified\":\"2016-11-14 14:57:40\",\"modified_by\":null,\"checked_out\":null,\"checked_out_time\":null,\"publish_up\":\"2016-11-14 14:57:40\",\"publish_down\":\"0000-00-00 00:00:00\",\"images\":\"{\\\"image_intro\\\":\\\"\\\",\\\"float_intro\\\":\\\"\\\",\\\"image_intro_alt\\\":\\\"\\\",\\\"image_intro_caption\\\":\\\"\\\",\\\"image_fulltext\\\":\\\"\\\",\\\"float_fulltext\\\":\\\"\\\",\\\"image_fulltext_alt\\\":\\\"\\\",\\\"image_fulltext_caption\\\":\\\"\\\"}\",\"urls\":\"{\\\"urla\\\":false,\\\"urlatext\\\":\\\"\\\",\\\"targeta\\\":\\\"\\\",\\\"urlb\\\":false,\\\"urlbtext\\\":\\\"\\\",\\\"targetb\\\":\\\"\\\",\\\"urlc\\\":false,\\\"urlctext\\\":\\\"\\\",\\\"targetc\\\":\\\"\\\"}\",\"attribs\":\"{\\\"show_title\\\":\\\"\\\",\\\"link_titles\\\":\\\"\\\",\\\"show_tags\\\":\\\"\\\",\\\"show_intro\\\":\\\"\\\",\\\"info_block_position\\\":\\\"\\\",\\\"info_block_show_title\\\":\\\"\\\",\\\"show_category\\\":\\\"\\\",\\\"link_category\\\":\\\"\\\",\\\"show_parent_category\\\":\\\"\\\",\\\"link_parent_category\\\":\\\"\\\",\\\"show_author\\\":\\\"\\\",\\\"link_author\\\":\\\"\\\",\\\"show_create_date\\\":\\\"\\\",\\\"show_modify_date\\\":\\\"\\\",\\\"show_publish_date\\\":\\\"\\\",\\\"show_item_navigation\\\":\\\"\\\",\\\"show_icons\\\":\\\"\\\",\\\"show_print_icon\\\":\\\"\\\",\\\"show_email_icon\\\":\\\"\\\",\\\"show_vote\\\":\\\"\\\",\\\"show_hits\\\":\\\"\\\",\\\"show_noauth\\\":\\\"\\\",\\\"urls_position\\\":\\\"\\\",\\\"alternative_readmore\\\":\\\"\\\",\\\"article_layout\\\":\\\"\\\",\\\"show_publishing_options\\\":\\\"\\\",\\\"show_article_options\\\":\\\"\\\",\\\"show_urls_images_backend\\\":\\\"\\\",\\\"show_urls_images_frontend\\\":\\\"\\\",\\\"spfeatured_image\\\":\\\"\\\",\\\"post_format\\\":\\\"standard\\\",\\\"gallery\\\":\\\"\\\",\\\"audio\\\":\\\"\\\",\\\"video\\\":\\\"\\\",\\\"link_title\\\":\\\"\\\",\\\"link_url\\\":\\\"\\\",\\\"quote_text\\\":\\\"\\\",\\\"quote_author\\\":\\\"\\\",\\\"post_status\\\":\\\"\\\"}\",\"version\":1,\"ordering\":null,\"metakey\":\"\",\"metadesc\":\"\",\"access\":\"1\",\"hits\":null,\"metadata\":\"{\\\"robots\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"rights\\\":\\\"\\\",\\\"xreference\\\":\\\"\\\"}\",\"featured\":\"0\",\"language\":\"*\",\"xreference\":\"\"}', '0');

DROP TABLE IF EXISTS `lal5d_update_sites`;
CREATE TABLE `lal5d_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  `extra_query` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Update Sites';

INSERT INTO lal5d_update_sites
(`update_site_id`, `name`, `type`, `location`, `enabled`, `last_check_timestamp`, `extra_query`) VALUES 
('1', 'Joomla! Core', 'collection', 'https://update.joomla.org/core/list.xml', '1', '1479127310', ''),
('2', 'Joomla! Extension Directory', 'collection', 'https://update.joomla.org/jed/list.xml', '1', '1479127312', ''),
('3', 'Accredited Joomla! Translations', 'collection', 'https://update.joomla.org/language/translationlist_3.xml', '1', '1479127318', ''),
('4', 'Joomla! Update Component Update Site', 'extension', 'https://update.joomla.org/core/extensions/com_joomlaupdate.xml', '1', '1479127320', ''),
('5', 'VirtueMart3 Update Site', 'extension', 'http://virtuemart.net/releases/vm3/virtuemart_update.xml', '1', '1479127321', ''),
('6', 'VirtueMart plg_vmpayment_standard Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_standard_update.xml', '1', '1479127321', ''),
('7', 'VirtueMart plg_vmpayment_klarna Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_klarna_update.xml', '1', '1479127322', ''),
('8', 'VirtueMart plg_vmpayment_klarnacheckout Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_klarnacheckout_update.xml', '1', '1479127322', ''),
('9', 'VirtueMart plg_vmpayment_sofort Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_sofort_update.xml', '1', '1479127322', ''),
('10', 'VirtueMart plg_vmpayment_paypal Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_paypal_update.xml', '1', '1479127323', ''),
('11', 'VirtueMart plg_vmpayment_heidelpay Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_heidelpay_update.xml', '1', '1479127323', ''),
('12', 'VirtueMart plg_vmpayment_paybox Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_paybox_update.xml', '1', '1479127324', ''),
('13', 'VirtueMart3 plg_vmpayment_tco Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_tco_update.xml', '1', '1479127324', ''),
('14', 'VirtueMart plg_vmpayment_amazon Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_amazon_update.xml', '1', '1479127324', ''),
('15', 'VirtueMart plg_system_amazon Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_system_amazon_update.xml', '1', '1479127325', ''),
('16', 'VirtueMart plg_vmpayment_realex_hpp_api Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_realex_hpp_api_update.xml', '1', '1479127325', ''),
('17', 'VirtueMart plg_vmuserfield_realex_hpp_api Update Site', 'extension', '\n            http://virtuemart.net/releases/vm3/plg_vmuserfield_realex_hpp_api_update.xml', '1', '1479127325', ''),
('18', 'VirtueMart3 plg_vmpayment_skrill Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_skrill_update.xml', '1', '1479127326', ''),
('19', 'VirtueMart plg_vmpayment_authorizenet Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_authorisenet_update.xml', '1', '1479127326', ''),
('20', 'VirtueMart plg_vmpayment_sofort_ideal Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_sofort_ideal_update.xml', '1', '1479127326', ''),
('21', 'VirtueMart plg_vmpayment_klikandpay Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmpayment_klikandpay_update.xml', '1', '1479127327', ''),
('22', 'VirtueMart3 plg_vmshipment_weight_countries Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmshipment_weight_countries_update.xml', '1', '1479127327', ''),
('23', 'VirtueMart3 plg_vmcustom_textinput Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmcustom_textinput_update.xml', '1', '1479127327', ''),
('24', 'VirtueMart3 plg_vmcustom_specification Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmcustom_specification_update.xml', '1', '1479127328', ''),
('25', 'VirtueMart3 plg_vmcalculation_avalara Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_vmcalculation_avalara_update.xml', '1', '1479127328', ''),
('26', 'VirtueMart3 plg_search_virtuemart Update Site', 'extension', 'http://virtuemart.net/releases/vm3/plg_search_virtuemart_update.xml', '1', '1479127328', ''),
('27', 'VirtueMart3 MOD_VMENU Update Site', 'extension', 'http://virtuemart.net/releases/vm3/mod_vmmenu_update.xml', '1', '1479127329', ''),
('28', 'VirtueMart3 mod_virtuemart_currencies Update Site', 'extension', 'http://virtuemart.net/releases/vm3/mod_virtuemart_currencies_update.xml', '1', '1479127329', ''),
('29', 'VirtueMart3 mod_virtuemart_product Update Site', 'extension', 'http://virtuemart.net/releases/vm3/mod_virtuemart_product_update.xml', '1', '1479127330', ''),
('30', 'VirtueMart3 mod_virtuemart_search Update Site', 'extension', 'http://virtuemart.net/releases/vm3/mod_virtuemart_search_update.xml', '1', '1479127331', ''),
('31', 'VirtueMart3 mod_virtuemart_manufacturer Update Site', 'extension', 'http://virtuemart.net/releases/vm3/mod_virtuemart_manufacturer_update.xml', '1', '1479127331', ''),
('32', 'VirtueMart3 mod_virtuemart_cart Update Site', 'extension', 'http://virtuemart.net/releases/vm3/mod_virtuemart_cart_update.xml', '1', '1479127332', ''),
('33', 'VirtueMart3 mod_virtuemart_category Update Site', 'extension', 'http://virtuemart.net/releases/vm3/mod_virtuemart_category_update.xml', '1', '1479127332', ''),
('34', 'VirtueMart3 AIO Update Site', 'extension', 'http://virtuemart.net/releases/vm3/virtuemart_aio_update.xml', '1', '1479127332', ''),
('35', 'Helix3 - Ajax', 'extension', 'http://www.joomshaper.com/updates/plg-ajax-helix3.xml', '1', '1479127334', ''),
('36', 'System - Helix3 Framework', 'extension', 'http://www.joomshaper.com/updates/plg-system-helix3.xml', '1', '1479127337', ''),
('37', 'Gantry Framework Update Site', 'extension', 'http://www.gantry-framework.org/updates/joomla16/gantry.xml', '1', '1479127338', ''),
('38', 'Akeeba Backup Core', 'extension', 'http://cdn.akeebabackup.com/updates/abcore.xml', '1', '0', ''),
('40', 'pagebuilder', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_pagebuilder.xml', '1', '0', ''),
('41', 'GTranslate', 'extension', 'http://gtranslate.net/downloads/gtranslate.xml', '1', '0', ''),
('42', 'imageshow', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_imageshow.xml', '1', '0', ''),
('43', 'poweradmin', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_poweradmin.xml', '1', '0', ''),
('44', 'uniform', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_uniform.xml', '1', '0', ''),
('45', 'mobilize', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_mobilize.xml', '1', '0', ''),
('46', 'easyslider', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_easyslider.xml', '1', '0', '');

DROP TABLE IF EXISTS `lal5d_update_sites_extensions`;
CREATE TABLE `lal5d_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Links extensions to update sites';

INSERT INTO lal5d_update_sites_extensions
(`update_site_id`, `extension_id`) VALUES 
('1', '700'),
('2', '700'),
('3', '802'),
('4', '28'),
('5', '10000'),
('6', '10002'),
('7', '10003'),
('8', '10004'),
('9', '10005'),
('10', '10006'),
('11', '10007'),
('12', '10008'),
('13', '10009'),
('14', '10010'),
('15', '10011'),
('16', '10012'),
('17', '10013'),
('18', '10014'),
('19', '10015'),
('20', '10016'),
('21', '10017'),
('22', '10018'),
('23', '10019'),
('24', '10020'),
('25', '10021'),
('26', '10022'),
('27', '10023'),
('28', '10024'),
('29', '10025'),
('30', '10026'),
('31', '10027'),
('32', '10028'),
('33', '10029'),
('34', '10001'),
('35', '10031'),
('36', '10032'),
('37', '10036'),
('38', '10041'),
('40', '10057'),
('41', '10065'),
('42', '10046'),
('43', '10071'),
('44', '10079'),
('45', '10084'),
('46', '10087');

DROP TABLE IF EXISTS `lal5d_updates`;
CREATE TABLE `lal5d_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `folder` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `detailsurl` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `infourl` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_query` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Available Updates';

INSERT INTO lal5d_updates
(`update_id`, `update_site_id`, `extension_id`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`, `extra_query`) VALUES 
('1', '3', '0', 'Armenian', '', 'pkg_hy-AM', 'package', '', '0', '3.4.4.1', '', 'https://update.joomla.org/language/details3/hy-AM_details.xml', '', ''),
('2', '3', '0', 'Malay', '', 'pkg_ms-MY', 'package', '', '0', '3.4.1.2', '', 'https://update.joomla.org/language/details3/ms-MY_details.xml', '', ''),
('3', '3', '0', 'Romanian', '', 'pkg_ro-RO', 'package', '', '0', '3.6.0.1', '', 'https://update.joomla.org/language/details3/ro-RO_details.xml', '', ''),
('4', '3', '0', 'Flemish', '', 'pkg_nl-BE', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/nl-BE_details.xml', '', ''),
('5', '3', '0', 'Chinese Traditional', '', 'pkg_zh-TW', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/zh-TW_details.xml', '', ''),
('6', '3', '0', 'French', '', 'pkg_fr-FR', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/fr-FR_details.xml', '', ''),
('7', '3', '0', 'Galician', '', 'pkg_gl-ES', 'package', '', '0', '3.3.1.2', '', 'https://update.joomla.org/language/details3/gl-ES_details.xml', '', ''),
('8', '3', '0', 'Georgian', '', 'pkg_ka-GE', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/ka-GE_details.xml', '', ''),
('9', '3', '0', 'Greek', '', 'pkg_el-GR', 'package', '', '0', '3.6.3.2', '', 'https://update.joomla.org/language/details3/el-GR_details.xml', '', ''),
('10', '3', '0', 'Japanese', '', 'pkg_ja-JP', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/ja-JP_details.xml', '', ''),
('11', '3', '0', 'Hebrew', '', 'pkg_he-IL', 'package', '', '0', '3.1.1.1', '', 'https://update.joomla.org/language/details3/he-IL_details.xml', '', ''),
('12', '3', '0', 'Hungarian', '', 'pkg_hu-HU', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/hu-HU_details.xml', '', ''),
('13', '3', '0', 'Afrikaans', '', 'pkg_af-ZA', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/af-ZA_details.xml', '', ''),
('14', '3', '0', 'Arabic Unitag', '', 'pkg_ar-AA', 'package', '', '0', '3.6.4.2', '', 'https://update.joomla.org/language/details3/ar-AA_details.xml', '', ''),
('15', '3', '0', 'Belarusian', '', 'pkg_be-BY', 'package', '', '0', '3.2.1.1', '', 'https://update.joomla.org/language/details3/be-BY_details.xml', '', ''),
('16', '3', '0', 'Bulgarian', '', 'pkg_bg-BG', 'package', '', '0', '3.4.4.2', '', 'https://update.joomla.org/language/details3/bg-BG_details.xml', '', ''),
('17', '3', '0', 'Catalan', '', 'pkg_ca-ES', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/ca-ES_details.xml', '', ''),
('18', '3', '0', 'Chinese Simplified', '', 'pkg_zh-CN', 'package', '', '0', '3.4.1.1', '', 'https://update.joomla.org/language/details3/zh-CN_details.xml', '', ''),
('19', '3', '0', 'Croatian', '', 'pkg_hr-HR', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/hr-HR_details.xml', '', ''),
('20', '3', '0', 'Czech', '', 'pkg_cs-CZ', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/cs-CZ_details.xml', '', ''),
('21', '3', '0', 'Danish', '', 'pkg_da-DK', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/da-DK_details.xml', '', ''),
('22', '3', '0', 'Dutch', '', 'pkg_nl-NL', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/nl-NL_details.xml', '', ''),
('23', '3', '0', 'Estonian', '', 'pkg_et-EE', 'package', '', '0', '3.6.0.1', '', 'https://update.joomla.org/language/details3/et-EE_details.xml', '', ''),
('24', '3', '0', 'Italian', '', 'pkg_it-IT', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/it-IT_details.xml', '', ''),
('25', '3', '0', 'Khmer', '', 'pkg_km-KH', 'package', '', '0', '3.4.5.1', '', 'https://update.joomla.org/language/details3/km-KH_details.xml', '', ''),
('26', '3', '0', 'Korean', '', 'pkg_ko-KR', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/ko-KR_details.xml', '', ''),
('27', '3', '0', 'Latvian', '', 'pkg_lv-LV', 'package', '', '0', '3.6.2.2', '', 'https://update.joomla.org/language/details3/lv-LV_details.xml', '', ''),
('28', '3', '0', 'Macedonian', '', 'pkg_mk-MK', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/mk-MK_details.xml', '', ''),
('29', '3', '0', 'Norwegian Bokmal', '', 'pkg_nb-NO', 'package', '', '0', '3.5.1.1', '', 'https://update.joomla.org/language/details3/nb-NO_details.xml', '', ''),
('30', '3', '0', 'Norwegian Nynorsk', '', 'pkg_nn-NO', 'package', '', '0', '3.4.2.1', '', 'https://update.joomla.org/language/details3/nn-NO_details.xml', '', ''),
('31', '3', '0', 'Persian', '', 'pkg_fa-IR', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/fa-IR_details.xml', '', ''),
('32', '3', '0', 'Polish', '', 'pkg_pl-PL', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/pl-PL_details.xml', '', ''),
('33', '3', '0', 'Portuguese', '', 'pkg_pt-PT', 'package', '', '0', '3.6.4.3', '', 'https://update.joomla.org/language/details3/pt-PT_details.xml', '', ''),
('34', '3', '0', 'Russian', '', 'pkg_ru-RU', 'package', '', '0', '3.6.2.2', '', 'https://update.joomla.org/language/details3/ru-RU_details.xml', '', ''),
('35', '3', '0', 'English AU', '', 'pkg_en-AU', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/en-AU_details.xml', '', ''),
('36', '3', '0', 'Slovak', '', 'pkg_sk-SK', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/sk-SK_details.xml', '', ''),
('37', '3', '0', 'English US', '', 'pkg_en-US', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/en-US_details.xml', '', ''),
('38', '3', '0', 'Swedish', '', 'pkg_sv-SE', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/sv-SE_details.xml', '', ''),
('39', '3', '0', 'Syriac', '', 'pkg_sy-IQ', 'package', '', '0', '3.4.5.1', '', 'https://update.joomla.org/language/details3/sy-IQ_details.xml', '', ''),
('40', '3', '0', 'Tamil', '', 'pkg_ta-IN', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/ta-IN_details.xml', '', ''),
('41', '3', '0', 'Thai', '', 'pkg_th-TH', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/th-TH_details.xml', '', ''),
('42', '3', '0', 'Turkish', '', 'pkg_tr-TR', 'package', '', '0', '3.6.2.1', '', 'https://update.joomla.org/language/details3/tr-TR_details.xml', '', ''),
('43', '3', '0', 'Ukrainian', '', 'pkg_uk-UA', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/uk-UA_details.xml', '', ''),
('44', '3', '0', 'Uyghur', '', 'pkg_ug-CN', 'package', '', '0', '3.3.0.1', '', 'https://update.joomla.org/language/details3/ug-CN_details.xml', '', ''),
('45', '3', '0', 'Albanian', '', 'pkg_sq-AL', 'package', '', '0', '3.1.1.1', '', 'https://update.joomla.org/language/details3/sq-AL_details.xml', '', ''),
('46', '3', '0', 'Basque', '', 'pkg_eu-ES', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/eu-ES_details.xml', '', ''),
('47', '3', '0', 'Hindi', '', 'pkg_hi-IN', 'package', '', '0', '3.3.6.2', '', 'https://update.joomla.org/language/details3/hi-IN_details.xml', '', ''),
('48', '3', '0', 'German DE', '', 'pkg_de-DE', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/de-DE_details.xml', '', ''),
('49', '3', '0', 'Portuguese Brazil', '', 'pkg_pt-BR', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/pt-BR_details.xml', '', ''),
('50', '3', '0', 'Serbian Latin', '', 'pkg_sr-YU', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/sr-YU_details.xml', '', '');

INSERT INTO lal5d_updates
(`update_id`, `update_site_id`, `extension_id`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`, `extra_query`) VALUES 
('51', '3', '0', 'Spanish', '', 'pkg_es-ES', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/es-ES_details.xml', '', ''),
('52', '3', '0', 'Bosnian', '', 'pkg_bs-BA', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/bs-BA_details.xml', '', ''),
('53', '3', '0', 'Serbian Cyrillic', '', 'pkg_sr-RS', 'package', '', '0', '3.6.3.1', '', 'https://update.joomla.org/language/details3/sr-RS_details.xml', '', ''),
('54', '3', '0', 'Vietnamese', '', 'pkg_vi-VN', 'package', '', '0', '3.2.1.1', '', 'https://update.joomla.org/language/details3/vi-VN_details.xml', '', ''),
('55', '3', '0', 'Bahasa Indonesia', '', 'pkg_id-ID', 'package', '', '0', '3.6.2.1', '', 'https://update.joomla.org/language/details3/id-ID_details.xml', '', ''),
('56', '3', '0', 'Finnish', '', 'pkg_fi-FI', 'package', '', '0', '3.6.2.1', '', 'https://update.joomla.org/language/details3/fi-FI_details.xml', '', ''),
('57', '3', '0', 'Swahili', '', 'pkg_sw-KE', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/sw-KE_details.xml', '', ''),
('58', '3', '0', 'Montenegrin', '', 'pkg_srp-ME', 'package', '', '0', '3.3.1.1', '', 'https://update.joomla.org/language/details3/srp-ME_details.xml', '', ''),
('59', '3', '0', 'English CA', '', 'pkg_en-CA', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/en-CA_details.xml', '', ''),
('60', '3', '0', 'French CA', '', 'pkg_fr-CA', 'package', '', '0', '3.5.1.2', '', 'https://update.joomla.org/language/details3/fr-CA_details.xml', '', ''),
('61', '3', '0', 'Welsh', '', 'pkg_cy-GB', 'package', '', '0', '3.3.0.2', '', 'https://update.joomla.org/language/details3/cy-GB_details.xml', '', ''),
('62', '3', '0', 'Sinhala', '', 'pkg_si-LK', 'package', '', '0', '3.3.1.1', '', 'https://update.joomla.org/language/details3/si-LK_details.xml', '', ''),
('63', '3', '0', 'Dari Persian', '', 'pkg_prs-AF', 'package', '', '0', '3.4.4.1', '', 'https://update.joomla.org/language/details3/prs-AF_details.xml', '', ''),
('64', '3', '0', 'Turkmen', '', 'pkg_tk-TM', 'package', '', '0', '3.5.0.2', '', 'https://update.joomla.org/language/details3/tk-TM_details.xml', '', ''),
('65', '3', '0', 'Irish', '', 'pkg_ga-IE', 'package', '', '0', '3.6.0.1', '', 'https://update.joomla.org/language/details3/ga-IE_details.xml', '', ''),
('66', '3', '0', 'Dzongkha', '', 'pkg_dz-BT', 'package', '', '0', '3.6.2.1', '', 'https://update.joomla.org/language/details3/dz-BT_details.xml', '', ''),
('67', '3', '0', 'Slovenian', '', 'pkg_sl-SI', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/sl-SI_details.xml', '', ''),
('68', '3', '0', 'Spanish CO', '', 'pkg_es-CO', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/es-CO_details.xml', '', ''),
('69', '3', '0', 'German CH', '', 'pkg_de-CH', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/de-CH_details.xml', '', ''),
('70', '3', '0', 'German AT', '', 'pkg_de-AT', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/de-AT_details.xml', '', ''),
('71', '3', '0', 'German LI', '', 'pkg_de-LI', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/de-LI_details.xml', '', ''),
('72', '3', '0', 'German LU', '', 'pkg_de-LU', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/de-LU_details.xml', '', ''),
('73', '3', '0', 'English NZ', '', 'pkg_en-NZ', 'package', '', '0', '3.6.4.1', '', 'https://update.joomla.org/language/details3/en-NZ_details.xml', '', ''),
('74', '35', '10031', 'Helix3 - Ajax', '', 'helix3', 'plugin', 'ajax', '0', '1.7', '', 'http://www.joomshaper.com/updates/plg-ajax-helix3.xml', '', ''),
('75', '36', '10032', 'System - Helix3 Framework', '', 'helix3', 'plugin', 'system', '0', '1.7', '', 'http://www.joomshaper.com/updates/plg-system-helix3.xml', '', '');

DROP TABLE IF EXISTS `lal5d_user_keys`;
CREATE TABLE `lal5d_user_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `series` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invalid` tinyint(4) NOT NULL,
  `time` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uastring` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `series` (`series`),
  UNIQUE KEY `series_2` (`series`),
  UNIQUE KEY `series_3` (`series`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_user_notes`;
CREATE TABLE `lal5d_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `lal5d_user_profiles`;
CREATE TABLE `lal5d_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Simple user profile storage table';

DROP TABLE IF EXISTS `lal5d_user_usergroup_map`;
CREATE TABLE `lal5d_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_user_usergroup_map
(`user_id`, `group_id`) VALUES 
('602', '8');

DROP TABLE IF EXISTS `lal5d_usergroups`;
CREATE TABLE `lal5d_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_usergroups
(`id`, `parent_id`, `lft`, `rgt`, `title`) VALUES 
('1', '0', '1', '18', 'Public'),
('2', '1', '8', '15', 'Registered'),
('3', '2', '9', '14', 'Author'),
('4', '3', '10', '13', 'Editor'),
('5', '4', '11', '12', 'Publisher'),
('6', '1', '4', '7', 'Manager'),
('7', '6', '5', '6', 'Administrator'),
('8', '1', '16', '17', 'Super Users'),
('9', '1', '2', '3', 'Guest');

DROP TABLE IF EXISTS `lal5d_users`;
CREATE TABLE `lal5d_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  `otpKey` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Two factor authentication encrypted keys',
  `otep` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'One time emergency passwords',
  `requireReset` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Require user to reset password on next login',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`(100)),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=603 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_users
(`id`, `name`, `username`, `email`, `password`, `block`, `sendEmail`, `registerDate`, `lastvisitDate`, `activation`, `params`, `lastResetTime`, `resetCount`, `otpKey`, `otep`, `requireReset`) VALUES 
('602', 'Super User', 'thushara.sandakelum', 'thushara.sandakelum00@gmail.com', '$2y$10$O3LX1mQ2AfeBO/T7kd3zvO1SSthUg.J7fYnIHUvBC/9nDcHVP0tqi', '0', '1', '2016-11-12 05:26:33', '2016-11-14 14:37:27', '0', '{}', '0000-00-00 00:00:00', '0', '', '', '0');

DROP TABLE IF EXISTS `lal5d_utf8_conversion`;
CREATE TABLE `lal5d_utf8_conversion` (
  `converted` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_utf8_conversion
(`converted`) VALUES 
('2');

DROP TABLE IF EXISTS `lal5d_viewlevels`;
CREATE TABLE `lal5d_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO lal5d_viewlevels
(`id`, `title`, `ordering`, `rules`) VALUES 
('1', 'Public', '0', '[1]'),
('2', 'Registered', '2', '[6,2,8]'),
('3', 'Special', '3', '[6,3,8]'),
('5', 'Guest', '1', '[9]'),
('6', 'Super Users', '4', '[8]');

DROP TABLE IF EXISTS `lal5d_virtuemart_adminmenuentries`;
CREATE TABLE `lal5d_virtuemart_adminmenuentries` (
  `id` tinyint(1) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'The ID of the VM Module, this Item is assigned to',
  `parent_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` char(64) NOT NULL DEFAULT '0',
  `link` char(64) NOT NULL DEFAULT '0',
  `depends` char(64) NOT NULL DEFAULT '' COMMENT 'Names of the Parameters, this Item depends on',
  `icon_class` char(96) DEFAULT NULL,
  `ordering` int(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `tooltip` char(128) DEFAULT NULL,
  `view` char(32) DEFAULT NULL,
  `task` char(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `module_id` (`module_id`),
  KEY `published` (`published`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='Administration Menu Items';

INSERT INTO lal5d_virtuemart_adminmenuentries
(`id`, `module_id`, `parent_id`, `name`, `link`, `depends`, `icon_class`, `ordering`, `published`, `tooltip`, `view`, `task`) VALUES 
('1', '1', '0', 'COM_VIRTUEMART_CATEGORY_S', '', '', 'vmicon vmicon-16-folder_camera', '1', '1', '', 'category', ''),
('2', '1', '0', 'COM_VIRTUEMART_PRODUCT_S', '', '', 'vmicon vmicon-16-camera', '2', '1', '', 'product', ''),
('3', '1', '0', 'COM_VIRTUEMART_PRODUCT_CUSTOM_FIELD_S', '', '', 'vmicon vmicon-16-document_move', '5', '1', '', 'custom', ''),
('4', '1', '0', 'COM_VIRTUEMART_PRODUCT_INVENTORY', '', '', 'vmicon vmicon-16-price_watch', '7', '1', '', 'inventory', ''),
('5', '1', '0', 'COM_VIRTUEMART_CALC_S', '', '', 'vmicon vmicon-16-calculator', '8', '1', '', 'calc', ''),
('6', '1', '0', 'COM_VIRTUEMART_REVIEW_RATE_S', '', '', 'vmicon vmicon-16-comments', '9', '1', '', 'ratings', ''),
('7', '2', '0', 'COM_VIRTUEMART_ORDER_S', '', '', 'vmicon vmicon-16-page_white_stack', '1', '1', '', 'orders', ''),
('8', '2', '0', 'COM_VIRTUEMART_COUPON_S', '', '', 'vmicon vmicon-16-shopping', '10', '1', '', 'coupon', ''),
('9', '2', '0', 'COM_VIRTUEMART_REPORT', '', '', 'vmicon vmicon-16-chart_bar', '3', '1', '', 'report', ''),
('10', '2', '0', 'COM_VIRTUEMART_USER_S', '', '', 'vmicon vmicon-16-user', '4', '1', '', 'user', ''),
('11', '2', '0', 'COM_VIRTUEMART_SHOPPERGROUP_S', '', '', 'vmicon vmicon-16-user-group', '5', '1', '', 'shoppergroup', ''),
('12', '3', '0', 'COM_VIRTUEMART_MANUFACTURER_S', '', '', 'vmicon vmicon-16-wrench_orange', '1', '1', '', 'manufacturer', ''),
('13', '3', '0', 'COM_VIRTUEMART_MANUFACTURER_CATEGORY_S', '', '', 'vmicon vmicon-16-folder_wrench', '2', '1', '', 'manufacturercategories', ''),
('14', '4', '0', 'COM_VIRTUEMART_STORE', '', '', 'vmicon vmicon-16-reseller_account_template', '1', '1', '', 'user', 'editshop'),
('15', '4', '0', 'COM_VIRTUEMART_MEDIA_S', '', '', 'vmicon vmicon-16-pictures', '2', '1', '', 'media', ''),
('16', '4', '0', 'COM_VIRTUEMART_SHIPMENTMETHOD_S', '', '', 'vmicon vmicon-16-lorry', '3', '1', '', 'shipmentmethod', ''),
('17', '4', '0', 'COM_VIRTUEMART_PAYMENTMETHOD_S', '', '', 'vmicon vmicon-16-creditcards', '4', '1', '', 'paymentmethod', ''),
('18', '5', '0', 'COM_VIRTUEMART_CONFIGURATION', '', '', 'vmicon vmicon-16-config', '1', '1', '', 'config', ''),
('19', '5', '0', 'COM_VIRTUEMART_USERFIELD_S', '', '', 'vmicon vmicon-16-participation_rate', '2', '1', '', 'userfields', ''),
('20', '5', '0', 'COM_VIRTUEMART_ORDERSTATUS_S', '', '', 'vmicon vmicon-16-document_editing', '3', '1', '', 'orderstatus', ''),
('21', '5', '0', 'COM_VIRTUEMART_CURRENCY_S', '', '', 'vmicon vmicon-16-coins', '5', '1', '', 'currency', ''),
('22', '5', '0', 'COM_VIRTUEMART_COUNTRY_S', '', '', 'vmicon vmicon-16-globe', '6', '1', '', 'country', ''),
('23', '11', '0', 'COM_VIRTUEMART_MIGRATION_UPDATE', '', '', 'vmicon vmicon-16-installer_box', '0', '1', '', 'updatesmigration', ''),
('24', '11', '0', 'COM_VIRTUEMART_ABOUT', '', '', 'vmicon vmicon-16-info', '10', '1', '', 'about', ''),
('25', '11', '0', 'COM_VIRTUEMART_HELP_TOPICS', 'http://docs.virtuemart.net/', '', 'vmicon vmicon-16-help', '5', '1', '', '', ''),
('26', '11', '0', 'COM_VIRTUEMART_COMMUNITY_FORUM', 'http://forum.virtuemart.net/', '', 'vmicon vmicon-16-reseller_programm', '7', '1', '', '', ''),
('27', '11', '0', 'COM_VIRTUEMART_STATISTIC_SUMMARY', '', '', 'vmicon vmicon-16-info', '1', '1', '', 'virtuemart', ''),
('28', '11', '0', 'COM_VIRTUEMART_LOG', '', '', 'vmicon vmicon-16-info', '2', '1', '', 'log', ''),
('29', '11', '0', 'COM_VIRTUEMART_SUPPORT', '', '', 'vmicon vmicon-16-help', '3', '1', '', 'support', '');

DROP TABLE IF EXISTS `lal5d_virtuemart_calc_categories`;
CREATE TABLE `lal5d_virtuemart_calc_categories` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_calc_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_category_id` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_calc_id` (`virtuemart_calc_id`,`virtuemart_category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_calc_categories
(`id`, `virtuemart_calc_id`, `virtuemart_category_id`) VALUES 
('1', '1', '2'),
('2', '1', '3'),
('3', '1', '4'),
('4', '1', '7'),
('5', '1', '8'),
('6', '1', '9'),
('7', '2', '9'),
('8', '3', '11'),
('9', '4', '12');

DROP TABLE IF EXISTS `lal5d_virtuemart_calc_countries`;
CREATE TABLE `lal5d_virtuemart_calc_countries` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_calc_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_country_id` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_calc_id` (`virtuemart_calc_id`,`virtuemart_country_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_virtuemart_calc_manufacturers`;
CREATE TABLE `lal5d_virtuemart_calc_manufacturers` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_calc_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_manufacturer_id` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_calc_id` (`virtuemart_calc_id`,`virtuemart_manufacturer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_virtuemart_calc_shoppergroups`;
CREATE TABLE `lal5d_virtuemart_calc_shoppergroups` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_calc_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_shoppergroup_id` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_calc_id` (`virtuemart_calc_id`,`virtuemart_shoppergroup_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_virtuemart_calc_states`;
CREATE TABLE `lal5d_virtuemart_calc_states` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_calc_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_state_id` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_calc_id` (`virtuemart_calc_id`,`virtuemart_state_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_virtuemart_calcs`;
CREATE TABLE `lal5d_virtuemart_calcs` (
  `virtuemart_calc_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Belongs to vendor',
  `calc_jplugin_id` int(1) NOT NULL DEFAULT '0',
  `calc_name` varchar(64) NOT NULL DEFAULT '' COMMENT 'Name of the rule',
  `calc_descr` varchar(128) NOT NULL DEFAULT '' COMMENT 'Description',
  `calc_kind` varchar(16) NOT NULL DEFAULT '' COMMENT 'Discount/Tax/Margin/Commission',
  `calc_value_mathop` varchar(8) NOT NULL DEFAULT '' COMMENT 'the mathematical operation like (+,-,+%,-%)',
  `calc_value` decimal(10,4) NOT NULL DEFAULT '0.0000' COMMENT 'The Amount',
  `calc_currency` smallint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Currency of the Rule',
  `calc_shopper_published` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Visible for Shoppers',
  `calc_vendor_published` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Visible for Vendors',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Startdate if nothing is set = permanent',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Enddate if nothing is set = permanent',
  `for_override` tinyint(1) NOT NULL DEFAULT '0',
  `calc_params` varchar(18000) NOT NULL DEFAULT '',
  `ordering` int(1) NOT NULL DEFAULT '0',
  `shared` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_calc_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `published` (`published`),
  KEY `calc_kind` (`calc_kind`),
  KEY `shared` (`shared`),
  KEY `publish_up` (`publish_up`),
  KEY `publish_down` (`publish_down`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_calcs
(`virtuemart_calc_id`, `virtuemart_vendor_id`, `calc_jplugin_id`, `calc_name`, `calc_descr`, `calc_kind`, `calc_value_mathop`, `calc_value`, `calc_currency`, `calc_shopper_published`, `calc_vendor_published`, `publish_up`, `publish_down`, `for_override`, `calc_params`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '1', '0', 'Tax 20%', 'common vat, if your shop needs only one VAT, just use it without any category set', 'VatTax', '+%', '20.0000', '47', '0', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '0', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('2', '1', '0', 'Discount 5% for ladies', 'The discount is based on net price with VAT, the tax amount is recalculated based on the new net price', 'DATax', '-%', '5.0000', '47', '0', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '0', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('3', '1', '0', 'Tax 10%', 'as example for the category product variants', 'VatTax', '+%', '10.0000', '47', '0', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '0', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('4', '1', '0', 'Tax 7%', 'as example for the category product attributes', 'VatTax', '+%', '7.0000', '47', '0', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '0', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_carts`;
CREATE TABLE `lal5d_virtuemart_carts` (
  `virtuemart_cart_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_user_id` int(1) unsigned NOT NULL,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL,
  `cartData` varbinary(50000) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_cart_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `virtuemart_user_id` (`virtuemart_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Used to store the cart';

DROP TABLE IF EXISTS `lal5d_virtuemart_categories`;
CREATE TABLE `lal5d_virtuemart_categories` (
  `virtuemart_category_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Belongs to vendor',
  `category_template` char(128) DEFAULT NULL,
  `category_layout` char(64) DEFAULT NULL,
  `category_product_layout` char(64) DEFAULT NULL,
  `products_per_row` tinyint(1) DEFAULT NULL,
  `limit_list_step` char(32) DEFAULT NULL,
  `limit_list_initial` smallint(1) unsigned DEFAULT NULL,
  `hits` int(1) unsigned NOT NULL DEFAULT '0',
  `metarobot` char(40) NOT NULL DEFAULT '',
  `metaauthor` char(64) NOT NULL DEFAULT '',
  `ordering` int(1) NOT NULL DEFAULT '0',
  `shared` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_category_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='Product Categories are stored here';

INSERT INTO lal5d_virtuemart_categories
(`virtuemart_category_id`, `virtuemart_vendor_id`, `category_template`, `category_layout`, `category_product_layout`, `products_per_row`, `limit_list_step`, `limit_list_initial`, `hits`, `metarobot`, `metaauthor`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('2', '1', '', '', '', '', '', '', '0', '', '', '2', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('3', '1', '', '', '', '', '', '', '0', '', '', '3', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('4', '1', '', '', '', '', '', '', '0', '', '', '4', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('7', '1', '', '', '', '', '', '', '0', '', '', '5', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('8', '1', '', '', '', '', '', '', '0', '', '', '7', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('9', '1', '', '', '', '', '', '', '0', '', '', '6', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('11', '1', '', '', '', '', '', '', '0', '', '', '1', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('12', '1', '', '', '', '', '', '', '0', '', '', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_categories_en_gb`;
CREATE TABLE `lal5d_virtuemart_categories_en_gb` (
  `virtuemart_category_id` int(1) unsigned NOT NULL,
  `category_name` varchar(180) NOT NULL DEFAULT '',
  `category_description` varchar(19000) NOT NULL DEFAULT '',
  `metadesc` varchar(400) NOT NULL DEFAULT '',
  `metakey` varchar(400) NOT NULL DEFAULT '',
  `customtitle` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(192) NOT NULL DEFAULT '',
  PRIMARY KEY (`virtuemart_category_id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_categories_en_gb
(`virtuemart_category_id`, `category_name`, `category_description`, `metadesc`, `metakey`, `customtitle`, `slug`) VALUES 
('2', 'Product pattern', '<p><span style=\"background-color: #fcdb73; text-align: center; padding: 5px 40px;\">Example for usage of product pattern. For showcase reason the PATTERN is NOT unpublished.</span></p>', '', '', '', 'product-pattern'),
('3', 'Pagination', '<p>Use this category to test the ordering of products. Sort order by Name, SKU, Manufacturer (more available in vmconfig &gt; product order settings)<br />Additionally filter by Manufacturer,</p>&#13;&#10;<p style=\"background-color: #fcdb73; text-align: center; padding: 5px 40px;\"><strong>Advise:</strong> There are three pattern HGD#0, CEG#0, FAC#0. The last two digits represent the sort order.</p>', '', '', '', 'pagination'),
('4', 'Headpiece', '', '', '', '', 'headpiece'),
('7', 'Wear', '', '', '', '', 'wear'),
('8', 'Mister', '<p>Sample for Subcategory. <br />Select superordinated category in VM BE &gt; <em>Product Categories</em> &gt; Your Category in section <em>Details &gt; Category Ordering </em></p>', '', '', '', 'mister'),
('9', 'Lady', '<p>Sample for Subcategory. <br />Select superordinated category in VM BE &gt; <em>Product Categories</em> &gt; Your Category in section <em>Details &gt; Category Ordering </em></p>', '', '', '', 'lady'),
('11', 'Product variants', '<p><span style=\"background-color: #fcdb73; text-align: center; padding: 5px 40px;\">Product variants by customfields w/ user input.</span></p>', '', '', '', 'product-variants'),
('12', 'Product attributes', '<p><span style=\"background-color: #fcdb73; text-align: center; padding: 5px 40px;\">Products using customfields as attribute.</span></p>', '', '', '', 'product-attributes');

DROP TABLE IF EXISTS `lal5d_virtuemart_category_categories`;
CREATE TABLE `lal5d_virtuemart_category_categories` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `category_parent_id` int(1) unsigned NOT NULL DEFAULT '0',
  `category_child_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_parent_id` (`category_parent_id`,`category_child_id`),
  KEY `category_child_id` (`category_child_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='Category child-parent relation list';

INSERT INTO lal5d_virtuemart_category_categories
(`id`, `category_parent_id`, `category_child_id`, `ordering`) VALUES 
('2', '0', '2', '4'),
('3', '0', '3', '6'),
('4', '0', '4', '6'),
('11', '0', '11', '1'),
('7', '0', '7', '5'),
('8', '7', '8', '8'),
('9', '7', '9', '7'),
('12', '0', '12', '2');

DROP TABLE IF EXISTS `lal5d_virtuemart_category_medias`;
CREATE TABLE `lal5d_virtuemart_category_medias` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_category_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_media_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_category_id` (`virtuemart_category_id`,`virtuemart_media_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_category_medias
(`id`, `virtuemart_category_id`, `virtuemart_media_id`, `ordering`) VALUES 
('1', '12', '10', '1'),
('2', '3', '10', '1'),
('3', '2', '10', '1'),
('4', '7', '11', '1'),
('5', '4', '12', '1'),
('6', '8', '11', '1'),
('7', '11', '10', '1'),
('8', '9', '13', '1');

DROP TABLE IF EXISTS `lal5d_virtuemart_configs`;
CREATE TABLE `lal5d_virtuemart_configs` (
  `virtuemart_config_id` tinyint(1) unsigned NOT NULL AUTO_INCREMENT,
  `config` text,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_config_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Holds configuration settings';

INSERT INTO lal5d_virtuemart_configs
(`virtuemart_config_id`, `config`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', 'useSSL=\"0\"|dangeroustools=\"0\"|debug_enable=\"none\"|vmdev=\"none\"|google_jquery=\"0\"|multix=\"none\"|usefancy=\"1\"|jchosen=\"1\"|enableEnglish=\"1\"|shop_is_offline=\"0\"|offline_message=\"Our Shop is currently down for maintenance. Please check back again soon.\"|use_as_catalog=\"0\"|currency_converter_module=\"convertECB.php\"|order_mail_html=\"1\"|useVendorEmail=\"0\"|pdf_button_enable=\"1\"|show_emailfriend=\"0\"|show_printicon=\"1\"|show_out_of_stock_products=\"1\"|ask_captcha=\"1\"|coupons_enable=\"1\"|show_uncat_products=\"0\"|show_uncat_child_products=\"0\"|show_unpub_cat_products=\"1\"|coupons_default_expire=\"1,M\"|weight_unit_default=\"KG\"|lwh_unit_default=\"m\"|list_limit=\"30\"|showReviewFor=\"all\"|reviewMode=\"bought\"|showRatingFor=\"all\"|ratingMode=\"bought\"|reviews_autopublish=\"1\"|reviews_minimum_comment_length=\"0\"|reviews_maximum_comment_length=\"2000\"|product_navigation=\"1\"|display_stock=\"1\"|vmtemplate=\"0\"|categorytemplate=\"0\"|showCategory=\"1\"|categorylayout=\"0\"|categories_per_row=\"3\"|productlayout=\"0\"|products_per_row=\"3\"|llimit_init_FE=\"24\"|vmlayout=\"0\"|show_store_desc=\"1\"|show_categories=\"1\"|homepage_categories_per_row=\"3\"|homepage_products_per_row=\"3\"|show_featured=\"1\"|featured_products_rows=\"1\"|show_topTen=\"1\"|topTen_products_rows=\"1\"|show_recent=\"1\"|recent_products_rows=\"1\"|show_latest=\"1\"|latest_products_rows=\"1\"|assets_general_path=\"components\\/com_virtuemart\\/assets\\/\"|media_category_path=\"images\\/stories\\/virtuemart\\/category\\/\"|media_product_path=\"images\\/stories\\/virtuemart\\/product\\/\"|media_manufacturer_path=\"images\\/stories\\/virtuemart\\/manufacturer\\/\"|media_vendor_path=\"images\\/stories\\/virtuemart\\/vendor\\/\"|forSale_path_thumb=\"images\\/stories\\/virtuemart\\/forSale\\/resized\\/\"|img_resize_enable=\"1\"|img_width=\"0\"|img_height=\"90\"|no_image_set=\"noimage.gif\"|no_image_found=\"warning.png\"|browse_orderby_field=\"pc.ordering\"|browse_cat_orderby_field=\"c.ordering,category_name\"|browse_orderby_fields=[\"`p`.product_sku\",\"category_name\",\"mf_name\",\"product_name\",\"pc.ordering\"]|browse_search_fields=[\"`p`.product_sku\",\"category_name\",\"category_description\",\"mf_name\",\"product_name\",\"product_s_desc\",\"product_desc\"]|askprice=\"1\"|roundindig=\"1\"|show_prices=\"1\"|price_show_packaging_pricelabel=\"0\"|show_tax=\"1\"|basePrice=\"0\"|basePriceText=\"1\"|basePriceRounding=\"-1\"|variantModification=\"0\"|variantModificationText=\"1\"|variantModificationRounding=\"-1\"|basePriceVariant=\"1\"|basePriceVariantText=\"1\"|basePriceVariantRounding=\"-1\"|basePriceWithTax=\"0\"|basePriceWithTaxText=\"1\"|basePriceWithTaxRounding=\"-1\"|discountedPriceWithoutTax=\"1\"|discountedPriceWithoutTaxText=\"1\"|discountedPriceWithoutTaxRounding=\"-1\"|salesPriceWithDiscount=\"0\"|salesPriceWithDiscountText=\"1\"|salesPriceWithDiscountRounding=\"-1\"|salesPrice=\"1\"|salesPriceText=\"1\"|salesPriceRounding=\"-1\"|priceWithoutTax=\"1\"|priceWithoutTaxText=\"1\"|priceWithoutTaxRounding=\"-1\"|discountAmount=\"1\"|discountAmountText=\"1\"|discountAmountRounding=\"-1\"|taxAmount=\"1\"|taxAmountText=\"1\"|taxAmountRounding=\"-1\"|unitPrice=\"1\"|unitPriceText=\"1\"|unitPriceRounding=\"-1\"|addtocart_popup=\"1\"|check_stock=\"0\"|automatic_payment=\"0\"|automatic_shipment=\"0\"|oncheckout_opc=\"1\"|oncheckout_ajax=\"1\"|oncheckout_show_legal_info=\"1\"|oncheckout_show_register=\"1\"|oncheckout_show_steps=\"0\"|oncheckout_show_register_text=\"COM_VIRTUEMART_ONCHECKOUT_DEFAULT_TEXT_REGISTER\"|oncheckout_show_images=\"1\"|inv_os=\"C\"|email_os_s=[\"U\",\"C\",\"X\",\"R\",\"S\"]|email_os_v=[\"U\",\"C\",\"X\",\"R\"]|seo_disabled=\"0\"|seo_translate=\"0\"|seo_use_id=\"0\"|sctime=1478928681.47494|vmlang=\"en_gb\"', '0000-00-00 00:00:00', '0', '2016-11-12 05:31:18', '602', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_countries`;
CREATE TABLE `lal5d_virtuemart_countries` (
  `virtuemart_country_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_worldzone_id` tinyint(1) NOT NULL DEFAULT '1',
  `country_name` varchar(64) DEFAULT NULL,
  `country_3_code` char(3) DEFAULT NULL,
  `country_2_code` char(2) DEFAULT NULL,
  `ordering` int(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_country_id`),
  KEY `country_3_code` (`country_3_code`),
  KEY `country_2_code` (`country_2_code`),
  KEY `country_name` (`country_name`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=249 DEFAULT CHARSET=utf8 COMMENT='Country records';

INSERT INTO lal5d_virtuemart_countries
(`virtuemart_country_id`, `virtuemart_worldzone_id`, `country_name`, `country_3_code`, `country_2_code`, `ordering`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '1', 'Afghanistan', 'AFG', 'AF', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('2', '1', 'Albania', 'ALB', 'AL', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('3', '1', 'Algeria', 'DZA', 'DZ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('4', '1', 'American Samoa', 'ASM', 'AS', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('5', '1', 'Andorra', 'AND', 'AD', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('6', '1', 'Angola', 'AGO', 'AO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('7', '1', 'Anguilla', 'AIA', 'AI', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('8', '1', 'Antarctica', 'ATA', 'AQ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('9', '1', 'Antigua and Barbuda', 'ATG', 'AG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('10', '1', 'Argentina', 'ARG', 'AR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('11', '1', 'Armenia', 'ARM', 'AM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('12', '1', 'Aruba', 'ABW', 'AW', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('13', '1', 'Australia', 'AUS', 'AU', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('14', '1', 'Austria', 'AUT', 'AT', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('15', '1', 'Azerbaijan', 'AZE', 'AZ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('16', '1', 'Bahamas', 'BHS', 'BS', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('17', '1', 'Bahrain', 'BHR', 'BH', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('18', '1', 'Bangladesh', 'BGD', 'BD', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('19', '1', 'Barbados', 'BRB', 'BB', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('20', '1', 'Belarus', 'BLR', 'BY', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('21', '1', 'Belgium', 'BEL', 'BE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('22', '1', 'Belize', 'BLZ', 'BZ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('23', '1', 'Benin', 'BEN', 'BJ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('24', '1', 'Bermuda', 'BMU', 'BM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('25', '1', 'Bhutan', 'BTN', 'BT', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('26', '1', 'Bolivia', 'BOL', 'BO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('27', '1', 'Bosnia and Herzegowina', 'BIH', 'BA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('28', '1', 'Botswana', 'BWA', 'BW', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('29', '1', 'Bouvet Island', 'BVT', 'BV', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('30', '1', 'Brazil', 'BRA', 'BR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('31', '1', 'British Indian Ocean Territory', 'IOT', 'IO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('32', '1', 'Brunei Darussalam', 'BRN', 'BN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('33', '1', 'Bulgaria', 'BGR', 'BG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('34', '1', 'Burkina Faso', 'BFA', 'BF', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('35', '1', 'Burundi', 'BDI', 'BI', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('36', '1', 'Cambodia', 'KHM', 'KH', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('37', '1', 'Cameroon', 'CMR', 'CM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('38', '1', 'Canada', 'CAN', 'CA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('39', '1', 'Cape Verde', 'CPV', 'CV', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('40', '1', 'Cayman Islands', 'CYM', 'KY', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('41', '1', 'Central African Republic', 'CAF', 'CF', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('42', '1', 'Chad', 'TCD', 'TD', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('43', '1', 'Chile', 'CHL', 'CL', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('44', '1', 'China', 'CHN', 'CN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('45', '1', 'Christmas Island', 'CXR', 'CX', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('46', '1', 'Cocos (Keeling) Islands', 'CCK', 'CC', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('47', '1', 'Colombia', 'COL', 'CO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('48', '1', 'Comoros', 'COM', 'KM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('49', '1', 'Congo', 'COG', 'CG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('50', '1', 'Cook Islands', 'COK', 'CK', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_countries
(`virtuemart_country_id`, `virtuemart_worldzone_id`, `country_name`, `country_3_code`, `country_2_code`, `ordering`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('51', '1', 'Costa Rica', 'CRI', 'CR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('52', '1', 'Cote D\'Ivoire', 'CIV', 'CI', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('53', '1', 'Croatia', 'HRV', 'HR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('54', '1', 'Cuba', 'CUB', 'CU', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('55', '1', 'Cyprus', 'CYP', 'CY', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('56', '1', 'Czech Republic', 'CZE', 'CZ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('57', '1', 'Denmark', 'DNK', 'DK', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('58', '1', 'Djibouti', 'DJI', 'DJ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('59', '1', 'Dominica', 'DMA', 'DM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('60', '1', 'Dominican Republic', 'DOM', 'DO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('61', '1', 'East Timor', 'TLS', 'TL', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('62', '1', 'Ecuador', 'ECU', 'EC', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('63', '1', 'Egypt', 'EGY', 'EG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('64', '1', 'El Salvador', 'SLV', 'SV', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('65', '1', 'Equatorial Guinea', 'GNQ', 'GQ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('66', '1', 'Eritrea', 'ERI', 'ER', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('67', '1', 'Estonia', 'EST', 'EE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('68', '1', 'Ethiopia', 'ETH', 'ET', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('69', '1', 'Falkland Islands (Malvinas)', 'FLK', 'FK', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('70', '1', 'Faroe Islands', 'FRO', 'FO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('71', '1', 'Fiji', 'FJI', 'FJ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('72', '1', 'Finland', 'FIN', 'FI', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('73', '1', 'France', 'FRA', 'FR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('75', '1', 'French Guiana', 'GUF', 'GF', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('76', '1', 'French Polynesia', 'PYF', 'PF', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('77', '1', 'French Southern Territories', 'ATF', 'TF', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('78', '1', 'Gabon', 'GAB', 'GA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('79', '1', 'Gambia', 'GMB', 'GM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('80', '1', 'Georgia', 'GEO', 'GE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('81', '1', 'Germany', 'DEU', 'DE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('82', '1', 'Ghana', 'GHA', 'GH', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('83', '1', 'Gibraltar', 'GIB', 'GI', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('84', '1', 'Greece', 'GRC', 'GR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('85', '1', 'Greenland', 'GRL', 'GL', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('86', '1', 'Grenada', 'GRD', 'GD', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('87', '1', 'Guadeloupe', 'GLP', 'GP', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('88', '1', 'Guam', 'GUM', 'GU', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('89', '1', 'Guatemala', 'GTM', 'GT', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('90', '1', 'Guinea', 'GIN', 'GN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('91', '1', 'Guinea-bissau', 'GNB', 'GW', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('92', '1', 'Guyana', 'GUY', 'GY', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('93', '1', 'Haiti', 'HTI', 'HT', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('94', '1', 'Heard and Mc Donald Islands', 'HMD', 'HM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('95', '1', 'Honduras', 'HND', 'HN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('96', '1', 'Hong Kong', 'HKG', 'HK', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('97', '1', 'Hungary', 'HUN', 'HU', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('98', '1', 'Iceland', 'ISL', 'IS', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('99', '1', 'India', 'IND', 'IN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('100', '1', 'Indonesia', 'IDN', 'ID', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('101', '1', 'Iran (Islamic Republic of)', 'IRN', 'IR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_countries
(`virtuemart_country_id`, `virtuemart_worldzone_id`, `country_name`, `country_3_code`, `country_2_code`, `ordering`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('102', '1', 'Iraq', 'IRQ', 'IQ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('103', '1', 'Ireland', 'IRL', 'IE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('104', '1', 'Israel', 'ISR', 'IL', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('105', '1', 'Italy', 'ITA', 'IT', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('106', '1', 'Jamaica', 'JAM', 'JM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('107', '1', 'Japan', 'JPN', 'JP', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('108', '1', 'Jordan', 'JOR', 'JO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('109', '1', 'Kazakhstan', 'KAZ', 'KZ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('110', '1', 'Kenya', 'KEN', 'KE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('111', '1', 'Kiribati', 'KIR', 'KI', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('112', '1', 'Korea, Democratic People\'s Republic of', 'PRK', 'KP', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('113', '1', 'Korea, Republic of', 'KOR', 'KR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('114', '1', 'Kuwait', 'KWT', 'KW', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('115', '1', 'Kyrgyzstan', 'KGZ', 'KG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('116', '1', 'Lao People\'s Democratic Republic', 'LAO', 'LA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('117', '1', 'Latvia', 'LVA', 'LV', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('118', '1', 'Lebanon', 'LBN', 'LB', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('119', '1', 'Lesotho', 'LSO', 'LS', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('120', '1', 'Liberia', 'LBR', 'LR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('121', '1', 'Libya', 'LBY', 'LY', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('122', '1', 'Liechtenstein', 'LIE', 'LI', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('123', '1', 'Lithuania', 'LTU', 'LT', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('124', '1', 'Luxembourg', 'LUX', 'LU', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('125', '1', 'Macau', 'MAC', 'MO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('126', '1', 'Macedonia, The Former Yugoslav Republic of', 'MKD', 'MK', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('127', '1', 'Madagascar', 'MDG', 'MG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('128', '1', 'Malawi', 'MWI', 'MW', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('129', '1', 'Malaysia', 'MYS', 'MY', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('130', '1', 'Maldives', 'MDV', 'MV', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('131', '1', 'Mali', 'MLI', 'ML', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('132', '1', 'Malta', 'MLT', 'MT', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('133', '1', 'Marshall Islands', 'MHL', 'MH', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('134', '1', 'Martinique', 'MTQ', 'MQ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('135', '1', 'Mauritania', 'MRT', 'MR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('136', '1', 'Mauritius', 'MUS', 'MU', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('137', '1', 'Mayotte', 'MYT', 'YT', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('138', '1', 'Mexico', 'MEX', 'MX', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('139', '1', 'Micronesia, Federated States of', 'FSM', 'FM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('140', '1', 'Moldova, Republic of', 'MDA', 'MD', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('141', '1', 'Monaco', 'MCO', 'MC', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('142', '1', 'Mongolia', 'MNG', 'MN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('143', '1', 'Montserrat', 'MSR', 'MS', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('144', '1', 'Morocco', 'MAR', 'MA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('145', '1', 'Mozambique', 'MOZ', 'MZ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('146', '1', 'Myanmar', 'MMR', 'MM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('147', '1', 'Namibia', 'NAM', 'NA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('148', '1', 'Nauru', 'NRU', 'NR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('149', '1', 'Nepal', 'NPL', 'NP', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('150', '1', 'Netherlands', 'NLD', 'NL', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('151', '1', 'Netherlands Antilles', 'ANT', 'AN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_countries
(`virtuemart_country_id`, `virtuemart_worldzone_id`, `country_name`, `country_3_code`, `country_2_code`, `ordering`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('152', '1', 'New Caledonia', 'NCL', 'NC', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('153', '1', 'New Zealand', 'NZL', 'NZ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('154', '1', 'Nicaragua', 'NIC', 'NI', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('155', '1', 'Niger', 'NER', 'NE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('156', '1', 'Nigeria', 'NGA', 'NG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('157', '1', 'Niue', 'NIU', 'NU', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('158', '1', 'Norfolk Island', 'NFK', 'NF', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('159', '1', 'Northern Mariana Islands', 'MNP', 'MP', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('160', '1', 'Norway', 'NOR', 'NO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('161', '1', 'Oman', 'OMN', 'OM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('162', '1', 'Pakistan', 'PAK', 'PK', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('163', '1', 'Palau', 'PLW', 'PW', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('164', '1', 'Panama', 'PAN', 'PA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('165', '1', 'Papua New Guinea', 'PNG', 'PG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('166', '1', 'Paraguay', 'PRY', 'PY', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('167', '1', 'Peru', 'PER', 'PE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('168', '1', 'Philippines', 'PHL', 'PH', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('169', '1', 'Pitcairn', 'PCN', 'PN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('170', '1', 'Poland', 'POL', 'PL', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('171', '1', 'Portugal', 'PRT', 'PT', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('172', '1', 'Puerto Rico', 'PRI', 'PR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('173', '1', 'Qatar', 'QAT', 'QA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('174', '1', 'Reunion', 'REU', 'RE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('175', '1', 'Romania', 'ROM', 'RO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('176', '1', 'Russian Federation', 'RUS', 'RU', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('177', '1', 'Rwanda', 'RWA', 'RW', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('178', '1', 'Saint Kitts and Nevis', 'KNA', 'KN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('179', '1', 'Saint Lucia', 'LCA', 'LC', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('180', '1', 'Saint Vincent and the Grenadines', 'VCT', 'VC', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('181', '1', 'Samoa', 'WSM', 'WS', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('182', '1', 'San Marino', 'SMR', 'SM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('183', '1', 'Sao Tome and Principe', 'STP', 'ST', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('184', '1', 'Saudi Arabia', 'SAU', 'SA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('185', '1', 'Senegal', 'SEN', 'SN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('186', '1', 'Seychelles', 'SYC', 'SC', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('187', '1', 'Sierra Leone', 'SLE', 'SL', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('188', '1', 'Singapore', 'SGP', 'SG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('189', '1', 'Slovakia', 'SVK', 'SK', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('190', '1', 'Slovenia', 'SVN', 'SI', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('191', '1', 'Solomon Islands', 'SLB', 'SB', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('192', '1', 'Somalia', 'SOM', 'SO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('193', '1', 'South Africa', 'ZAF', 'ZA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('194', '1', 'South Georgia and the South Sandwich Islands', 'SGS', 'GS', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('195', '1', 'Spain', 'ESP', 'ES', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('196', '1', 'Sri Lanka', 'LKA', 'LK', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('197', '1', 'St. Helena', 'SHN', 'SH', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('198', '1', 'St. Pierre and Miquelon', 'SPM', 'PM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('199', '1', 'Sudan', 'SDN', 'SD', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('200', '1', 'Suriname', 'SUR', 'SR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('201', '1', 'Svalbard and Jan Mayen Islands', 'SJM', 'SJ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_countries
(`virtuemart_country_id`, `virtuemart_worldzone_id`, `country_name`, `country_3_code`, `country_2_code`, `ordering`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('202', '1', 'Swaziland', 'SWZ', 'SZ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('203', '1', 'Sweden', 'SWE', 'SE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('204', '1', 'Switzerland', 'CHE', 'CH', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('205', '1', 'Syrian Arab Republic', 'SYR', 'SY', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('206', '1', 'Taiwan', 'TWN', 'TW', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('207', '1', 'Tajikistan', 'TJK', 'TJ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('208', '1', 'Tanzania, United Republic of', 'TZA', 'TZ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('209', '1', 'Thailand', 'THA', 'TH', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('210', '1', 'Togo', 'TGO', 'TG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('211', '1', 'Tokelau', 'TKL', 'TK', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('212', '1', 'Tonga', 'TON', 'TO', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('213', '1', 'Trinidad and Tobago', 'TTO', 'TT', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('214', '1', 'Tunisia', 'TUN', 'TN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('215', '1', 'Turkey', 'TUR', 'TR', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('216', '1', 'Turkmenistan', 'TKM', 'TM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('217', '1', 'Turks and Caicos Islands', 'TCA', 'TC', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('218', '1', 'Tuvalu', 'TUV', 'TV', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('219', '1', 'Uganda', 'UGA', 'UG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('220', '1', 'Ukraine', 'UKR', 'UA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('221', '1', 'United Arab Emirates', 'ARE', 'AE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('222', '1', 'United Kingdom', 'GBR', 'GB', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('223', '1', 'United States', 'USA', 'US', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('224', '1', 'United States Minor Outlying Islands', 'UMI', 'UM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('225', '1', 'Uruguay', 'URY', 'UY', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('226', '1', 'Uzbekistan', 'UZB', 'UZ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('227', '1', 'Vanuatu', 'VUT', 'VU', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('228', '1', 'Vatican City State (Holy See)', 'VAT', 'VA', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('229', '1', 'Venezuela', 'VEN', 'VE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('230', '1', 'Viet Nam', 'VNM', 'VN', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('231', '1', 'Virgin Islands (British)', 'VGB', 'VG', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('232', '1', 'Virgin Islands (U.S.)', 'VIR', 'VI', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('233', '1', 'Wallis and Futuna Islands', 'WLF', 'WF', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('234', '1', 'Western Sahara', 'ESH', 'EH', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('235', '1', 'Yemen', 'YEM', 'YE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('237', '1', 'The Democratic Republic of Congo', 'RCB', 'CD', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('238', '1', 'Zambia', 'ZMB', 'ZM', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('239', '1', 'Zimbabwe', 'ZWE', 'ZW', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('241', '1', 'Jersey', 'JEY', 'JE', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('242', '1', 'St. Barthelemy', 'BLM', 'BL', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('243', '1', 'St. Eustatius', 'BES', 'BQ', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('244', '1', 'Canary Islands', 'XCA', 'IC', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('245', '1', 'Serbia', 'SRB', 'RS', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('246', '1', 'Sint Maarten (French Antilles)', 'MAF', 'MF', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('247', '1', 'Sint Maarten (Netherlands Antilles)', 'SXM', 'SX', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('248', '1', 'Palestinian Territory, occupied', 'PSE', 'PS', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_coupons`;
CREATE TABLE `lal5d_virtuemart_coupons` (
  `virtuemart_coupon_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL,
  `coupon_code` varchar(32) NOT NULL DEFAULT '',
  `percent_or_total` enum('percent','total') NOT NULL DEFAULT 'percent',
  `coupon_type` enum('gift','permanent') NOT NULL DEFAULT 'gift',
  `coupon_value` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `coupon_start_date` datetime DEFAULT NULL,
  `coupon_expiry_date` datetime DEFAULT NULL,
  `coupon_value_valid` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `coupon_used` varchar(200) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_coupon_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `coupon_code` (`coupon_code`),
  KEY `coupon_type` (`coupon_type`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Used to store coupon codes';

INSERT INTO lal5d_virtuemart_coupons
(`virtuemart_coupon_id`, `virtuemart_vendor_id`, `coupon_code`, `percent_or_total`, `coupon_type`, `coupon_value`, `coupon_start_date`, `coupon_expiry_date`, `coupon_value_valid`, `coupon_used`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '1', 'Sample Coupon', 'total', 'permanent', '0.01000', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0.00000', '0', '1', '0000-00-00 00:00:00', '635', '0000-00-00 00:00:00', '635', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_currencies`;
CREATE TABLE `lal5d_virtuemart_currencies` (
  `virtuemart_currency_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `currency_name` varchar(64) DEFAULT NULL,
  `currency_code_2` char(2) DEFAULT NULL,
  `currency_code_3` char(3) DEFAULT NULL,
  `currency_numeric_code` int(4) DEFAULT NULL,
  `currency_exchange_rate` decimal(10,5) DEFAULT NULL,
  `currency_symbol` varchar(8) DEFAULT NULL,
  `currency_decimal_place` varchar(8) DEFAULT NULL,
  `currency_decimal_symbol` varchar(8) DEFAULT NULL,
  `currency_thousands` varchar(8) DEFAULT NULL,
  `currency_positive_style` varchar(64) DEFAULT NULL,
  `currency_negative_style` varchar(64) DEFAULT NULL,
  `ordering` int(1) NOT NULL DEFAULT '0',
  `shared` tinyint(1) NOT NULL DEFAULT '1',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_currency_id`),
  UNIQUE KEY `currency_code_3` (`currency_code_3`),
  KEY `ordering` (`ordering`),
  KEY `currency_name` (`currency_name`),
  KEY `published` (`published`),
  KEY `shared` (`shared`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `currency_numeric_code` (`currency_numeric_code`)
) ENGINE=MyISAM AUTO_INCREMENT=202 DEFAULT CHARSET=utf8 COMMENT='Used to store currencies';

INSERT INTO lal5d_virtuemart_currencies
(`virtuemart_currency_id`, `virtuemart_vendor_id`, `currency_name`, `currency_code_2`, `currency_code_3`, `currency_numeric_code`, `currency_exchange_rate`, `currency_symbol`, `currency_decimal_place`, `currency_decimal_symbol`, `currency_thousands`, `currency_positive_style`, `currency_negative_style`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('2', '1', 'United Arab Emirates dirham', '', 'AED', '784', '0.00000', 'د.إ', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('4', '1', 'Albanian lek', '', 'ALL', '8', '0.00000', 'Lek', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('5', '1', 'Netherlands Antillean gulden', '', 'ANG', '532', '0.00000', 'ƒ', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('7', '1', 'Argentine peso', '', 'ARS', '32', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('9', '1', 'Australian dollar', '', 'AUD', '36', '0.00000', '$', '2', '.', '', '{symbol} {number}', '{sign}{symbol} {number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('10', '1', 'Aruban florin', '', 'AWG', '533', '0.00000', 'ƒ', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('11', '1', 'Barbadian dollar', '', 'BBD', '52', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('12', '1', 'Bangladeshi taka', '', 'BDT', '50', '0.00000', '৳', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('15', '1', 'Bahraini dinar', '', 'BHD', '48', '0.00000', 'ب.د', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('16', '1', 'Burundian franc', '', 'BIF', '108', '0.00000', 'Fr', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('17', '1', 'Bermudian dollar', '', 'BMD', '60', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('18', '1', 'Brunei dollar', '', 'BND', '96', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('19', '1', 'Bolivian boliviano', '', 'BOB', '68', '0.00000', '$b', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('20', '1', 'Brazilian real', '', 'BRL', '986', '0.00000', 'R$', '2', ',', '.', '{symbol} {number}', '{symbol} {sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('21', '1', 'Bahamian dollar', '', 'BSD', '44', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('22', '1', 'Bhutanese ngultrum', '', 'BTN', '64', '0.00000', 'BTN', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('24', '1', 'Botswana pula', '', 'BWP', '72', '0.00000', 'P', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('25', '1', 'Belize dollar', '', 'BZD', '84', '0.00000', 'BZ$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('26', '1', 'Canadian dollar', '', 'CAD', '124', '0.00000', '$', '2', '.', ',', '{symbol}{number}', '{symbol}{sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('27', '1', 'Swiss franc', '', 'CHF', '756', '0.00000', 'CHF', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('28', '1', 'Unidad de Fomento', '', 'CLF', '990', '0.00000', 'CLF', '0', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('29', '1', 'Chilean peso', '', 'CLP', '152', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('30', '1', 'Chinese renminbi yuan', '', 'CNY', '156', '0.00000', '元', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('31', '1', 'Colombian peso', '', 'COP', '170', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('32', '1', 'Costa Rican colón', '', 'CRC', '188', '0.00000', '₡', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('33', '1', 'Czech koruna', '', 'CZK', '203', '0.00000', 'Kč', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('34', '1', 'Cuban peso', '', 'CUP', '192', '0.00000', '₱', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('35', '1', 'Cape Verdean escudo', '', 'CVE', '132', '0.00000', '$', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('40', '1', 'Danish krone', '', 'DKK', '208', '0.00000', 'kr', '2', '.', ',', '{symbol}{number}', '{symbol}{sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('41', '1', 'Dominican peso', '', 'DOP', '214', '0.00000', 'RD$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('42', '1', 'Algerian dinar', '', 'DZD', '12', '0.00000', 'د.ج', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('44', '1', 'Egyptian pound', '', 'EGP', '818', '0.00000', '£', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('46', '1', 'Ethiopian birr', '', 'ETB', '230', '0.00000', 'ETB', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('47', '1', 'Euro', '', 'EUR', '978', '0.00000', '€', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('49', '1', 'Fijian dollar', '', 'FJD', '242', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('50', '1', 'Falkland pound', '', 'FKP', '238', '0.00000', '£', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('52', '1', 'British pound', '', 'GBP', '826', '0.00000', '£', '2', '.', ',', '{symbol}{number}', '{symbol}{sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('54', '1', 'Gibraltar pound', '', 'GIP', '292', '0.00000', '£', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('55', '1', 'Gambian dalasi', '', 'GMD', '270', '0.00000', 'D', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('56', '1', 'Guinean franc', '', 'GNF', '324', '0.00000', 'Fr', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('58', '1', 'Guatemalan quetzal', '', 'GTQ', '320', '0.00000', 'Q', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('60', '1', 'Guyanese dollar', '', 'GYD', '328', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('61', '1', 'Hong Kong dollar', '', 'HKD', '344', '0.00000', '元', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('62', '1', 'Honduran lempira', '', 'HNL', '340', '0.00000', 'L', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('63', '1', 'Haitian gourde', '', 'HTG', '332', '0.00000', 'G', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('64', '1', 'Hungarian forint', '', 'HUF', '348', '0.00000', 'Ft', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('65', '1', 'Indonesian rupiah', '', 'IDR', '360', '0.00000', 'Rp', '0', '', '', '{symbol}{number}', '{symbol}{sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('67', '1', 'Israeli new sheqel', '', 'ILS', '376', '0.00000', '₪', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('68', '1', 'Indian rupee', '', 'INR', '356', '0.00000', '₨', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('69', '1', 'Iraqi dinar', '', 'IQD', '368', '0.00000', 'ع.د', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_currencies
(`virtuemart_currency_id`, `virtuemart_vendor_id`, `currency_name`, `currency_code_2`, `currency_code_3`, `currency_numeric_code`, `currency_exchange_rate`, `currency_symbol`, `currency_decimal_place`, `currency_decimal_symbol`, `currency_thousands`, `currency_positive_style`, `currency_negative_style`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('70', '1', 'Iranian rial', '', 'IRR', '364', '0.00000', '﷼', '2', ',', '', '{number} {symbol}', '{sign}{number}{symb0l}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('73', '1', 'Jamaican dollar', '', 'JMD', '388', '0.00000', 'J$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('74', '1', 'Jordanian dinar', '', 'JOD', '400', '0.00000', 'د.ا', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('75', '1', 'Japanese yen', '', 'JPY', '392', '0.00000', '¥', '0', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('76', '1', 'Kenyan shilling', '', 'KES', '404', '0.00000', 'Sh', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('77', '1', 'Cambodian riel', '', 'KHR', '116', '0.00000', '៛', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('78', '1', 'Comorian franc', '', 'KMF', '174', '0.00000', 'Fr', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('79', '1', 'North Korean won', '', 'KPW', '408', '0.00000', '₩', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('80', '1', 'South Korean won', '', 'KRW', '410', '0.00000', '₩', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('81', '1', 'Kuwaiti dinar', '', 'KWD', '414', '0.00000', 'د.ك', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('82', '1', 'Cayman Islands dollar', '', 'KYD', '136', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('83', '1', 'Lao kip', '', 'LAK', '418', '0.00000', '₭', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('84', '1', 'Lebanese pound', '', 'LBP', '422', '0.00000', '£', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('85', '1', 'Sri Lankan rupee', '', 'LKR', '144', '0.00000', '₨', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('86', '1', 'Liberian dollar', '', 'LRD', '430', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('87', '1', 'Lesotho loti', '', 'LSL', '426', '0.00000', 'L', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('89', '1', 'Libyan dinar', '', 'LYD', '434', '0.00000', 'ل.د', '3', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('90', '1', 'Moroccan dirham', '', 'MAD', '504', '0.00000', 'د.م.', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('92', '1', 'Mongolian tögrög', '', 'MNT', '496', '0.00000', '₮', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('93', '1', 'Macanese pataca', '', 'MOP', '446', '0.00000', 'P', '1', ',', '', '{symbol}{number}', '{symbol}{sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('94', '1', 'Mauritanian ouguiya', '', 'MRO', '478', '0.00000', 'UM', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('96', '1', 'Mauritian rupee', '', 'MUR', '480', '0.00000', '₨', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('97', '1', 'Maldivian rufiyaa', '', 'MVR', '462', '0.00000', 'ރ.', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('98', '1', 'Malawian kwacha', '', 'MWK', '454', '0.00000', 'MK', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('100', '1', 'Malaysian ringgit', '', 'MYR', '458', '0.00000', 'RM', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('102', '1', 'Nigerian naira', '', 'NGN', '566', '0.00000', '₦', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('105', '1', 'Norwegian krone', '', 'NOK', '578', '0.00000', 'kr', '2', ',', '', '{symbol}{number}', '{symbol}{sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('106', '1', 'Nepalese rupee', '', 'NPR', '524', '0.00000', '₨', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('107', '1', 'New Zealand dollar', '', 'NZD', '554', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{symbol}{sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('108', '1', 'Omani rial', '', 'OMR', '512', '0.00000', '﷼', '3', '.', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('109', '1', 'Panamanian balboa', '', 'PAB', '590', '0.00000', 'B/.', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('110', '1', 'Peruvian nuevo sol', '', 'PEN', '604', '0.00000', 'S/.', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('111', '1', 'Papua New Guinean kina', '', 'PGK', '598', '0.00000', 'K', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('112', '1', 'Philippine peso', '', 'PHP', '608', '0.00000', '₱', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('113', '1', 'Pakistani rupee', '', 'PKR', '586', '0.00000', '₨', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('114', '1', 'Polish Złoty', '', 'PLN', '985', '0.00000', 'zł', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('116', '1', 'Paraguayan guaraní', '', 'PYG', '600', '0.00000', '₲', '0', '', '.', '{symbol} {number}', '{symbol} {sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('117', '1', 'Qatari riyal', '', 'QAR', '634', '0.00000', '﷼', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('118', '1', 'Romanian leu', '', 'RON', '946', '0.00000', 'lei', '2', ',', '.', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('119', '1', 'Rwandan franc', '', 'RWF', '646', '0.00000', 'Fr', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('120', '1', 'Saudi riyal', '', 'SAR', '682', '0.00000', '﷼', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('121', '1', 'Solomon Islands dollar', '', 'SBD', '90', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('122', '1', 'Seychellois rupee', '', 'SCR', '690', '0.00000', '₨', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('124', '1', 'Swedish krona', '', 'SEK', '752', '0.00000', 'kr', '2', ',', '.', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('125', '1', 'Singapore dollar', '', 'SGD', '702', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('126', '1', 'Saint Helenian pound', '', 'SHP', '654', '0.00000', '£', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('127', '1', 'Sierra Leonean leone', '', 'SLL', '694', '0.00000', 'Le', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('128', '1', 'Somali shilling', '', 'SOS', '706', '0.00000', 'S', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('130', '1', 'São Tomé and Príncipe dobra', '', 'STD', '678', '0.00000', 'Db', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('131', '1', 'Russian ruble', '', 'RUB', '643', '0.00000', 'руб', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_currencies
(`virtuemart_currency_id`, `virtuemart_vendor_id`, `currency_name`, `currency_code_2`, `currency_code_3`, `currency_numeric_code`, `currency_exchange_rate`, `currency_symbol`, `currency_decimal_place`, `currency_decimal_symbol`, `currency_thousands`, `currency_positive_style`, `currency_negative_style`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('132', '1', 'Salvadoran colón', '', 'SVC', '222', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('133', '1', 'Syrian pound', '', 'SYP', '760', '0.00000', '£', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('134', '1', 'Swazi lilangeni', '', 'SZL', '748', '0.00000', 'L', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('135', '1', 'Thai baht', '', 'THB', '764', '0.00000', '฿', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('136', '1', 'Tunisian dinar', '', 'TND', '788', '0.00000', 'د.ت', '3', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('137', '1', 'Tongan paʻanga', '', 'TOP', '776', '0.00000', 'T$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('139', '1', 'Türk Lirası', '', 'TRY', '949', '0.00000', 'TL', '2', ',', '.', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('140', '1', 'Trinidad and Tobago dollar', '', 'TTD', '780', '0.00000', 'TT$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('141', '1', 'New Taiwan dollar', '', 'TWD', '901', '0.00000', 'NT$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('142', '1', 'Tanzanian shilling', '', 'TZS', '834', '0.00000', 'Sh', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('144', '1', 'United States dollar', '', 'USD', '840', '0.00000', '$', '2', '.', ',', '{symbol}{number}', '{symbol}{sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('147', '1', 'Vietnamese Dong', '', 'VND', '704', '0.00000', '₫', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('148', '1', 'Vanuatu vatu', '', 'VUV', '548', '0.00000', 'Vt', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('149', '1', 'Samoan tala', '', 'WST', '882', '0.00000', 'T', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('151', '1', 'Yemeni rial', '', 'YER', '886', '0.00000', '﷼', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('152', '1', 'Serbian dinar', '', 'RSD', '941', '0.00000', 'Дин.', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('153', '1', 'South African rand', '', 'ZAR', '710', '0.00000', 'R', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('154', '1', 'Zambian kwacha', '', 'ZMK', '894', '0.00000', 'ZK', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('156', '1', 'Zimbabwean dollar', '', 'ZWD', '932', '0.00000', 'Z$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('158', '1', 'Armenian dram', '', 'AMD', '51', '0.00000', 'դր.', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('159', '1', 'Myanmar kyat', '', 'MMK', '104', '0.00000', 'K', '2', ',', '', '{number} {symbol}', '{symbol} {sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('160', '1', 'Croatian kuna', '', 'HRK', '191', '0.00000', 'kn', '2', ',', '.', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('161', '1', 'Eritrean nakfa', '', 'ERN', '232', '0.00000', 'Nfk', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('162', '1', 'Djiboutian franc', '', 'DJF', '262', '0.00000', 'Fr', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('163', '1', 'Icelandic króna', '', 'ISK', '352', '0.00000', 'kr', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('164', '1', 'Kazakhstani tenge', '', 'KZT', '398', '0.00000', 'лв', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('165', '1', 'Kyrgyzstani som', '', 'KGS', '417', '0.00000', 'лв', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('166', '1', 'Latvian lats', '', 'LVL', '428', '0.00000', 'Ls', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('167', '1', 'Lithuanian litas', '', 'LTL', '440', '0.00000', 'Lt', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('168', '1', 'Mexican peso', '', 'MXN', '484', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('169', '1', 'Moldovan leu', '', 'MDL', '498', '0.00000', 'L', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('170', '1', 'Namibian dollar', '', 'NAD', '516', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('171', '1', 'Nicaraguan córdoba', '', 'NIO', '558', '0.00000', 'C$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('172', '1', 'Ugandan shilling', '', 'UGX', '800', '0.00000', 'Sh', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('173', '1', 'Macedonian denar', '', 'MKD', '807', '0.00000', 'ден', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('174', '1', 'Uruguayan peso', '', 'UYU', '858', '0.00000', '$', '0', '', '', '{symbol}number}', '{symbol}{sign}{number}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('175', '1', 'Uzbekistani som', '', 'UZS', '860', '0.00000', 'лв', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('176', '1', 'Azerbaijani manat', '', 'AZN', '934', '0.00000', 'ман', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('177', '1', 'Ghanaian cedi', '', 'GHS', '936', '0.00000', '₵', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('178', '1', 'Venezuelan bolívar', '', 'VEF', '937', '0.00000', 'Bs', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('179', '1', 'Sudanese pound', '', 'SDG', '938', '0.00000', '£', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('180', '1', 'Uruguay Peso', '', 'UYI', '940', '0.00000', 'UYI', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('181', '1', 'Mozambican metical', '', 'MZN', '943', '0.00000', 'MT', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('182', '1', 'WIR Euro', '', 'CHE', '947', '0.00000', '€', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('183', '1', 'WIR Franc', '', 'CHW', '948', '0.00000', 'CHW', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('184', '1', 'Central African CFA franc', '', 'XAF', '950', '0.00000', 'Fr', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('185', '1', 'East Caribbean dollar', '', 'XCD', '951', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('186', '1', 'West African CFA franc', '', 'XOF', '952', '0.00000', 'Fr', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('187', '1', 'CFP franc', '', 'XPF', '953', '0.00000', 'Fr', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('188', '1', 'Surinamese dollar', '', 'SRD', '968', '0.00000', '$', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_currencies
(`virtuemart_currency_id`, `virtuemart_vendor_id`, `currency_name`, `currency_code_2`, `currency_code_3`, `currency_numeric_code`, `currency_exchange_rate`, `currency_symbol`, `currency_decimal_place`, `currency_decimal_symbol`, `currency_thousands`, `currency_positive_style`, `currency_negative_style`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('189', '1', 'Malagasy ariary', '', 'MGA', '969', '0.00000', 'MGA', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('190', '1', 'Unidad de Valor Real', '', 'COU', '970', '0.00000', 'COU', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('191', '1', 'Afghan afghani', '', 'AFN', '971', '0.00000', '؋', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('192', '1', 'Tajikistani somoni', '', 'TJS', '972', '0.00000', 'ЅМ', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('193', '1', 'Angolan kwanza', '', 'AOA', '973', '0.00000', 'Kz', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('194', '1', 'Belarusian ruble', '', 'BYR', '974', '0.00000', 'p.', '0', '', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('195', '1', 'Bulgarian lev', '', 'BGN', '975', '0.00000', 'лв', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('196', '1', 'Congolese franc', '', 'CDF', '976', '0.00000', 'Fr', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('197', '1', 'Bosnia and Herzegovina convert', '', 'BAM', '977', '0.00000', 'KM', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('198', '1', 'Mexican Unid', '', 'MXV', '979', '0.00000', 'MXV', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('199', '1', 'Ukrainian hryvnia', '', 'UAH', '980', '0.00000', '₴', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('200', '1', 'Georgian lari', '', 'GEL', '981', '0.00000', 'ლ', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('201', '1', 'Mvdol', '', 'BOV', '984', '0.00000', 'BOV', '2', ',', '', '{number} {symbol}', '{sign}{number} {symbol}', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_customs`;
CREATE TABLE `lal5d_virtuemart_customs` (
  `virtuemart_custom_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `custom_parent_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `custom_jplugin_id` int(1) NOT NULL DEFAULT '0',
  `custom_element` varchar(50) NOT NULL DEFAULT '',
  `admin_only` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:Display in admin only',
  `custom_title` varchar(255) NOT NULL DEFAULT '' COMMENT 'field title',
  `show_title` tinyint(1) NOT NULL DEFAULT '1',
  `custom_tip` varchar(255) NOT NULL DEFAULT '' COMMENT 'tip',
  `custom_value` varchar(2200) DEFAULT NULL COMMENT 'default value',
  `custom_desc` varchar(255) DEFAULT NULL COMMENT 'description or unit',
  `field_type` varchar(2) NOT NULL DEFAULT '0' COMMENT 'S:string,I:int,P:parent, B:bool,D:date,T:time,H:hidden',
  `is_list` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'list of values',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:hidden',
  `is_cart_attribute` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Add attributes to cart',
  `is_input` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Add input to cart',
  `searchable` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Available as search filter',
  `layout_pos` varchar(24) DEFAULT NULL COMMENT 'Layout Position',
  `custom_params` varchar(17000) NOT NULL DEFAULT '',
  `shared` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'valid for all vendors?',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_custom_id`),
  KEY `custom_parent_id` (`custom_parent_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `custom_element` (`custom_element`),
  KEY `field_type` (`field_type`),
  KEY `is_cart_attribute` (`is_cart_attribute`),
  KEY `is_input` (`is_input`),
  KEY `searchable` (`searchable`),
  KEY `shared` (`shared`),
  KEY `published` (`published`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='custom fields definition';

INSERT INTO lal5d_virtuemart_customs
(`virtuemart_custom_id`, `custom_parent_id`, `virtuemart_vendor_id`, `custom_jplugin_id`, `custom_element`, `admin_only`, `custom_title`, `show_title`, `custom_tip`, `custom_value`, `custom_desc`, `field_type`, `is_list`, `is_hidden`, `is_cart_attribute`, `is_input`, `searchable`, `layout_pos`, `custom_params`, `shared`, `published`, `created_on`, `created_by`, `ordering`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '0', '0', '0', '0', '0', 'COM_VIRTUEMART_RELATED_PRODUCTS', '1', 'COM_VIRTUEMART_RELATED_PRODUCTS_TIP', 'related_products', 'COM_VIRTUEMART_RELATED_PRODUCTS_DESC', 'R', '0', '0', '0', '0', '0', 'related_products', 'wPrice=\"1\"|wImage=\"1\"|wDescr=\"1\"|', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('2', '0', '0', '0', '0', '0', 'COM_VIRTUEMART_RELATED_CATEGORIES', '1', 'COM_VIRTUEMART_RELATED_CATEGORIES_TIP', 'related_categories', 'COM_VIRTUEMART_RELATED_CATEGORIES_DESC', 'Z', '0', '0', '0', '0', '0', 'related_categories', 'wImage=\"1\"|wDescr=\"1\"|', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('9', '0', '1', '0', '', '0', 'Group', '1', 'Group', '', 'set of cart attribute', 'G', '0', '0', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('10', '0', '1', '0', '', '0', 'String', '1', 'Also with tooltip', 'Display characteristic product attributes in a standarized format', '', 'S', '0', '0', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('11', '9', '1', '0', '', '0', 'String, attribute', '1', 'Use values seperated by ; to directly select the value in the backend', '', '', 'S', '0', '0', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('12', '0', '1', '0', '', '0', 'String, list', '1', 'Use values seperated by ; to directly select the value in the backend', 'Cotton;Wool;Flax;Nylon;Polyester', '', 'S', '1', '0', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('13', '0', '1', '0', '', '0', 'String, is input', '1', 'Select a variant', 'Combine Customfields of the same type to create flexible selections (dropdowns, radio lists)', '', 'S', '0', '0', '1', '1', '0', 'addtocart', '', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('14', '0', '1', '0', '', '0', 'String, admin list', '1', 'Select a variant', 'Cotton;Wool;Flax;Nylon;Polyester', '', 'S', '2', '0', '1', '1', '0', 'addtocart', '', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('15', '9', '1', '0', '', '0', 'Media, list', '1', 'Also with tooltip', '20;21;22;23;24', 'extra Image', 'M', '1', '0', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('16', '9', '1', '0', '', '0', 'Editor', '1', 'Show extra conditions', 'Use the texteditor to display extra text at predefined positions', 'Testimonial', 'X', '0', '0', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '3', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('17', '0', '1', '0', '', '0', 'Date', '1', 'Show date', '', 'Next delivery', 'D', '0', '0', '1', '0', '0', 'addtocart', '', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('18', '0', '1', '0', '', '0', 'Time', '1', 'Show time', '', 'Workshop at ', 'T', '0', '0', '0', '0', '0', 'addtocart', '', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('20', '0', '1', '0', '', '0', 'Generic Child Variant', '1', 'Also with tooltip', 'Use admin lists for faster product editing', '', 'A', '0', '0', '1', '0', '0', 'ontop', 'withParent=\"0\"|parentOrderable=\"0\"|wPrice=\"1\"|', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('21', '0', '1', '0', '', '0', 'Multi Variant', '1', 'Also with tooltip', 'Use admin lists for faster product editing', '', 'C', '0', '0', '1', '0', '0', 'addtocart', 'usecanonical=\"1\"|showlabels=\"0\"|sCustomId=\"11\"|selectoptions=\"0\"|clabels=\"0\"|options=\"0\"|', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('22', '0', '1', '0', '', '0', 'Media, paid', '1', 'Also with tooltip', '', 'paid extra Image', 'M', '0', '0', '1', '1', '0', 'addtocart', 'width=\"0\"|height=\"0\"|addEmpty=\"0\"|selectType=\"1\"|', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('23', '0', '1', '0', '', '0', 'String, is input alternative', '1', 'Select a variant', 'Combine Customfields of the same type to create flexible selections (dropdowns, radio lists)', '', 'S', '0', '0', '1', '1', '0', 'addtocart', '', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('24', '0', '1', '0', '', '0', 'Property', '0', '', '', '', 'P', '0', '0', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_invoices`;
CREATE TABLE `lal5d_virtuemart_invoices` (
  `virtuemart_invoice_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `virtuemart_order_id` int(1) unsigned DEFAULT NULL,
  `invoice_number` varchar(64) DEFAULT NULL,
  `order_status` char(2) DEFAULT NULL,
  `xhtml` text,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_invoice_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`,`virtuemart_vendor_id`),
  KEY `virtuemart_order_id` (`virtuemart_order_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='custom fields definition';

DROP TABLE IF EXISTS `lal5d_virtuemart_manufacturer_medias`;
CREATE TABLE `lal5d_virtuemart_manufacturer_medias` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_manufacturer_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_media_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_manufacturer_id` (`virtuemart_manufacturer_id`,`virtuemart_media_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_manufacturer_medias
(`id`, `virtuemart_manufacturer_id`, `virtuemart_media_id`, `ordering`) VALUES 
('1', '3', '5', '1'),
('2', '1', '6', '1'),
('3', '2', '5', '1');

DROP TABLE IF EXISTS `lal5d_virtuemart_manufacturercategories`;
CREATE TABLE `lal5d_virtuemart_manufacturercategories` (
  `virtuemart_manufacturercategories_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_manufacturercategories_id`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Manufacturers are assigned to these categories';

INSERT INTO lal5d_virtuemart_manufacturercategories
(`virtuemart_manufacturercategories_id`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_manufacturercategories_en_gb`;
CREATE TABLE `lal5d_virtuemart_manufacturercategories_en_gb` (
  `virtuemart_manufacturercategories_id` int(1) unsigned NOT NULL,
  `mf_category_name` varchar(180) NOT NULL DEFAULT '',
  `mf_category_desc` varchar(19000) NOT NULL DEFAULT '',
  `slug` varchar(192) NOT NULL DEFAULT '',
  PRIMARY KEY (`virtuemart_manufacturercategories_id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_manufacturercategories_en_gb
(`virtuemart_manufacturercategories_id`, `mf_category_name`, `mf_category_desc`, `slug`) VALUES 
('1', 'default', 'This is the default manufacturer category ', 'default');

DROP TABLE IF EXISTS `lal5d_virtuemart_manufacturers`;
CREATE TABLE `lal5d_virtuemart_manufacturers` (
  `virtuemart_manufacturer_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_manufacturercategories_id` int(1) DEFAULT NULL,
  `metarobot` varchar(400) DEFAULT NULL,
  `metaauthor` varchar(400) DEFAULT NULL,
  `hits` int(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_manufacturer_id`),
  UNIQUE KEY `virtuemart_manufacturercategories_id` (`virtuemart_manufacturer_id`,`virtuemart_manufacturercategories_id`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Manufacturers are those who deliver products';

INSERT INTO lal5d_virtuemart_manufacturers
(`virtuemart_manufacturer_id`, `virtuemart_manufacturercategories_id`, `metarobot`, `metaauthor`, `hits`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '1', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('2', '1', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('3', '1', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_manufacturers_en_gb`;
CREATE TABLE `lal5d_virtuemart_manufacturers_en_gb` (
  `virtuemart_manufacturer_id` int(1) unsigned NOT NULL,
  `mf_name` varchar(180) NOT NULL DEFAULT '',
  `mf_email` varchar(255) NOT NULL DEFAULT '',
  `mf_desc` varchar(19000) NOT NULL DEFAULT '',
  `mf_url` varchar(255) NOT NULL DEFAULT '',
  `metadesc` varchar(400) NOT NULL DEFAULT '',
  `metakey` varchar(400) NOT NULL DEFAULT '',
  `customtitle` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(192) NOT NULL DEFAULT '',
  PRIMARY KEY (`virtuemart_manufacturer_id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_manufacturers_en_gb
(`virtuemart_manufacturer_id`, `mf_name`, `mf_email`, `mf_desc`, `mf_url`, `metadesc`, `metakey`, `customtitle`, `slug`) VALUES 
('1', 'Manufacturer', 'manufacturer@example.org', '<p>An example for a manufacturer</p>', 'http://virtuemart.net', '', '', '', 'manufacturer'),
('2', 'Default', 'example@manufacturer.net', '<p>Default manufacturer</p>', 'http://virtuemart.net', '', '', '', 'default'),
('3', 'Producer', 'info@producer.com', '<p>An example for another manufacturer.</p>', 'http://virtuemart.net', '', '', '', 'producer');

DROP TABLE IF EXISTS `lal5d_virtuemart_medias`;
CREATE TABLE `lal5d_virtuemart_medias` (
  `virtuemart_media_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `file_title` varchar(126) NOT NULL DEFAULT '',
  `file_description` varchar(254) NOT NULL DEFAULT '',
  `file_meta` varchar(254) NOT NULL DEFAULT '',
  `file_class` varchar(64) NOT NULL DEFAULT '',
  `file_mimetype` varchar(64) NOT NULL DEFAULT '',
  `file_type` varchar(32) NOT NULL DEFAULT '',
  `file_url` varchar(900) NOT NULL DEFAULT '',
  `file_url_thumb` varchar(900) NOT NULL DEFAULT '',
  `file_is_product_image` tinyint(1) NOT NULL DEFAULT '0',
  `file_is_downloadable` tinyint(1) NOT NULL DEFAULT '0',
  `file_is_forSale` tinyint(1) NOT NULL DEFAULT '0',
  `file_params` varchar(17000) NOT NULL DEFAULT '',
  `file_lang` varchar(500) NOT NULL DEFAULT '',
  `shared` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_media_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `published` (`published`),
  KEY `file_type` (`file_type`),
  KEY `shared` (`shared`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='Additional Images and Files which are assigned to products';

INSERT INTO lal5d_virtuemart_medias
(`virtuemart_media_id`, `virtuemart_vendor_id`, `file_title`, `file_description`, `file_meta`, `file_class`, `file_mimetype`, `file_type`, `file_url`, `file_url_thumb`, `file_is_product_image`, `file_is_downloadable`, `file_is_forSale`, `file_params`, `file_lang`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '1', 'ShopLogo', 'Used in the invoice', 'virtuemart shop', '', 'image/gif', 'vendor', 'images/stories/virtuemart/vendor/vendor.gif', 'images/stories/virtuemart/vendor/resized/vendor_0x90.gif', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('5', '1', 'Manufacturer', '', '', '', 'image/jpeg', 'manufacturer', 'images/stories/virtuemart/manufacturer/manufacturer.jpg', '', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('6', '1', 'Producer', '', '', '', 'image/jpeg', 'manufacturer', 'images/stories/virtuemart/manufacturer/producer.jpg', '', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('10', '1', 'student hat', 'Products in this category showing tips and tricks', 'student_hat_16', '', 'image/jpeg', 'category', 'images/stories/virtuemart/category/student_hat_16.jpg', '', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('11', '1', 'T-Shirts', 'Warp5 T-Shirts', 'virtuemart warp5', '', 'image/png', 'product', 'images/stories/virtuemart/product/tshirt5.png', '', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('12', '1', 'Hats', 'Hat #1', 'virtuemart #1', '', 'image/png', 'product', 'images/stories/virtuemart/product/hat1.png', '', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('13', '1', 'Skirts', 'Skirt #1', 'virtuemart #1', '', 'image/png', 'product', 'images/stories/virtuemart/product/skirt1.png', '', '0', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('20', '1', 'VM Cart Logo', 'The Famous VirtueMart Cart Logo', 'virtuemart cart logo', '', 'image/jpeg', 'product', 'images/stories/virtuemart/product/cart_logo.jpg', '', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('21', '1', 'Hat 1', 'VirtueMart Sample', 'virtuemart sample', '', 'image/png', 'product', 'images/stories/virtuemart/product/hat1.png', '', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('22', '1', 'Hat 2', 'VirtueMart Sample', 'virtuemart sample', '', 'image/png', 'product', 'images/stories/virtuemart/product/hat2.png', '', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('23', '1', 'Hat 3', 'VirtueMart Sample', 'virtuemart sample', '', 'image/png', 'product', 'images/stories/virtuemart/product/hat3.png', '', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('24', '1', 'shirt 1', 'VirtueMart Sample', 'virtuemart sample', '', 'image/png', 'product', 'images/stories/virtuemart/product/shirt1.png', '', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('25', '1', 'shirt 2', 'VirtueMart Sample', 'virtuemart sample', '', 'image/png', 'product', 'images/stories/virtuemart/product/shirt2.png', '', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('26', '1', 'Coat', '', '', '', 'image/png', 'product', 'images/stories/virtuemart/product/coat1.png', '', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('27', '1', 'Skirt 1', 'VirtueMart Sample', 'virtuemart sample', '', 'image/png', 'product', 'images/stories/virtuemart/product/skirt1.png', '', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('28', '1', 'Skirt 2', 'VirtueMart Sample', 'virtuemart sample', '', 'image/png', 'product', 'images/stories/virtuemart/product/skirt2.png', '', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('29', '1', 'T-Shirt EightBall', 'VirtueMart Sample', 'virtuemart sample', '', 'image/png', 'product', 'images/stories/virtuemart/product/tshirt8.png', '', '1', '0', '0', '', '', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_migration_oldtonew_ids`;
CREATE TABLE `lal5d_virtuemart_migration_oldtonew_ids` (
  `id` smallint(1) unsigned NOT NULL AUTO_INCREMENT,
  `cats` longblob,
  `catsxref` blob,
  `manus` longblob,
  `mfcats` blob,
  `shoppergroups` longblob,
  `products` longblob,
  `products_start` int(1) DEFAULT NULL,
  `orderstates` blob,
  `orders` longblob,
  `attributes` longblob,
  `relatedproducts` longblob,
  `orders_start` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='xref table for vm1 ids to vm2 ids';

DROP TABLE IF EXISTS `lal5d_virtuemart_modules`;
CREATE TABLE `lal5d_virtuemart_modules` (
  `module_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `module_name` char(255) DEFAULT NULL,
  `module_description` varchar(21000) DEFAULT NULL,
  `module_perms` char(255) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `is_admin` enum('0','1') NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`module_id`),
  KEY `module_name` (`module_name`),
  KEY `ordering` (`ordering`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='VirtueMart Core Modules, not: Joomla modules';

INSERT INTO lal5d_virtuemart_modules
(`module_id`, `module_name`, `module_description`, `module_perms`, `published`, `is_admin`, `ordering`) VALUES 
('1', 'product', 'Here you can administer your online catalog of products.  Categories , Products (view=product), Attributes, Product Types, Product Files (view=media), Inventory, Calculation Rules, Customer Reviews  ', 'storeadmin,admin', '1', '', '1'),
('2', 'order', 'View Order and Update Order Status:    Orders , Coupons , Revenue Report ,Shopper , Shopper Groups ', 'admin,storeadmin', '1', '', '2'),
('3', 'manufacturer', 'Manage the manufacturers of products in your store.', 'storeadmin,admin', '1', '', '3'),
('4', 'store', 'Store Configuration: Store Information, Payment Methods , Shipment, Shipment Rates', 'storeadmin,admin', '1', '', '4'),
('5', 'configuration', 'Configuration: shop configuration , currencies (view=currency), Credit Card List, Countries, userfields, order status  ', 'admin,storeadmin', '1', '0', '5'),
('6', 'msgs', 'This module is unprotected an used for displaying system messages to users.  We need to have an area that does not require authorization when things go wrong.', 'none', '0', '', '99'),
('7', 'shop', 'This is the Washupito store module.  This is the demo store included with the VirtueMart distribution.', 'none', '1', '', '99'),
('8', 'store', 'Store Configuration: Store Information, Payment Methods , Shipment, Shipment Rates', 'storeadmin,admin', '1', '', '4'),
('9', 'account', 'This module allows shoppers to update their account information and view previously placed orders.', 'shopper,storeadmin,admin,demo', '1', '', '99'),
('10', 'checkout', '', 'none', '0', '', '99'),
('11', 'tools', 'Tools', 'admin', '1', '0', '8'),
('13', 'zone', 'This is the zone-shipment module. Here you can manage your shipment costs according to Zones.', 'admin,storeadmin', '0', '', '11');

DROP TABLE IF EXISTS `lal5d_virtuemart_order_calc_rules`;
CREATE TABLE `lal5d_virtuemart_order_calc_rules` (
  `virtuemart_order_calc_rule_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_calc_id` int(1) unsigned DEFAULT NULL,
  `virtuemart_order_id` int(1) unsigned DEFAULT NULL,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `virtuemart_order_item_id` int(1) DEFAULT NULL,
  `calc_rule_name` varchar(64) NOT NULL DEFAULT '' COMMENT 'Name of the rule',
  `calc_kind` varchar(16) NOT NULL DEFAULT '' COMMENT 'Discount/Tax/Margin/Commission',
  `calc_mathop` varchar(16) NOT NULL DEFAULT '' COMMENT 'Discount/Tax/Margin/Commission',
  `calc_amount` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `calc_result` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `calc_value` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `calc_currency` int(1) DEFAULT NULL,
  `calc_params` varchar(18000) NOT NULL DEFAULT '',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_order_calc_rule_id`),
  KEY `virtuemart_calc_id` (`virtuemart_calc_id`),
  KEY `virtuemart_order_id` (`virtuemart_order_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores all calculation rules which are part of an order';

DROP TABLE IF EXISTS `lal5d_virtuemart_order_histories`;
CREATE TABLE `lal5d_virtuemart_order_histories` (
  `virtuemart_order_history_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_order_id` int(1) unsigned NOT NULL DEFAULT '0',
  `order_status_code` char(1) NOT NULL DEFAULT '0',
  `customer_notified` tinyint(1) NOT NULL DEFAULT '0',
  `comments` varchar(21000) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_order_history_id`),
  KEY `virtuemart_order_id` (`virtuemart_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores all actions and changes that occur to an order';

DROP TABLE IF EXISTS `lal5d_virtuemart_order_items`;
CREATE TABLE `lal5d_virtuemart_order_items` (
  `virtuemart_order_item_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_order_id` int(1) unsigned DEFAULT NULL,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `virtuemart_product_id` int(1) DEFAULT NULL,
  `order_item_sku` varchar(255) NOT NULL DEFAULT '',
  `order_item_name` varchar(4096) NOT NULL DEFAULT '',
  `product_quantity` int(1) DEFAULT NULL,
  `product_item_price` decimal(15,5) DEFAULT NULL,
  `product_priceWithoutTax` decimal(15,5) DEFAULT NULL,
  `product_tax` decimal(15,5) DEFAULT NULL,
  `product_basePriceWithTax` decimal(15,5) DEFAULT NULL,
  `product_discountedPriceWithoutTax` decimal(15,5) DEFAULT NULL,
  `product_final_price` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `product_subtotal_discount` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `product_subtotal_with_tax` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `order_item_currency` int(1) DEFAULT NULL,
  `order_status` char(1) DEFAULT NULL,
  `product_attribute` mediumtext,
  `delivery_date` varchar(200) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_order_item_id`),
  KEY `virtuemart_product_id` (`virtuemart_product_id`),
  KEY `virtuemart_order_id` (`virtuemart_order_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `order_status` (`order_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores all items (products) which are part of an order';

DROP TABLE IF EXISTS `lal5d_virtuemart_order_userinfos`;
CREATE TABLE `lal5d_virtuemart_order_userinfos` (
  `virtuemart_order_userinfo_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_order_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_user_id` int(1) unsigned NOT NULL DEFAULT '0',
  `address_type` char(2) DEFAULT NULL,
  `address_type_name` varchar(32) DEFAULT NULL,
  `company` varchar(64) DEFAULT NULL,
  `title` varchar(32) DEFAULT NULL,
  `last_name` varchar(96) DEFAULT NULL,
  `first_name` varchar(96) DEFAULT NULL,
  `middle_name` varchar(96) DEFAULT NULL,
  `phone_1` varchar(32) DEFAULT NULL,
  `phone_2` varchar(32) DEFAULT NULL,
  `fax` varchar(32) DEFAULT NULL,
  `address_1` varchar(96) NOT NULL DEFAULT '',
  `address_2` varchar(64) DEFAULT NULL,
  `city` varchar(96) NOT NULL DEFAULT '',
  `virtuemart_state_id` smallint(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_country_id` smallint(1) unsigned NOT NULL DEFAULT '0',
  `zip` varchar(32) NOT NULL DEFAULT '',
  `email` varchar(128) DEFAULT NULL,
  `agreed` tinyint(1) NOT NULL DEFAULT '0',
  `tos` tinyint(1) NOT NULL DEFAULT '0',
  `customer_note` varchar(5000) NOT NULL DEFAULT '',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_order_userinfo_id`),
  KEY `virtuemart_order_id` (`virtuemart_order_id`),
  KEY `virtuemart_user_id` (`virtuemart_user_id`,`address_type`),
  KEY `address_type` (`address_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores the BillTo and ShipTo Information at order time';

DROP TABLE IF EXISTS `lal5d_virtuemart_orders`;
CREATE TABLE `lal5d_virtuemart_orders` (
  `virtuemart_order_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_user_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '0',
  `order_number` varchar(64) DEFAULT NULL,
  `customer_number` varchar(32) DEFAULT NULL,
  `order_pass` varchar(34) DEFAULT NULL,
  `order_create_invoice_pass` varchar(32) DEFAULT NULL,
  `order_total` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `order_salesPrice` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `order_billTaxAmount` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `order_billTax` varchar(400) DEFAULT NULL,
  `order_billDiscountAmount` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `order_discountAmount` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `order_subtotal` decimal(15,5) DEFAULT NULL,
  `order_tax` decimal(10,5) DEFAULT NULL,
  `order_shipment` decimal(10,5) DEFAULT NULL,
  `order_shipment_tax` decimal(10,5) DEFAULT NULL,
  `order_payment` decimal(10,2) DEFAULT NULL,
  `order_payment_tax` decimal(10,5) DEFAULT NULL,
  `coupon_discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `coupon_code` varchar(32) DEFAULT NULL,
  `order_discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `order_currency` smallint(1) DEFAULT NULL,
  `order_status` char(1) DEFAULT NULL,
  `user_currency_id` smallint(1) DEFAULT NULL,
  `user_currency_rate` decimal(10,5) NOT NULL DEFAULT '1.00000',
  `payment_currency_id` smallint(1) DEFAULT NULL,
  `payment_currency_rate` decimal(10,5) NOT NULL DEFAULT '1.00000',
  `virtuemart_paymentmethod_id` int(1) unsigned DEFAULT NULL,
  `virtuemart_shipmentmethod_id` int(1) unsigned DEFAULT NULL,
  `delivery_date` varchar(200) DEFAULT NULL,
  `order_language` varchar(7) DEFAULT NULL,
  `ip_address` char(15) NOT NULL DEFAULT '',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_order_id`),
  KEY `virtuemart_user_id` (`virtuemart_user_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `order_number` (`order_number`),
  KEY `virtuemart_paymentmethod_id` (`virtuemart_paymentmethod_id`),
  KEY `virtuemart_shipmentmethod_id` (`virtuemart_shipmentmethod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Used to store all orders';

DROP TABLE IF EXISTS `lal5d_virtuemart_orderstates`;
CREATE TABLE `lal5d_virtuemart_orderstates` (
  `virtuemart_orderstate_id` tinyint(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `order_status_code` char(1) NOT NULL DEFAULT '',
  `order_status_name` varchar(64) DEFAULT NULL,
  `order_status_description` varchar(20000) DEFAULT NULL,
  `order_stock_handle` char(1) NOT NULL DEFAULT 'A',
  `ordering` int(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_orderstate_id`),
  KEY `ordering` (`ordering`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='All available order statuses';

INSERT INTO lal5d_virtuemart_orderstates
(`virtuemart_orderstate_id`, `virtuemart_vendor_id`, `order_status_code`, `order_status_name`, `order_status_description`, `order_stock_handle`, `ordering`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '1', 'P', 'COM_VIRTUEMART_ORDER_STATUS_PENDING', '', 'R', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('2', '1', 'U', 'COM_VIRTUEMART_ORDER_STATUS_CONFIRMED_BY_SHOPPER', '', 'R', '2', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('3', '1', 'C', 'COM_VIRTUEMART_ORDER_STATUS_CONFIRMED', '', 'R', '3', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('4', '1', 'X', 'COM_VIRTUEMART_ORDER_STATUS_CANCELLED', '', 'A', '4', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('5', '1', 'R', 'COM_VIRTUEMART_ORDER_STATUS_REFUNDED', '', 'A', '5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('6', '1', 'S', 'COM_VIRTUEMART_ORDER_STATUS_SHIPPED', '', 'O', '6', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('7', '1', 'F', 'COM_VIRTUEMART_ORDER_STATUS_COMPLETED', '', 'R', '7', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('8', '1', 'D', 'COM_VIRTUEMART_ORDER_STATUS_DENIED', '', 'A', '8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_payment_plg_standard`;
CREATE TABLE `lal5d_virtuemart_payment_plg_standard` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_order_id` int(1) unsigned DEFAULT NULL,
  `order_number` char(64) DEFAULT NULL,
  `virtuemart_paymentmethod_id` mediumint(1) unsigned DEFAULT NULL,
  `payment_name` varchar(5000) DEFAULT NULL,
  `payment_order_total` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `payment_currency` char(3) DEFAULT NULL,
  `email_currency` char(3) DEFAULT NULL,
  `cost_per_transaction` decimal(10,2) DEFAULT NULL,
  `cost_min_transaction` decimal(10,2) DEFAULT NULL,
  `cost_percent_total` decimal(10,2) DEFAULT NULL,
  `tax_id` smallint(1) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Payment Standard Table';

DROP TABLE IF EXISTS `lal5d_virtuemart_paymentmethod_shoppergroups`;
CREATE TABLE `lal5d_virtuemart_paymentmethod_shoppergroups` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_paymentmethod_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_shoppergroup_id` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_paymentmethod_id` (`virtuemart_paymentmethod_id`,`virtuemart_shoppergroup_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='xref table for paymentmethods to shoppergroup';

DROP TABLE IF EXISTS `lal5d_virtuemart_paymentmethods`;
CREATE TABLE `lal5d_virtuemart_paymentmethods` (
  `virtuemart_paymentmethod_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `payment_jplugin_id` int(1) NOT NULL DEFAULT '0',
  `payment_element` varchar(50) NOT NULL DEFAULT '',
  `payment_params` varchar(19000) NOT NULL DEFAULT '',
  `currency_id` int(1) unsigned DEFAULT NULL,
  `shared` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'valide for all vendors?',
  `ordering` int(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_paymentmethod_id`),
  KEY `payment_jplugin_id` (`payment_jplugin_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `payment_element` (`payment_element`,`virtuemart_vendor_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='The payment methods of your store';

INSERT INTO lal5d_virtuemart_paymentmethods
(`virtuemart_paymentmethod_id`, `virtuemart_vendor_id`, `payment_jplugin_id`, `payment_element`, `payment_params`, `currency_id`, `shared`, `ordering`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '1', '10002', 'standard', 'payment_logos=\"\"|countries=\"\"|payment_currency=\"0\"|status_pending=\"U\"|send_invoice_on_order_null=\"1\"|min_amount=\"\"|max_amount=\"\"|cost_per_transaction=\"0.10\"|cost_percent_total=\"1.5\"|tax_id=\"0\"|payment_info=\"\"|', '', '0', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_paymentmethods_en_gb`;
CREATE TABLE `lal5d_virtuemart_paymentmethods_en_gb` (
  `virtuemart_paymentmethod_id` int(1) unsigned NOT NULL,
  `payment_name` varchar(180) NOT NULL DEFAULT '',
  `payment_desc` varchar(19000) NOT NULL DEFAULT '',
  `slug` varchar(192) NOT NULL DEFAULT '',
  PRIMARY KEY (`virtuemart_paymentmethod_id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_paymentmethods_en_gb
(`virtuemart_paymentmethod_id`, `payment_name`, `payment_desc`, `slug`) VALUES 
('1', 'Cash on delivery', '', 'Cash-on-delivery');

DROP TABLE IF EXISTS `lal5d_virtuemart_product_categories`;
CREATE TABLE `lal5d_virtuemart_product_categories` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_product_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_category_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_product_id` (`virtuemart_product_id`,`virtuemart_category_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COMMENT='Maps Products to Categories';

INSERT INTO lal5d_virtuemart_product_categories
(`id`, `virtuemart_product_id`, `virtuemart_category_id`, `ordering`) VALUES 
('1', '164', '12', '0'),
('2', '165', '12', '1'),
('3', '166', '12', '2'),
('4', '167', '12', '3'),
('5', '168', '12', '4'),
('6', '169', '12', '5'),
('7', '200', '2', '0'),
('8', '201', '2', '1'),
('9', '202', '2', '2'),
('10', '203', '2', '3'),
('11', '204', '2', '4'),
('12', '205', '2', '5'),
('13', '206', '2', '6'),
('14', '207', '2', '7'),
('15', '170', '11', '0'),
('16', '171', '11', '1'),
('17', '172', '11', '3'),
('18', '176', '11', '10'),
('19', '156', '9', '0'),
('20', '161', '4', '0'),
('21', '156', '7', '0'),
('22', '160', '4', '0'),
('23', '158', '9', '0'),
('24', '155', '8', '0'),
('25', '158', '7', '0'),
('26', '155', '9', '0'),
('27', '155', '7', '0'),
('28', '154', '7', '0'),
('29', '157', '7', '0'),
('30', '157', '9', '0'),
('31', '157', '8', '0'),
('32', '154', '8', '0'),
('33', '156', '8', '0'),
('34', '162', '4', '0'),
('35', '300', '11', '16'),
('36', '1000', '3', '3'),
('37', '1001', '3', '6'),
('38', '1002', '3', '15'),
('39', '1003', '3', '30'),
('40', '1004', '3', '17'),
('41', '1005', '3', '16'),
('42', '1006', '3', '22'),
('43', '1007', '3', '23'),
('44', '1008', '3', '12'),
('45', '1009', '3', '18'),
('46', '1010', '3', '33'),
('47', '1100', '3', '8'),
('48', '1101', '3', '2'),
('49', '1102', '3', '7'),
('50', '1103', '3', '5');

INSERT INTO lal5d_virtuemart_product_categories
(`id`, `virtuemart_product_id`, `virtuemart_category_id`, `ordering`) VALUES 
('51', '1104', '3', '4'),
('52', '1105', '3', '1'),
('53', '1106', '3', '32'),
('54', '1107', '3', '25'),
('55', '1108', '3', '24'),
('56', '1109', '3', '27'),
('57', '1110', '3', '28'),
('58', '1200', '3', '20'),
('59', '1201', '3', '19'),
('60', '1202', '3', '14'),
('61', '1203', '3', '13'),
('62', '1204', '3', '11'),
('63', '1205', '3', '26'),
('64', '1206', '3', '9'),
('65', '1207', '3', '31'),
('66', '1208', '3', '10'),
('67', '1209', '3', '29'),
('68', '1210', '3', '12');

DROP TABLE IF EXISTS `lal5d_virtuemart_product_customfields`;
CREATE TABLE `lal5d_virtuemart_product_customfields` (
  `virtuemart_customfield_id` int(1) unsigned NOT NULL AUTO_INCREMENT COMMENT 'field id',
  `virtuemart_product_id` int(1) NOT NULL DEFAULT '0',
  `virtuemart_custom_id` int(1) NOT NULL DEFAULT '1' COMMENT 'custom group id',
  `customfield_value` varchar(2500) DEFAULT NULL COMMENT 'field value',
  `customfield_price` decimal(15,6) DEFAULT NULL COMMENT 'price',
  `disabler` int(1) unsigned NOT NULL DEFAULT '0',
  `override` int(1) unsigned NOT NULL DEFAULT '0',
  `customfield_params` varchar(17000) NOT NULL DEFAULT '' COMMENT 'Param for Plugins',
  `product_sku` varchar(64) DEFAULT NULL,
  `product_gtin` varchar(64) DEFAULT NULL,
  `product_mpn` varchar(64) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) unsigned NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) unsigned NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_customfield_id`),
  KEY `virtuemart_product_id` (`virtuemart_product_id`),
  KEY `virtuemart_custom_id` (`virtuemart_custom_id`),
  KEY `published` (`published`),
  KEY `ordering` (`virtuemart_product_id`,`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=485 DEFAULT CHARSET=utf8 COMMENT='custom fields';

INSERT INTO lal5d_virtuemart_product_customfields
(`virtuemart_customfield_id`, `virtuemart_product_id`, `virtuemart_custom_id`, `customfield_value`, `customfield_price`, `disabler`, `override`, `customfield_params`, `product_sku`, `product_gtin`, `product_mpn`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`, `ordering`) VALUES 
('1', '166', '16', '<p><strong>Editor field content.</strong> We have additional room here for more information. Use of <em>WYSIWYG</em> editor customfield here.</p>', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('2', '166', '12', 'Polyester', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('3', '166', '10', 'My string content here.', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('4', '167', '15', '11', '', '0', '0', 'width=\"0\"|height=\"0\"|', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('5', '167', '15', '10', '', '0', '0', 'width=\"0\"|height=\"0\"|', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('6', '167', '16', '1', '', '0', '0', 'width=\"0\"|height=\"0\"|', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('200', '204', '10', 'Customfield string 1: Child content', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('201', '204', '10', 'Customfield string 2: Child content', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('202', '204', '16', '<p>Advanced PATTERN content <br />&gt;&gt; This customfields are assigned in parent product.</p>', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('203', '207', '16', '<p>Advanced PATTERN content <br />&gt;&gt; This customfields are assigned in parent product.<br /><br />Enable overrides in plugin customfields and set your new content.<br />You can add customfields additional to inherited.</p>', '', '0', '202', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('204', '207', '10', 'Override for string 2', '', '0', '201', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('205', '207', '10', 'Disables string 1 of parent', '', '200', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('206', '207', '15', '21', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('276', '207', '13', 'A Variant', '0.000010', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '10'),
('277', '207', '13', 'B Variant', '5.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '11'),
('278', '207', '13', 'C Variant', '10.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '12'),
('279', '207', '13', 'D Variant', '-5.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '13'),
('280', '171', '10', 'My customfield string content', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('281', '171', '12', 'My customfield cart string content', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('282', '171', '69', '6', '1.000000', '0', '0', 'width=\"0\"|height=\"0\"|', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('283', '171', '69', '7', '3.000000', '0', '0', 'width=\"0\"|height=\"0\"|', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '5'),
('284', '171', '69', '8', '2.000000', '0', '0', 'width=\"0\"|height=\"0\"|', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '4'),
('285', '171', '14', 'Cotton', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('286', '171', '14', 'Wool', '4.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('287', '171', '14', 'Flax', '7.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('288', '171', '13', 'Advanced', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('289', '171', '13', 'Expert', '4.900000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('290', '172', '20', 'product_sku', '', '0', '0', 'withParent=\"0\"|parentOrderable=\"0\"|wPrice=0|', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('291', '176', '22', '21', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('292', '176', '22', '22', '5.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('400', '153', '11', 'Stiched genuine VM logo, color: black', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('401', '153', '13', 'Basic', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('402', '153', '13', 'Handmade', '100.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('403', '153', '14', 'Cotton', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('404', '153', '14', 'Wool', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '4'),
('405', '153', '14', 'Polyester', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '5'),
('406', '153', '16', '<p>Wear pattern data field using customfield editor.</p>', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '6'),
('407', '154', '11', 'Stiched genuine VM logo, color: black', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('408', '154', '10', 'Machine-washable', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('412', '154', '20', 'product_sku', '', '0', '0', 'withParent=\"0\"|parentOrderable=\"0\"|wPrice=0|', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('413', '154', '13', 'Silver Buttons', '0.000010', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('414', '154', '13', 'Gold Buttons', '10.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('415', '155', '20', 'product_sku', '', '0', '0', 'withParent=\"0\"|parentOrderable=\"0\"|wPrice=0|', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('416', '155', '11', 'Stiched genuine VM logo, color: black', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('417', '155', '12', 'Flax', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('418', '155', '10', 'Machine-washable', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('425', '156', '14', 'Wool', '7.990000', '0', '404', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '5'),
('426', '156', '14', 'Flax', '12.990000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '6'),
('427', '156', '14', 'Nylon', '0.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('428', '156', '14', 'Polyester', '3.990000', '0', '405', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '4');

INSERT INTO lal5d_virtuemart_product_customfields
(`virtuemart_customfield_id`, `virtuemart_product_id`, `virtuemart_custom_id`, `customfield_value`, `customfield_price`, `disabler`, `override`, `customfield_params`, `product_sku`, `product_gtin`, `product_mpn`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`, `ordering`) VALUES 
('429', '156', '16', '<p>Wear pattern data field using customfield editor override for Zipper.</p>', '', '0', '406', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '7'),
('430', '157', '13', 'Handmade', '207.500000', '0', '402', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('431', '157', '14', 'Nylon', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('432', '157', '14', 'Polyester', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('433', '157', '16', '<p>Wear pattern data field using customfield editor, override for H2O jacket</p>', '', '0', '404', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '4'),
('434', '158', '13', 'Handmade', '140.833330', '0', '402', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('435', '158', '14', 'Cotton', '0.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('436', '158', '14', 'Wool', '35.833330', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('437', '158', '14', 'Flax', '15.833330', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('438', '158', '16', '<p>Wear pattern data field using customfield editor, Skirt \"Knock-Rock.\"</p>', '', '0', '404', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '4'),
('439', '159', '10', '', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('440', '159', '16', '<p>Example text for customfield editor position default.</p>', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('441', '159', '11', '', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('442', '160', '11', 'Color: yellow, Logo: monochrome', '', '0', '441', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('443', '160', '10', 'Stiched VM logo', '', '0', '439', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('444', '160', '13', 'Bulk', '-2.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('445', '160', '13', 'Retail', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('446', '161', '11', 'Color: red, Logo: monochrome', '', '0', '441', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('447', '161', '13', 'Size: S', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('448', '161', '13', 'Size: M', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('449', '161', '13', 'Size: L', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('450', '161', '13', 'Size: Uni', '2.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '4'),
('451', '161', '10', 'Stiched VM logo', '', '0', '439', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('452', '162', '11', 'Color: brown, Logo: monochrome', '', '0', '441', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('453', '162', '10', 'Stiched VM logo', '', '0', '439', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('454', '162', '14', 'Standard', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('455', '162', '14', 'Waxed', '10.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('456', '162', '13', 'Size: M', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('457', '162', '13', 'Size: L', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '1'),
('458', '162', '13', 'Size: XL', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('473', '195', '14', 'Cotton', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('474', '195', '14', 'Wool', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('475', '195', '14', 'Flax', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('477', '195', '13', 'Silver Buttons', '0.000010', '0', '413', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('478', '195', '13', 'Gold Buttons', '10.000000', '0', '414', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('479', '196', '14', 'Cotton', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('480', '196', '14', 'Wool', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('481', '196', '14', 'Flax', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('483', '196', '13', 'Silver Buttons', '0.000010', '0', '413', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('484', '196', '13', 'Gold Buttons', '14.000000', '0', '414', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('459', '197', '23', '5D', '0.000010', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('460', '197', '23', '10D', '5.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('461', '197', '13', 'Industry made', '0.000010', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '5'),
('462', '197', '13', 'Hand made', '20.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '6'),
('463', '198', '23', '20D', '5.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2'),
('464', '198', '23', '30D', '10.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('465', '198', '23', '40D', '15.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '4'),
('466', '198', '13', 'Industry made', '0.000010', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '5'),
('467', '198', '13', 'Hand made', '20.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '6'),
('468', '199', '23', '30D', '10.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '2');

INSERT INTO lal5d_virtuemart_product_customfields
(`virtuemart_customfield_id`, `virtuemart_product_id`, `virtuemart_custom_id`, `customfield_value`, `customfield_price`, `disabler`, `override`, `customfield_params`, `product_sku`, `product_gtin`, `product_mpn`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`, `ordering`) VALUES 
('469', '199', '23', '40D', '20.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '3'),
('470', '199', '23', '50D', '30.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '4'),
('471', '199', '13', 'Industry made', '0.000010', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '5'),
('472', '199', '13', 'Hand made', '25.000000', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '6'),
('300', '300', '21', '', '', '0', '0', 'usecanonical=0|showlabels=0|sCustomId=10|selectoptions=[{\"voption\":\"product_width\",\"clabel\":\"1\",\"values\":\"46.0000\\r\\n51.0000\\r\\n56.0000\\r\\n61.0000\"},{\"voption\":\"product_length\",\"clabel\":\"1\",\"values\":\"68.5000\\r\\n71.0000\\r\\n73.5000\\r\\n76.0000\"},{\"voption\":\"clabels\",\"clabel\":\"Weave\",\"values\":\"Advanced\\r\\nPremium\"}]|clabels=0|options={\"300\":[\"\",\"\",\"0\"],\"301\":[\"46.0000\",\"68.5000\",\"Advanced\"],\"302\":[\"46.0000\",\"68.5000\",\"Premium\"],\"303\":[\"46.0000\",\"71.0000\",\"Advanced\"],\"304\":[\"46.0000\",\"71.0000\",\"Premium\"],\"305\":[\"51.0000\",\"68.5000\",\"Advanced\"],\"306\":[\"51.0000\",\"71.0000\",\"Advanced\"],\"307\":[\"51.0000\",\"71.0000\",\"Premium\"],\"308\":[\"51.0000\",\"73.5000\",\"Advanced\"],\"309\":[\"51.0000\",\"73.5000\",\"Premium\"],\"310\":[\"56.0000\",\"73.5000\",\"Advanced\"],\"311\":[\"56.0000\",\"73.5000\",\"Premium\"],\"312\":[\"56.0000\",\"76.0000\",\"Advanced\"],\"313\":[\"56.0000\",\"76.0000\",\"Premium\"],\"314\":[\"61.0000\",\"76.0000\",\"Advanced\"],\"315\":[\"61.0000\",\"76.0000\",\"Premium\"]}|', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('301', '301', '10', 'Advanced', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('302', '302', '10', 'Premium', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('303', '303', '10', 'Advanced', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('304', '304', '10', 'Premium', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('305', '305', '10', 'Advanced', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('306', '306', '10', 'Advanced', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('307', '307', '10', 'Premium', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('308', '308', '10', 'Advanced', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('309', '309', '10', 'Premium', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('310', '310', '10', 'Advanced', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('311', '311', '10', 'Premium', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('312', '312', '10', 'Advanced', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('313', '313', '10', 'Premium', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('314', '314', '10', 'Advanced', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0'),
('315', '315', '10', 'Premium', '', '0', '0', '', '', '', '', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_product_manufacturers`;
CREATE TABLE `lal5d_virtuemart_product_manufacturers` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_product_id` int(1) DEFAULT NULL,
  `virtuemart_manufacturer_id` int(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_product_id` (`virtuemart_product_id`,`virtuemart_manufacturer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='Maps a product to a manufacturer';

INSERT INTO lal5d_virtuemart_product_manufacturers
(`id`, `virtuemart_product_id`, `virtuemart_manufacturer_id`) VALUES 
('1', '13', '1'),
('2', '163', '2'),
('3', '170', '3'),
('4', '200', '2'),
('5', '204', '3'),
('6', '300', '3'),
('7', '153', '2'),
('8', '154', '3'),
('9', '155', '3'),
('10', '159', '2'),
('11', '1000', '1'),
('12', '1100', '2'),
('13', '1200', '3');

DROP TABLE IF EXISTS `lal5d_virtuemart_product_medias`;
CREATE TABLE `lal5d_virtuemart_product_medias` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_product_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_media_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_product_id` (`virtuemart_product_id`,`virtuemart_media_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_product_medias
(`id`, `virtuemart_product_id`, `virtuemart_media_id`, `ordering`) VALUES 
('1', '13', '20', '1'),
('2', '203', '21', '1'),
('3', '207', '22', '1'),
('4', '154', '24', '1'),
('5', '155', '29', '1'),
('6', '156', '25', '1'),
('7', '157', '26', '1'),
('8', '158', '13', '1'),
('9', '160', '22', '1'),
('10', '161', '21', '1'),
('11', '162', '23', '1'),
('12', '164', '20', '2'),
('13', '164', '21', '3'),
('14', '164', '22', '4'),
('15', '164', '23', '5'),
('16', '164', '24', '6'),
('17', '164', '25', '7'),
('18', '164', '26', '8'),
('19', '164', '27', '9'),
('20', '164', '28', '10'),
('21', '164', '29', '11'),
('22', '300', '11', '1'),
('23', '302', '29', '1'),
('24', '304', '29', '1'),
('25', '307', '29', '1'),
('26', '309', '29', '1'),
('27', '311', '29', '1'),
('28', '313', '29', '1'),
('29', '315', '29', '1'),
('30', '1000', '20', '0'),
('31', '1100', '20', '0'),
('32', '1200', '20', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_product_prices`;
CREATE TABLE `lal5d_virtuemart_product_prices` (
  `virtuemart_product_price_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_product_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_shoppergroup_id` int(1) unsigned NOT NULL DEFAULT '0',
  `product_price` decimal(15,6) DEFAULT NULL,
  `override` tinyint(1) DEFAULT NULL,
  `product_override_price` decimal(15,5) DEFAULT NULL,
  `product_tax_id` int(1) DEFAULT NULL,
  `product_discount_id` int(1) DEFAULT NULL,
  `product_currency` smallint(1) DEFAULT NULL,
  `product_price_publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_price_publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `price_quantity_start` int(1) unsigned NOT NULL DEFAULT '0',
  `price_quantity_end` int(1) unsigned NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_product_price_id`),
  KEY `virtuemart_product_id` (`virtuemart_product_id`),
  KEY `product_price` (`virtuemart_product_id`),
  KEY `virtuemart_shoppergroup_id` (`virtuemart_shoppergroup_id`),
  KEY `product_price_publish_up` (`product_price_publish_up`),
  KEY `product_price_publish_down` (`product_price_publish_down`),
  KEY `price_quantity_start` (`price_quantity_start`),
  KEY `price_quantity_end` (`price_quantity_end`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='Holds price records for a product';

INSERT INTO lal5d_virtuemart_product_prices
(`virtuemart_product_price_id`, `virtuemart_product_id`, `virtuemart_shoppergroup_id`, `product_price`, `override`, `product_override_price`, `product_tax_id`, `product_discount_id`, `product_currency`, `product_price_publish_up`, `product_price_publish_down`, `price_quantity_start`, `price_quantity_end`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '13', '0', '10.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('2', '163', '0', '10.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('3', '165', '0', '0.000010', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('4', '168', '0', '100.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '5', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('5', '168', '0', '80.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '6', '10', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('6', '168', '0', '70.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '11', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('7', '169', '0', '100.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('8', '169', '2', '80.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('9', '169', '4', '50.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('10', '200', '0', '33.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('11', '204', '0', '25.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('12', '207', '0', '80.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '6', '10', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('13', '207', '0', '50.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '11', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('14', '161', '0', '15.833330', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('15', '160', '0', '40.833330', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('16', '158', '0', '140.833330', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('17', '157', '0', '207.500000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('18', '156', '0', '49.166670', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('19', '154', '0', '40.833330', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('20', '155', '0', '24.166670', '0', '19.00000', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('21', '300', '0', '10.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('22', '301', '0', '8.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('23', '302', '0', '8.200000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('24', '303', '0', '8.500000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('25', '304', '0', '8.700000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('26', '305', '0', '9.900000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('27', '306', '0', '10.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('28', '307', '0', '10.300000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('29', '308', '0', '10.500000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('30', '309', '0', '10.800000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('31', '310', '0', '12.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('32', '311', '0', '12.400000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('33', '312', '0', '12.700000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('34', '313', '0', '12.900000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('35', '314', '0', '13.500000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('36', '315', '0', '14.500000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('37', '1000', '0', '10.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('38', '1100', '0', '50.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('39', '1200', '0', '80.000000', '', '', '', '', '47', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_product_shoppergroups`;
CREATE TABLE `lal5d_virtuemart_product_shoppergroups` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_product_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_shoppergroup_id` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_product_id` (`virtuemart_product_id`,`virtuemart_shoppergroup_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Maps Products to Categories';

DROP TABLE IF EXISTS `lal5d_virtuemart_products`;
CREATE TABLE `lal5d_virtuemart_products` (
  `virtuemart_product_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `product_parent_id` int(1) unsigned NOT NULL DEFAULT '0',
  `product_sku` varchar(255) DEFAULT NULL,
  `product_gtin` varchar(64) DEFAULT NULL,
  `product_mpn` varchar(64) DEFAULT NULL,
  `product_weight` decimal(10,4) DEFAULT NULL,
  `product_weight_uom` varchar(7) DEFAULT NULL,
  `product_length` decimal(10,4) DEFAULT NULL,
  `product_width` decimal(10,4) DEFAULT NULL,
  `product_height` decimal(10,4) DEFAULT NULL,
  `product_lwh_uom` varchar(7) DEFAULT NULL,
  `product_url` varchar(255) DEFAULT NULL,
  `product_in_stock` int(1) NOT NULL DEFAULT '0',
  `product_ordered` int(1) NOT NULL DEFAULT '0',
  `low_stock_notification` int(1) unsigned NOT NULL DEFAULT '0',
  `product_available_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_availability` varchar(32) DEFAULT NULL,
  `product_special` tinyint(1) DEFAULT NULL,
  `product_sales` int(1) unsigned NOT NULL DEFAULT '0',
  `product_unit` varchar(8) DEFAULT NULL,
  `product_packaging` decimal(8,4) unsigned DEFAULT NULL,
  `product_params` text NOT NULL,
  `hits` int(1) unsigned DEFAULT NULL,
  `intnotes` text,
  `metarobot` varchar(400) DEFAULT NULL,
  `metaauthor` varchar(400) DEFAULT NULL,
  `layout` varchar(16) DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `pordering` int(1) unsigned NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_product_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `product_parent_id` (`product_parent_id`),
  KEY `product_special` (`product_special`),
  KEY `product_in_stock` (`product_in_stock`),
  KEY `product_ordered` (`product_ordered`),
  KEY `published` (`published`),
  KEY `pordering` (`pordering`),
  KEY `created_on` (`created_on`),
  KEY `modified_on` (`modified_on`)
) ENGINE=MyISAM AUTO_INCREMENT=1211 DEFAULT CHARSET=utf8 COMMENT='All products are stored here.';

INSERT INTO lal5d_virtuemart_products
(`virtuemart_product_id`, `virtuemart_vendor_id`, `product_parent_id`, `product_sku`, `product_gtin`, `product_mpn`, `product_weight`, `product_weight_uom`, `product_length`, `product_width`, `product_height`, `product_lwh_uom`, `product_url`, `product_in_stock`, `product_ordered`, `low_stock_notification`, `product_available_date`, `product_availability`, `product_special`, `product_sales`, `product_unit`, `product_packaging`, `product_params`, `hits`, `intnotes`, `metarobot`, `metaauthor`, `layout`, `published`, `pordering`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('13', '1', '0', 'root', '', '', '0.1000', 'KG', '0.1000', '0.1000', '0.1000', 'M', '', '10', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', 'min_order_level=\"\"|max_order_level=\"\"|step_order_level=\"\"|product_box=\"1\"|', '', '', '', '', '', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('163', '1', '13', '', '', '', '', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('164', '1', '163', '', '', '', '5.0000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '2', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('165', '1', '163', 'DP2', '', '', '1.0000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '3', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('166', '1', '163', 'DP3', '', '', '10.0000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '4', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('167', '1', '163', 'CFD', '', '', '10.0000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '5', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('168', '1', '163', 'MPRS', '', '', '10.0000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '6', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('169', '1', '163', 'MP002', '', '', '10.0000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '7', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('200', '1', '13', '005', '', '', '0.1000', '', '', '', '', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('201', '1', '200', '006', '', '', '0.1000', '', '', '', '', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '2', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('202', '1', '200', '007', '', '', '', '', '', '', '', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '3', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('203', '1', '200', '008', '', '', '4.0000', '', '', '', '', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '4', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('204', '1', '13', '009', '', '', '0.4000', '', '', '', '', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '5', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('205', '1', '204', '010', '', '', '', '', '', '', '', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '6', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('206', '1', '204', '011', '', '', '', '', '', '', '', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '7', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('207', '1', '204', '012', '', '', '', '', '', '', '', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '8', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('170', '1', '13', '', '', '', '', '', '', '', '', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('171', '1', '170', 'CSIV', '', '', '', '', '', '', '', '', '', '11', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('172', '1', '170', 'GCCV', '', '', '', '', '', '', '', '', '', '12', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('173', '1', '172', 'GCV-A', '', '', '', '', '', '', '', '', '', '13', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('174', '1', '172', 'GCV-B', '', '', '', '', '', '', '', '', '', '14', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '2', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('175', '1', '172', 'GCV-C', '', '', '', '', '', '', '', '', '', '15', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '3', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('176', '1', '170', 'CSIV', '', '', '', '', '', '', '', '', '', '11', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('153', '1', '13', '', '', '', '', 'KG', '', '', '', 'M', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('154', '1', '13', 'PR-DST', '', '', '200.0000', 'G', '40.0000', '40.0000', '40.0000', 'CM', '', '50', '0', '0', '0000-00-00 00:00:00', '', '1', '0', '', '', '', '', '', '', '', '', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('155', '1', '13', 'MA-SS', '', '', '200.0000', 'G', '40.0000', '40.0000', '40.0000', 'CM', '', '50', '0', '0', '0000-00-00 00:00:00', '', '1', '0', '', '', '', '', '', '', '', '', '1', '2', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('156', '1', '153', 'MA-ZP', '', '', '200.0000', 'G', '40.0000', '40.0000', '3.0000', 'CM', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '3', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('157', '1', '153', 'MA-H2J', '', '', '300.0000', 'G', '45.0000', '45.0000', '10.0000', 'CM', '', '5', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '4', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('158', '1', '153', 'DESKR', '', '', '200.0000', 'G', '35.0000', '35.0000', '5.0000', 'CM', '', '100', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '5', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('159', '1', '13', '', '', '', '', 'KG', '', '', '', 'M', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('160', '1', '159', 'XSF', '', '', '150.0000', 'G', '30.0000', '30.0000', '30.0000', 'CM', '', '30', '0', '0', '0000-00-00 00:00:00', '', '1', '0', '', '', '', '', '', '', '', '', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('161', '1', '159', 'PRCB', '', '', '100.0000', 'G', '20.0000', '20.0000', '20.0000', 'CM', '', '20', '0', '0', '0000-00-00 00:00:00', '', '1', '0', '', '', '', '', '', '', '', '', '1', '2', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('162', '1', '159', 'TPCM', '', '', '150.0000', 'G', '35.0000', '30.0000', '15.0000', 'CM', '', '30', '0', '0', '0000-00-00 00:00:00', '', '1', '0', '', '', '', '', '', '', '', '', '1', '3', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('195', '1', '154', 'DS-Small', '', '', '', 'G', '', '', '', 'CM', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('196', '1', '154', 'DS-Large', '', '', '', 'G', '', '', '', 'CM', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '2', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('197', '1', '155', 'TS-Small', '', '', '', 'G', '', '', '', 'CM', '', '30', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('198', '1', '155', 'TS-Medium', '', '', '', 'G', '', '', '', 'CM', '', '30', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '2', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('199', '1', '155', 'TS-Large', '', '', '', 'G', '', '', '', 'CM', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '0', '', '', '', '', '', '', '', '', '1', '3', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('300', '1', '170', 'MV Parent', '', '', '', '', '', '56.0000', '', 'CM', '', '10', '0', '0', '0000-00-00 00:00:00', '', '1', '0', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('301', '1', '300', 'MV 2', '', '', '', '', '68.5000', '46.0000', '', '', '', '8', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('302', '1', '300', 'MV 3', '', '', '', '', '68.5000', '46.0000', '', '', '', '5', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('303', '1', '300', 'MV 4', '', '', '', '', '71.0000', '46.0000', '', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '2', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('304', '1', '300', 'MV 5', '', '', '', '', '71.0000', '46.0000', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '3', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('305', '1', '300', 'MV 6', '', '', '', '', '68.5000', '51.0000', '', '', '', '30', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '10', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('306', '1', '300', 'MV 7', '', '', '', '', '71.0000', '51.0000', '', '', '', '35', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '11', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('307', '1', '300', 'MV 8', '', '', '', '', '71.0000', '51.0000', '', '', '', '25', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '12', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('308', '1', '300', 'MV 9', '', '', '', '', '73.5000', '51.0000', '', '', '', '40', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '13', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('309', '1', '300', 'MV 10', '', '', '', '', '73.5000', '51.0000', '', '', '', '30', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '14', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('310', '1', '300', 'MV 11', '', '', '', '', '73.5000', '56.0000', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '20', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('311', '1', '300', 'MV 12', '', '', '', '', '73.5000', '56.0000', '', '', '', '15', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '21', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_products
(`virtuemart_product_id`, `virtuemart_vendor_id`, `product_parent_id`, `product_sku`, `product_gtin`, `product_mpn`, `product_weight`, `product_weight_uom`, `product_length`, `product_width`, `product_height`, `product_lwh_uom`, `product_url`, `product_in_stock`, `product_ordered`, `low_stock_notification`, `product_available_date`, `product_availability`, `product_special`, `product_sales`, `product_unit`, `product_packaging`, `product_params`, `hits`, `intnotes`, `metarobot`, `metaauthor`, `layout`, `published`, `pordering`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('312', '1', '300', 'MV 13', '', '', '', '', '76.0000', '56.0000', '', '', '', '27', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '22', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('313', '1', '300', 'MV 14', '', '', '', '', '76.0000', '56.0000', '', '', '', '24', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '23', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('314', '1', '300', 'MV 15', '', '', '', '', '76.0000', '61.0000', '', '', '', '33', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '24', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('315', '1', '300', 'MV 16', '', '', '', '', '76.0000', '61.0000', '', '', '', '31', '0', '0', '0000-00-00 00:00:00', '', '', '0', '', '', '', '', '', '', '', '', '1', '25', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1000', '1', '13', 'CEG', '', '', '1.0000', '', '10.0000', '10.0000', '10.0000', '', '', '10', '0', '0', '0000-00-00 00:00:00', '', '', '170', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1100', '1', '13', 'GHD', '', '', '2.0000', '', '20.0000', '20.0000', '10.0000', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '', '180', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1200', '1', '13', 'FAC', '', '', '3.0000', '', '30.0000', '20.0000', '30.0000', '', '', '30', '0', '0', '0000-00-00 00:00:00', '', '', '190', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1001', '1', '1000', '', '', '', '1.1000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '50', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1002', '1', '1000', '', '', '', '1.2000', '', '', '', '', '', '', '30', '0', '0', '0000-00-00 00:00:00', '', '0', '40', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1003', '1', '1000', '', '', '', '1.2000', '', '', '', '', '', '', '25', '0', '0', '0000-00-00 00:00:00', '', '0', '70', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1004', '1', '1000', '', '', '', '1.1000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '50', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1005', '1', '1000', '', '', '', '1.3000', '', '', '', '', '', '', '23', '0', '0', '0000-00-00 00:00:00', '', '0', '51', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1006', '1', '1000', '', '', '', '1.3000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '52', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1007', '1', '1000', '', '', '', '1.1000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '53', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1008', '1', '1000', '', '', '', '1.4000', '', '', '', '', '', '', '25', '0', '0', '0000-00-00 00:00:00', '', '0', '54', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1009', '1', '1000', '', '', '', '1.5000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '55', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1010', '1', '1000', '', '', '', '1.8000', '', '', '', '', '', '', '30', '0', '0', '0000-00-00 00:00:00', '', '0', '56', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1101', '1', '1100', '', '', '', '2.1000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '20', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1102', '1', '1100', '', '', '', '2.2000', '', '', '', '', '', '', '30', '0', '0', '0000-00-00 00:00:00', '', '0', '30', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1103', '1', '1100', '', '', '', '2.2000', '', '', '', '', '', '', '25', '0', '0', '0000-00-00 00:00:00', '', '0', '40', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1104', '1', '1100', '', '', '', '2.1000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '50', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1105', '1', '1100', '', '', '', '2.3000', '', '', '', '', '', '', '23', '0', '0', '0000-00-00 00:00:00', '', '0', '51', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1106', '1', '1100', '', '', '', '2.5000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '52', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1107', '1', '1100', '', '', '', '2.6000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '53', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1108', '1', '1100', '', '', '', '2.7000', '', '', '', '', '', '', '25', '0', '0', '0000-00-00 00:00:00', '', '0', '54', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1109', '1', '1100', '', '', '', '2.8000', '', '', '', '', '', '', '20', '0', '0', '0000-00-00 00:00:00', '', '0', '55', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1110', '1', '1100', '', '', '', '2.9000', '', '', '', '', '', '', '30', '0', '0', '0000-00-00 00:00:00', '', '0', '56', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1201', '1', '1200', '', '', '', '', '', '20.0000', '', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '20', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1202', '1', '1200', '', '', '', '', '', '30.0000', '', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '30', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1203', '1', '1200', '', '', '', '', '', '25.0000', '', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '40', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1204', '1', '1200', '', '', '', '', '', '20.0000', '', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '50', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1205', '1', '1200', '', '', '', '', '', '23.0000', '', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '51', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1206', '1', '1200', '', '', '', '', '', '20.0000', '', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '52', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1207', '1', '1200', '', '', '', '', '', '20.0000', '', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '53', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1208', '1', '1200', '', '', '', '3.9000', '', '25.0000', '', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '54', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1209', '1', '1200', '', '', '', '3.8000', '', '20.0000', '', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '55', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1210', '1', '1200', '', '', '', '3.7000', '', '30.0000', '', '', '', '', '0', '0', '0', '0000-00-00 00:00:00', '', '0', '56', '', '', '', '', '', '', '', '', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_products_en_gb`;
CREATE TABLE `lal5d_virtuemart_products_en_gb` (
  `virtuemart_product_id` int(1) unsigned NOT NULL,
  `product_s_desc` varchar(2000) NOT NULL DEFAULT '',
  `product_desc` varchar(18400) NOT NULL DEFAULT '',
  `product_name` varchar(180) NOT NULL DEFAULT '',
  `metadesc` varchar(400) NOT NULL DEFAULT '',
  `metakey` varchar(400) NOT NULL DEFAULT '',
  `customtitle` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(192) NOT NULL DEFAULT '',
  PRIMARY KEY (`virtuemart_product_id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_products_en_gb
(`virtuemart_product_id`, `product_s_desc`, `product_desc`, `product_name`, `metadesc`, `metakey`, `customtitle`, `slug`) VALUES 
('13', '', '<p>This product is derived from a pattern for other products. It is a parent product and has multiple child products. <br />You can set several settings (content, customfields) for parent product. Childs of this parent will basically have the same settings as the parent automatically inherit except you overwrite the settings.<br /><br /></p>\r\n<p>In this case product price is set in pattern.</p><p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n<p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   <br /><br /></p>', 'Root Pattern', '', '', '', 'root'),
('163', '', '', 'PATTERN Product attributes', '', '', '', 'pattern-product-attributes'),
('164', '', '', 'Default product', '', '', '', 'default-product'),
('165', 'It\'s a free Product!', '<p>This product shows how a free product is set up. The shopper can purchase without beeing charged. In all cases the shopper needs to checkout.</p>\r\n<p>It can be used e.g. if you want to offer catalogues or sample products.</p>', 'Free product', '', '', '', 'free-product'),
('166', 'Default product with customfield string & editor. ', '<p>Please note: this example for string is no cart attribute, if you want to display the string detail in cart please enable Cart attribut in custom prototype.</p>', 'String &#38; list, editor', '', '', '', 'string,-list,-editor'),
('167', 'Showcase image customfield.', '<p>Use customfield to display an image or image list on desired layout position. <br /><br />Customfield image allows to display any of your media images, while image list provides a preset based on list in customfied prototype.<br />See for details be &gt; Custom Fields &gt; Image list</p>', 'Images &#38; list', '', '', '', 'images-list'),
('168', 'Price ranges for product quantity.', '<p>Price ranges for product quantity. Test out the price changes following the values below<br /><br />100€ 1-5 pcs</p>\r\n<p>80€ 6-10 pcs</p>\r\n<p>70€ 11- pcs</p>', 'Multiple price ranges', '', '', '', 'multiple-price-ranges'),
('169', 'Mutliple prices per shoppergroups.', '<p>Your shoppergroup changes your price. Login to preview.<br /><br />100€ Guest</p>\r\n<p>80€ Registered</p>\r\n<p>50€ Gold Member</p>', 'Multiple prices', '', '', '', 'images-1'),
('200', 'Showcase for pattern usage.', '<p>This product is used as a pattern for other products. It is a parent product and has multiple child products. <br />You can set several settings (content, customfields) for parent product. Childs of this parent will basically have the same settings as the parent automatically inherit except you overwrite the settings.<br /><br /></p>\r\n<p>In this case product price is set in pattern.</p>', 'Basic PATTERN', '', '', '', 'basic-pattern'),
('201', 'This is a basic child of Product PATTERN.', '<p>This is a basic child of Product PATTERN. You see inherited settings, only Product description is overwritten.<br /></p>', 'Basic child', '', '', '', 'basic-pattern-1'),
('202', 'This is a basic child of Product PATTERN. You see inherited settings.', '<p>This is a basic child of Product PATTERN. You see inherited settings. <br />Overwritten are following setting/content:<br />- Product desc<br />- Product price<br /></p>', 'Basic price overwrite', '', '', '', 'basic-price-overwrite'),
('203', 'Multiple overwrites short desc.', '<p>This is a child of Product PATTERN. Most inherited settings are overwritten: <br />- Short desc<br />- Product desc<br />- Product price<br />- Product Images<br />- Product Dimension and Weight (Units in Box)<br /></p>', 'Basic multiple overwrites', '', '', '', 'basic-multiple-overwrites'),
('204', 'Showcase advanced pattern usage.', '<p>This product is used as a pattern for other products. It is a parent product and has multiple child products. <br />You can set several settings (content, customfields) for parent product. Childs of this parent will basically have the same settings as the parent inherited until you overwrite.</p>\r\n<p>One of the hugest advantages is stock control ability.</p>', 'Advanced PATTERN', '', '', '', 'advanced-pattern'),
('205', '', '<p>This is a basic child of Product PATTERN. You see inherited settings, only Product description is overwritten.<br /></p>', 'Advanced child', '', '', '', 'advanced-child'),
('206', '', '<p>This is a advanced child of Advanced PATTERN. You see inherited settings. <br />Overwritten are following setting/content:<br />- Product desc<br />- Product price<br /></p>', 'Advanced price overwrite', '', '', '', 'advanced-price-overwrite'),
('207', 'Advanced multiple overrides', '<p>This is a child of Product PATTERN. Most inherited settings are overwritten: <br />- Short desc<br />- Product desc<br />- Product price<br />- Product Images<br />- Product Dimension and Weight (Units in Box)<br />- Customfields<br /></p>', 'Advanced multiple overrides', '', '', '', 'advanced-multiple-overrides'),
('170', '', '', 'PATTERN Product variants', '', '', '', 'pattern-product-variants'),
('171', '', '', 'Customfield string', '', '', '', 'customfield-string'),
('172', 'Default product generic child variant and cart variant.', '<p>Showcase to present the combination of product price, child variant price, and cart variant price:<br /><br />Child variant -&gt; full overrideable genuine product, stock control per variant</p>\r\n<p>Cart variant -&gt; easy to use variant, add price, no stock control</p>', 'Generic child variant', '', '', '', 'generic-child-cart-variant'),
('173', '', '', 'generic child variant A', '', '', '', 'generic-child-variant-a'),
('174', 'Default product generic child variant and cart variant.', '<p>This product is a showcase to present the combination of product price, child variant price, and cart variant price.<br /><br />Cart variant -&gt; easy to use, add price (+0.50€) no variant stock control</p>\r\n<p><br />Child variant -&gt; full overrideable genuine product as variant</p>', 'generic child variant B', '', '', '', 'generic-child-variant-b'),
('175', 'Default product generic child variant and cart variant.', '<p>This product is a showcase to present the combination of product price, child variant price, and cart variant price.<br /><br />Cart variant -&gt; easy to use, add price (+0.50€) no variant stock control</p>\r\n<p><br />Child variant -&gt; full overrideable genuine product as variant</p>', 'generic child variant C', '', '', '', 'generic-child-variant-c'),
('176', 'Product image variant', '<p>This product is a showcase for customfield image variant as shopper selection</p>', 'Customfield image variant', '', '', '', 'customfield-image-variant'),
('153', '', '', 'PATTERN Wear', '', '', '', 'pattern-wear'),
('154', 'Fine feathers make fine birds - time to get serious.', '<p>Refresh yourself with genuine VM dress.</p>', 'Dress Shirt with tie', '', '', '', 'dress-shirt-with-tie'),
('155', 'Freetime & leisure 360° comrade.', '<p>The first print VM shirt available - the one - the virtue. Profit by introductory offer </p>', 'T-Shirt classic blue', '', '', '', 't-shirt-classic-blue'),
('156', 'Your winter season friend. ', '', 'Zipper pullover', '', '', '', 'zipper-pullover'),
('157', 'Hard rain? Cold? - keep yourself dry & warm.', '', 'H20 Jacket', '', '', '', 'h20-jacket'),
('158', 'Redesigned traditional pattern. Decently highlighted VM emblem.', '', 'Skirt &#34;Knock-Rock&#34;', '', '', '', 'skirt-knock-rock'),
('159', '', '', 'PATTERN Headpiece', '', '', '', 'pattern-headpiece'),
('160', 'Masterclass protection, your everyday safety.', '', 'Safety Helmet', '', '', '', 'safety-helmet'),
('161', 'Need something genuine for your freetime?', '', 'Cap &#34;Baseball&#34;', '', '', '', 'cap-baseball'),
('162', 'Classic pattern, durable stiff brim resists sun & moisture.', '', 'Cowboy Hat', '', '', '', 'cowboy-hat'),
('195', '', '', 'Dress Shirt with tie - small', '', '', '', 'dress-shirt-with-tie-s'),
('196', '', '', 'Dress Shirt with tie - large', '', '', '', 'dress-shirt-with-tie-l'),
('197', '', '', 'T-Shirt classic blue - small', '', '', '', 't-shirt-classic-s'),
('198', '', '', 'T-Shirt classic blue - medium', '', '', '', 't-shirt-classic-m'),
('199', '', '', 'T-Shirt classic blue - large', '', '', '', 't-shirt-classic-l'),
('300', 'Depended Multivariants', 'The new Multi variant feature lets manage you 100s of product variants in the parent. The product content is replaced by the selected product', 'Multi Variant', '', '', '', 'multi-variant'),
('301', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-2'),
('302', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-3'),
('303', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-4'),
('304', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-5'),
('305', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-6'),
('306', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-7'),
('307', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-8'),
('308', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-9'),
('309', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-10'),
('310', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-11'),
('311', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-12');

INSERT INTO lal5d_virtuemart_products_en_gb
(`virtuemart_product_id`, `product_s_desc`, `product_desc`, `product_name`, `metadesc`, `metakey`, `customtitle`, `slug`) VALUES 
('312', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-13'),
('313', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-14'),
('314', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-15'),
('315', '', '', 'Multi Variant Child', '', '', '', 'multi-variant-16'),
('1000', '', '', 'CEG #0 03', '', '', '', 'ceg-0-03'),
('1100', '', '', 'GHD #0 08', '', '', '', 'ghd-0-08'),
('1200', '', '', 'FAC #0 20', '', '', '', 'fac-0-20'),
('1001', '', '', 'CEG #1 06', '', '', '', 'ceg-1-06'),
('1002', '', '', 'CEG #2 15', '', '', '', 'ceg-2-15'),
('1003', '', '', 'CEG #3 30', '', '', '', 'ceg-3-30'),
('1004', '', '', 'CEG #4 17', '', '', '', 'ceg-4-17'),
('1005', '', '', 'CEG #5 16', '', '', '', 'ceg-5-16'),
('1006', '', '', 'CEG #6 22', '', '', '', 'ceg-6-22'),
('1007', '', '', 'CEG #7 23', '', '', '', 'ceg-7-23'),
('1008', '', '', 'CEG #8 12', '', '', '', 'ceg-8-12'),
('1009', '', '', 'CEG #9 18', '', '', '', 'ceg-9-18'),
('1010', '', '', 'CEG #a 33', '', '', '', 'ceg-a-33'),
('1101', '', '', 'GHD #1 02', '', '', '', 'ghd-1-02'),
('1102', '', '', 'GHD #2 07', '', '', '', 'ghd-2-07'),
('1103', '', '', 'GHD #3 05', '', '', '', 'ghd-3-05'),
('1104', '', '', 'GHD #4 04', '', '', '', 'ghd-4-04'),
('1105', '', '', 'GHD #5 01', '', '', '', 'ghd-5-01'),
('1106', '', '', 'GHD #6 32', '', '', '', 'ghd-6-32'),
('1107', '', '', 'GHD #7 25', '', '', '', 'ghd-7-25'),
('1108', '', '', 'GHD #8 24', '', '', '', 'ghd-8-24'),
('1109', '', '', 'GHD #9 27', '', '', '', 'ghd-9-27'),
('1110', '', '', 'GHD #a 28', '', '', '', 'ghd-a-28'),
('1201', '', '', 'FAC #1 19', '', '', '', 'fac-1-19'),
('1202', '', '', 'FAC #2 14', '', '', '', 'fac-2-14'),
('1203', '', '', 'FAC #3 13', '', '', '', 'fac-3-13'),
('1204', '', '', 'FAC #4 11', '', '', '', 'fac-4-11'),
('1205', '', '', 'FAC #5 26', '', '', '', 'fac-5-26'),
('1206', '', '', 'FAC #6 09', '', '', '', 'fac-6-09'),
('1207', '', '', 'FAC #7 31', '', '', '', 'fac-7-31'),
('1208', '', '', 'FAC #8 10', '', '', '', 'fac-8-10'),
('1209', '', '', 'FAC #9 29', '', '', '', 'fac-9-29'),
('1210', '', '', 'FAC #a 12', '', '', '', 'fac-a-12');

DROP TABLE IF EXISTS `lal5d_virtuemart_rating_reviews`;
CREATE TABLE `lal5d_virtuemart_rating_reviews` (
  `virtuemart_rating_review_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_rating_vote_id` int(1) unsigned DEFAULT NULL,
  `virtuemart_product_id` int(1) unsigned NOT NULL DEFAULT '0',
  `comment` varchar(18000) DEFAULT NULL,
  `review_ok` tinyint(1) NOT NULL DEFAULT '0',
  `review_rates` int(1) unsigned NOT NULL DEFAULT '0',
  `review_ratingcount` int(1) unsigned NOT NULL DEFAULT '0',
  `review_rating` decimal(10,2) NOT NULL DEFAULT '0.00',
  `review_editable` tinyint(1) NOT NULL DEFAULT '1',
  `lastip` char(50) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `customer` varchar(128) NOT NULL DEFAULT '',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_rating_review_id`),
  KEY `virtuemart_rating_vote_id` (`virtuemart_rating_vote_id`),
  KEY `virtuemart_product_id` (`virtuemart_product_id`,`created_by`),
  KEY `created_on` (`created_on`),
  KEY `created_by` (`created_by`),
  KEY `published` (`published`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_virtuemart_rating_votes`;
CREATE TABLE `lal5d_virtuemart_rating_votes` (
  `virtuemart_rating_vote_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_product_id` int(1) unsigned NOT NULL DEFAULT '0',
  `vote` int(1) NOT NULL DEFAULT '0',
  `lastip` char(50) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_rating_vote_id`),
  KEY `virtuemart_product_id` (`virtuemart_product_id`,`created_by`),
  KEY `created_by` (`created_by`),
  KEY `created_on` (`created_on`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores all ratings for a product';

DROP TABLE IF EXISTS `lal5d_virtuemart_ratings`;
CREATE TABLE `lal5d_virtuemart_ratings` (
  `virtuemart_rating_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_product_id` int(1) unsigned NOT NULL DEFAULT '0',
  `rates` int(1) NOT NULL DEFAULT '0',
  `ratingcount` int(1) unsigned NOT NULL DEFAULT '0',
  `rating` decimal(10,1) NOT NULL DEFAULT '0.0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_rating_id`),
  UNIQUE KEY `virtuemart_product_id` (`virtuemart_product_id`,`virtuemart_rating_id`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=1211 DEFAULT CHARSET=utf8 COMMENT='Stores all ratings for a product';

INSERT INTO lal5d_virtuemart_ratings
(`virtuemart_rating_id`, `virtuemart_product_id`, `rates`, `ratingcount`, `rating`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES 
('160', '164', '5', '1', '4.9', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('161', '165', '4', '1', '4.3', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('162', '166', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('163', '167', '5', '1', '4.2', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('164', '168', '4', '1', '3.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('165', '169', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('200', '200', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('201', '201', '5', '1', '4.9', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('202', '202', '4', '1', '3.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('203', '203', '5', '1', '4.9', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('204', '204', '5', '1', '4.4', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('205', '205', '4', '1', '4.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('206', '206', '5', '1', '4.9', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('207', '207', '5', '1', '4.9', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('170', '170', '5', '1', '4.6', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('171', '171', '4', '1', '4.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('172', '172', '5', '1', '4.9', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('150', '154', '5', '1', '4.6', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('151', '155', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('152', '156', '4', '1', '3.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('153', '157', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('154', '158', '5', '1', '4.4', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('155', '160', '4', '1', '4.2', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('156', '161', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('157', '162', '5', '1', '4.7', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('300', '300', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('301', '301', '4', '1', '4.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('302', '302', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('303', '303', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('304', '304', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('305', '305', '4', '1', '4.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('306', '306', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('307', '307', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('308', '308', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('309', '309', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('310', '310', '4', '1', '4.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('311', '311', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('312', '312', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('313', '313', '4', '1', '4.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('314', '314', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('315', '315', '5', '1', '5.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1000', '1000', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1001', '1001', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1002', '1002', '4', '1', '4.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1003', '1003', '5', '1', '3.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1004', '1004', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1005', '1005', '4', '1', '4.0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1006', '1006', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1007', '1007', '5', '1', '4.9', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1008', '1008', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_ratings
(`virtuemart_rating_id`, `virtuemart_product_id`, `rates`, `ratingcount`, `rating`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`) VALUES 
('1009', '1009', '5', '1', '3.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1100', '1100', '5', '1', '4.5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1101', '1101', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1102', '1102', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1103', '1103', '5', '1', '4.5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1104', '1104', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1105', '1105', '5', '1', '3.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1106', '1106', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1107', '1107', '5', '1', '4.5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1108', '1108', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1109', '1109', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1110', '1110', '5', '1', '4.5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1200', '1200', '5', '1', '3.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1201', '1201', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1202', '1202', '5', '1', '4.5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1203', '1203', '5', '1', '4.5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1204', '1204', '5', '1', '3.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1205', '1205', '5', '1', '4.5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1206', '1206', '5', '1', '4.5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1207', '1207', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1208', '1208', '5', '1', '4.5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1209', '1209', '5', '1', '4.5', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1210', '1210', '5', '1', '4.8', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_shipment_plg_weight_countries`;
CREATE TABLE `lal5d_virtuemart_shipment_plg_weight_countries` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_order_id` int(11) unsigned DEFAULT NULL,
  `order_number` char(32) DEFAULT NULL,
  `virtuemart_shipmentmethod_id` mediumint(1) unsigned DEFAULT NULL,
  `shipment_name` varchar(5000) DEFAULT NULL,
  `order_weight` decimal(10,4) DEFAULT NULL,
  `shipment_weight_unit` char(3) DEFAULT 'KG',
  `shipment_cost` decimal(10,2) DEFAULT NULL,
  `shipment_package_fee` decimal(10,2) DEFAULT NULL,
  `tax_id` smallint(1) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Shipment Weight Countries Table';

DROP TABLE IF EXISTS `lal5d_virtuemart_shipmentmethod_shoppergroups`;
CREATE TABLE `lal5d_virtuemart_shipmentmethod_shoppergroups` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_shipmentmethod_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_shoppergroup_id` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_shipmentmethod_id` (`virtuemart_shipmentmethod_id`,`virtuemart_shoppergroup_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='xref table for shipment to shoppergroup';

DROP TABLE IF EXISTS `lal5d_virtuemart_shipmentmethods`;
CREATE TABLE `lal5d_virtuemart_shipmentmethods` (
  `virtuemart_shipmentmethod_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `shipment_jplugin_id` int(1) NOT NULL DEFAULT '0',
  `shipment_element` varchar(50) NOT NULL DEFAULT '',
  `shipment_params` varchar(19000) NOT NULL DEFAULT '',
  `currency_id` int(1) unsigned DEFAULT NULL,
  `ordering` int(1) NOT NULL DEFAULT '0',
  `shared` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_shipmentmethod_id`),
  KEY `shipment_jplugin_id` (`shipment_jplugin_id`),
  KEY `shipment_element` (`shipment_element`,`virtuemart_vendor_id`),
  KEY `ordering` (`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Shipment created from the shipment plugins';

INSERT INTO lal5d_virtuemart_shipmentmethods
(`virtuemart_shipmentmethod_id`, `virtuemart_vendor_id`, `shipment_jplugin_id`, `shipment_element`, `shipment_params`, `currency_id`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '1', '10018', 'weight_countries', 'shipment_logos=\"\"|countries=\"\"|zip_start=\"\"|zip_stop=\"\"|weight_start=\"\"|weight_stop=\"\"|weight_unit=\"KG\"|nbproducts_start=0|nbproducts_stop=0|orderamount_start=\"\"|orderamount_stop=\"\"|cost=\"0\"|package_fee=\"2.49\"|tax_id=\"0\"|free_shipment=\"500\"|', '', '0', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_shipmentmethods_en_gb`;
CREATE TABLE `lal5d_virtuemart_shipmentmethods_en_gb` (
  `virtuemart_shipmentmethod_id` int(1) unsigned NOT NULL,
  `shipment_name` varchar(180) NOT NULL DEFAULT '',
  `shipment_desc` varchar(19000) NOT NULL DEFAULT '',
  `slug` varchar(192) NOT NULL DEFAULT '',
  PRIMARY KEY (`virtuemart_shipmentmethod_id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_shipmentmethods_en_gb
(`virtuemart_shipmentmethod_id`, `shipment_name`, `shipment_desc`, `slug`) VALUES 
('1', 'Self pick-up', '', 'Self-pick-up');

DROP TABLE IF EXISTS `lal5d_virtuemart_shoppergroups`;
CREATE TABLE `lal5d_virtuemart_shoppergroups` (
  `virtuemart_shoppergroup_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `shopper_group_name` varchar(128) DEFAULT NULL,
  `shopper_group_desc` varchar(255) DEFAULT NULL,
  `custom_price_display` tinyint(1) NOT NULL DEFAULT '0',
  `price_display` blob NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `sgrp_additional` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  `shared` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_shoppergroup_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `shopper_group_name` (`shopper_group_name`),
  KEY `ordering` (`ordering`),
  KEY `shared` (`shared`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='Shopper Groups that users can be assigned to';

INSERT INTO lal5d_virtuemart_shoppergroups
(`virtuemart_shoppergroup_id`, `virtuemart_vendor_id`, `shopper_group_name`, `shopper_group_desc`, `custom_price_display`, `price_display`, `default`, `sgrp_additional`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('2', '1', 'COM_VIRTUEMART_SHOPPERGROUP_DEFAULT', 'COM_VIRTUEMART_SHOPPERGROUP_DEFAULT_TIP', '0', '', '1', '0', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('1', '1', 'COM_VIRTUEMART_SHOPPERGROUP_GUEST', 'COM_VIRTUEMART_SHOPPERGROUP_GUEST_TIP', '0', '', '2', '0', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('3', '1', 'Wholesale', 'Shoppers that can buy at wholesale.', '0', '', '0', '0', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('4', '1', 'Gold Level', 'Gold Level Shoppers.', '0', '', '0', '0', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_states`;
CREATE TABLE `lal5d_virtuemart_states` (
  `virtuemart_state_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `virtuemart_country_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_worldzone_id` int(1) unsigned NOT NULL DEFAULT '0',
  `state_name` varchar(64) DEFAULT NULL,
  `state_3_code` char(3) DEFAULT NULL,
  `state_2_code` char(2) DEFAULT NULL,
  `ordering` int(1) NOT NULL DEFAULT '0',
  `shared` tinyint(1) NOT NULL DEFAULT '1',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_state_id`),
  UNIQUE KEY `state_3_code` (`virtuemart_vendor_id`,`virtuemart_country_id`,`state_3_code`),
  UNIQUE KEY `state_2_code` (`virtuemart_vendor_id`,`virtuemart_country_id`,`state_2_code`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `virtuemart_country_id` (`virtuemart_country_id`),
  KEY `ordering` (`ordering`),
  KEY `shared` (`shared`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=832 DEFAULT CHARSET=utf8 COMMENT='States that are assigned to a country';

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '1', '223', '0', 'Alabama', 'ALA', 'AL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('2', '1', '223', '0', 'Alaska', 'ALK', 'AK', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('3', '1', '223', '0', 'Arizona', 'ARZ', 'AZ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('4', '1', '223', '0', 'Arkansas', 'ARK', 'AR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('5', '1', '223', '0', 'California', 'CAL', 'CA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('6', '1', '223', '0', 'Colorado', 'COL', 'CO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('7', '1', '223', '0', 'Connecticut', 'CCT', 'CT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('8', '1', '223', '0', 'Delaware', 'DEL', 'DE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('9', '1', '223', '0', 'District Of Columbia', 'DOC', 'DC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('10', '1', '223', '0', 'Florida', 'FLO', 'FL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('11', '1', '223', '0', 'Georgia', 'GEA', 'GA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('12', '1', '223', '0', 'Hawaii', 'HWI', 'HI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('13', '1', '223', '0', 'Idaho', 'IDA', 'ID', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('14', '1', '223', '0', 'Illinois', 'ILL', 'IL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('15', '1', '223', '0', 'Indiana', 'IND', 'IN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('16', '1', '223', '0', 'Iowa', 'IOA', 'IA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('17', '1', '223', '0', 'Kansas', 'KAS', 'KS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('18', '1', '223', '0', 'Kentucky', 'KTY', 'KY', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('19', '1', '223', '0', 'Louisiana', 'LOA', 'LA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('20', '1', '223', '0', 'Maine', 'MAI', 'ME', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('21', '1', '223', '0', 'Maryland', 'MLD', 'MD', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('22', '1', '223', '0', 'Massachusetts', 'MSA', 'MA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('23', '1', '223', '0', 'Michigan', 'MIC', 'MI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('24', '1', '223', '0', 'Minnesota', 'MIN', 'MN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('25', '1', '223', '0', 'Mississippi', 'MIS', 'MS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('26', '1', '223', '0', 'Missouri', 'MIO', 'MO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('27', '1', '223', '0', 'Montana', 'MOT', 'MT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('28', '1', '223', '0', 'Nebraska', 'NEB', 'NE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('29', '1', '223', '0', 'Nevada', 'NEV', 'NV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('30', '1', '223', '0', 'New Hampshire', 'NEH', 'NH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('31', '1', '223', '0', 'New Jersey', 'NEJ', 'NJ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('32', '1', '223', '0', 'New Mexico', 'NEM', 'NM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('33', '1', '223', '0', 'New York', 'NEY', 'NY', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('34', '1', '223', '0', 'North Carolina', 'NOC', 'NC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('35', '1', '223', '0', 'North Dakota', 'NOD', 'ND', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('36', '1', '223', '0', 'Ohio', 'OHI', 'OH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('37', '1', '223', '0', 'Oklahoma', 'OKL', 'OK', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('38', '1', '223', '0', 'Oregon', 'ORN', 'OR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('39', '1', '223', '0', 'Pennsylvania', 'PEA', 'PA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('40', '1', '223', '0', 'Rhode Island', 'RHI', 'RI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('41', '1', '223', '0', 'South Carolina', 'SOC', 'SC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('42', '1', '223', '0', 'South Dakota', 'SOD', 'SD', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('43', '1', '223', '0', 'Tennessee', 'TEN', 'TN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('44', '1', '223', '0', 'Texas', 'TXS', 'TX', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('45', '1', '223', '0', 'Utah', 'UTA', 'UT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('46', '1', '223', '0', 'Vermont', 'VMT', 'VT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('47', '1', '223', '0', 'Virginia', 'VIA', 'VA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('48', '1', '223', '0', 'Washington', 'WAS', 'WA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('49', '1', '223', '0', 'West Virginia', 'WEV', 'WV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('50', '1', '223', '0', 'Wisconsin', 'WIS', 'WI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('51', '1', '223', '0', 'Wyoming', 'WYO', 'WY', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('52', '1', '38', '0', 'Alberta', 'ALB', 'AB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('53', '1', '38', '0', 'British Columbia', 'BRC', 'BC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('54', '1', '38', '0', 'Manitoba', 'MAB', 'MB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('55', '1', '38', '0', 'New Brunswick', 'NEB', 'NB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('56', '1', '38', '0', 'Newfoundland and Labrador', 'NFL', 'NL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('57', '1', '38', '0', 'Northwest Territories', 'NWT', 'NT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('58', '1', '38', '0', 'Nova Scotia', 'NOS', 'NS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('59', '1', '38', '0', 'Nunavut', 'NUT', 'NU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('60', '1', '38', '0', 'Ontario', 'ONT', 'ON', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('61', '1', '38', '0', 'Prince Edward Island', 'PEI', 'PE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('62', '1', '38', '0', 'Quebec', 'QEC', 'QC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('63', '1', '38', '0', 'Saskatchewan', 'SAK', 'SK', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('64', '1', '38', '0', 'Yukon', 'YUT', 'YT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('65', '1', '222', '0', 'England', 'ENG', 'EN', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('66', '1', '222', '0', 'Northern Ireland', 'NOI', 'NI', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('67', '1', '222', '0', 'Scotland', 'SCO', 'SD', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('68', '1', '222', '0', 'Wales', 'WLS', 'WS', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('69', '1', '13', '0', 'Australian Capital Territory', 'ACT', 'AC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('70', '1', '13', '0', 'New South Wales', 'NSW', 'NS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('71', '1', '13', '0', 'Northern Territory', 'NOT', 'NT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('72', '1', '13', '0', 'Queensland', 'QLD', 'QL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('73', '1', '13', '0', 'South Australia', 'SOA', 'SA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('74', '1', '13', '0', 'Tasmania', 'TAS', 'TS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('75', '1', '13', '0', 'Victoria', 'VIC', 'VI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('76', '1', '13', '0', 'Western Australia', 'WEA', 'WA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('77', '1', '138', '0', 'Aguascalientes', 'AGS', 'AG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('78', '1', '138', '0', 'Baja California Norte', 'BCN', 'BN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('79', '1', '138', '0', 'Baja California Sur', 'BCS', 'BS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('80', '1', '138', '0', 'Campeche', 'CAM', 'CA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('81', '1', '138', '0', 'Chiapas', 'CHI', 'CS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('82', '1', '138', '0', 'Chihuahua', 'CHA', 'CH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('83', '1', '138', '0', 'Coahuila', 'COA', 'CO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('84', '1', '138', '0', 'Colima', 'COL', 'CM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('85', '1', '138', '0', 'Distrito Federal', 'DFM', 'DF', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('86', '1', '138', '0', 'Durango', 'DGO', 'DO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('87', '1', '138', '0', 'Guanajuato', 'GTO', 'GO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('88', '1', '138', '0', 'Guerrero', 'GRO', 'GU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('89', '1', '138', '0', 'Hidalgo', 'HGO', 'HI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('90', '1', '138', '0', 'Jalisco', 'JAL', 'JA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('91', '1', '138', '0', 'M', 'EDM', 'EM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('92', '1', '138', '0', 'Michoac', 'MCN', 'MI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('93', '1', '138', '0', 'Morelos', 'MOR', 'MO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('94', '1', '138', '0', 'Nayarit', 'NAY', 'NY', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('95', '1', '138', '0', 'Nuevo Le', 'NUL', 'NL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('96', '1', '138', '0', 'Oaxaca', 'OAX', 'OA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('97', '1', '138', '0', 'Puebla', 'PUE', 'PU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('98', '1', '138', '0', 'Quer', 'QRO', 'QU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('99', '1', '138', '0', 'Quintana Roo', 'QUR', 'QR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('100', '1', '138', '0', 'San Luis Potos', 'SLP', 'SP', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('101', '1', '138', '0', 'Sinaloa', 'SIN', 'SI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('102', '1', '138', '0', 'Sonora', 'SON', 'SO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('103', '1', '138', '0', 'Tabasco', 'TAB', 'TA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('104', '1', '138', '0', 'Tamaulipas', 'TAM', 'TM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('105', '1', '138', '0', 'Tlaxcala', 'TLX', 'TX', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('106', '1', '138', '0', 'Veracruz', 'VER', 'VZ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('107', '1', '138', '0', 'Yucat', 'YUC', 'YU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('108', '1', '138', '0', 'Zacatecas', 'ZAC', 'ZA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('109', '1', '30', '0', 'Acre', 'ACR', 'AC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('110', '1', '30', '0', 'Alagoas', 'ALG', 'AL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('111', '1', '30', '0', 'Amapá', 'AMP', 'AP', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('112', '1', '30', '0', 'Amazonas', 'AMZ', 'AM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('113', '1', '30', '0', 'Bahía', 'BAH', 'BA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('114', '1', '30', '0', 'Ceará', 'CEA', 'CE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('115', '1', '30', '0', 'Distrito Federal', 'DFB', 'DF', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('116', '1', '30', '0', 'Espírito Santo', 'ESS', 'ES', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('117', '1', '30', '0', 'Goiás', 'GOI', 'GO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('118', '1', '30', '0', 'Maranhão', 'MAR', 'MA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('119', '1', '30', '0', 'Mato Grosso', 'MAT', 'MT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('120', '1', '30', '0', 'Mato Grosso do Sul', 'MGS', 'MS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('121', '1', '30', '0', 'Minas Gerais', 'MIG', 'MG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('122', '1', '30', '0', 'Paraná', 'PAR', 'PR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('123', '1', '30', '0', 'Paraíba', 'PRB', 'PB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('124', '1', '30', '0', 'Pará', 'PAB', 'PA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('125', '1', '30', '0', 'Pernambuco', 'PER', 'PE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('126', '1', '30', '0', 'Piauí', 'PIA', 'PI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('127', '1', '30', '0', 'Rio Grande do Norte', 'RGN', 'RN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('128', '1', '30', '0', 'Rio Grande do Sul', 'RGS', 'RS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('129', '1', '30', '0', 'Rio de Janeiro', 'RDJ', 'RJ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('130', '1', '30', '0', 'Rondônia', 'RON', 'RO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('131', '1', '30', '0', 'Roraima', 'ROR', 'RR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('132', '1', '30', '0', 'Santa Catarina', 'SAC', 'SC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('133', '1', '30', '0', 'Sergipe', 'SER', 'SE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('134', '1', '30', '0', 'São Paulo', 'SAP', 'SP', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('135', '1', '30', '0', 'Tocantins', 'TOC', 'TO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('136', '1', '44', '0', 'Anhui', 'ANH', '34', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('137', '1', '44', '0', 'Beijing', 'BEI', '11', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('138', '1', '44', '0', 'Chongqing', 'CHO', '50', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('139', '1', '44', '0', 'Fujian', 'FUJ', '35', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('140', '1', '44', '0', 'Gansu', 'GAN', '62', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('141', '1', '44', '0', 'Guangdong', 'GUA', '44', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('142', '1', '44', '0', 'Guangxi Zhuang', 'GUZ', '45', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('143', '1', '44', '0', 'Guizhou', 'GUI', '52', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('144', '1', '44', '0', 'Hainan', 'HAI', '46', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('145', '1', '44', '0', 'Hebei', 'HEB', '13', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('146', '1', '44', '0', 'Heilongjiang', 'HEI', '23', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('147', '1', '44', '0', 'Henan', 'HEN', '41', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('148', '1', '44', '0', 'Hubei', 'HUB', '42', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('149', '1', '44', '0', 'Hunan', 'HUN', '43', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('150', '1', '44', '0', 'Jiangsu', 'JIA', '32', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('151', '1', '44', '0', 'Jiangxi', 'JIX', '36', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('152', '1', '44', '0', 'Jilin', 'JIL', '22', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('153', '1', '44', '0', 'Liaoning', 'LIA', '21', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('154', '1', '44', '0', 'Nei Mongol', 'NML', '15', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('155', '1', '44', '0', 'Ningxia Hui', 'NIH', '64', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('156', '1', '44', '0', 'Qinghai', 'QIN', '63', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('157', '1', '44', '0', 'Shandong', 'SNG', '37', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('158', '1', '44', '0', 'Shanghai', 'SHH', '31', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('159', '1', '44', '0', 'Shaanxi', 'SHX', '61', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('160', '1', '44', '0', 'Sichuan', 'SIC', '51', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('161', '1', '44', '0', 'Tianjin', 'TIA', '12', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('162', '1', '44', '0', 'Xinjiang Uygur', 'XIU', '65', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('163', '1', '44', '0', 'Xizang', 'XIZ', '54', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('164', '1', '44', '0', 'Yunnan', 'YUN', '53', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('165', '1', '44', '0', 'Zhejiang', 'ZHE', '33', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('166', '1', '104', '0', 'Israel', 'ISL', 'IL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('167', '1', '104', '0', 'Gaza Strip', 'GZS', 'GZ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('168', '1', '104', '0', 'West Bank', 'WBK', 'WB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('169', '1', '151', '0', 'St. Maarten', 'STM', 'SM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('170', '1', '151', '0', 'Bonaire', 'BNR', 'BN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('171', '1', '151', '0', 'Curacao', 'CUR', 'CR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('172', '1', '175', '0', 'Alba', 'ABA', 'AB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('173', '1', '175', '0', 'Arad', 'ARD', 'AR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('174', '1', '175', '0', 'Arges', 'ARG', 'AG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('175', '1', '175', '0', 'Bacau', 'BAC', 'BC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('176', '1', '175', '0', 'Bihor', 'BIH', 'BH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('177', '1', '175', '0', 'Bistrita-Nasaud', 'BIS', 'BN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('178', '1', '175', '0', 'Botosani', 'BOT', 'BT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('179', '1', '175', '0', 'Braila', 'BRL', 'BR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('180', '1', '175', '0', 'Brasov', 'BRA', 'BV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('181', '1', '175', '0', 'Bucuresti', 'BUC', 'B', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('182', '1', '175', '0', 'Buzau', 'BUZ', 'BZ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('183', '1', '175', '0', 'Calarasi', 'CAL', 'CL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('184', '1', '175', '0', 'Caras Severin', 'CRS', 'CS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('185', '1', '175', '0', 'Cluj', 'CLJ', 'CJ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('186', '1', '175', '0', 'Constanta', 'CST', 'CT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('187', '1', '175', '0', 'Covasna', 'COV', 'CV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('188', '1', '175', '0', 'Dambovita', 'DAM', 'DB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('189', '1', '175', '0', 'Dolj', 'DLJ', 'DJ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('190', '1', '175', '0', 'Galati', 'GAL', 'GL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('191', '1', '175', '0', 'Giurgiu', 'GIU', 'GR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('192', '1', '175', '0', 'Gorj', 'GOR', 'GJ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('193', '1', '175', '0', 'Hargita', 'HRG', 'HR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('194', '1', '175', '0', 'Hunedoara', 'HUN', 'HD', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('195', '1', '175', '0', 'Ialomita', 'IAL', 'IL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('196', '1', '175', '0', 'Iasi', 'IAS', 'IS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('197', '1', '175', '0', 'Ilfov', 'ILF', 'IF', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('198', '1', '175', '0', 'Maramures', 'MAR', 'MM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('199', '1', '175', '0', 'Mehedinti', 'MEH', 'MH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('200', '1', '175', '0', 'Mures', 'MUR', 'MS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('201', '1', '175', '0', 'Neamt', 'NEM', 'NT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('202', '1', '175', '0', 'Olt', 'OLT', 'OT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('203', '1', '175', '0', 'Prahova', 'PRA', 'PH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('204', '1', '175', '0', 'Salaj', 'SAL', 'SJ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('205', '1', '175', '0', 'Satu Mare', 'SAT', 'SM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('206', '1', '175', '0', 'Sibiu', 'SIB', 'SB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('207', '1', '175', '0', 'Suceava', 'SUC', 'SV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('208', '1', '175', '0', 'Teleorman', 'TEL', 'TR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('209', '1', '175', '0', 'Timis', 'TIM', 'TM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('210', '1', '175', '0', 'Tulcea', 'TUL', 'TL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('211', '1', '175', '0', 'Valcea', 'VAL', 'VL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('212', '1', '175', '0', 'Vaslui', 'VAS', 'VS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('213', '1', '175', '0', 'Vrancea', 'VRA', 'VN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('214', '1', '105', '0', 'Agrigento', 'AGR', 'AG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('215', '1', '105', '0', 'Alessandria', 'ALE', 'AL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('216', '1', '105', '0', 'Ancona', 'ANC', 'AN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('217', '1', '105', '0', 'Aosta', 'AOS', 'AO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('218', '1', '105', '0', 'Arezzo', 'ARE', 'AR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('219', '1', '105', '0', 'Ascoli Piceno', 'API', 'AP', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('220', '1', '105', '0', 'Asti', 'AST', 'AT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('221', '1', '105', '0', 'Avellino', 'AVE', 'AV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('222', '1', '105', '0', 'Bari', 'BAR', 'BA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('223', '1', '105', '0', 'Belluno', 'BEL', 'BL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('224', '1', '105', '0', 'Benevento', 'BEN', 'BN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('225', '1', '105', '0', 'Bergamo', 'BEG', 'BG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('226', '1', '105', '0', 'Biella', 'BIE', 'BI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('227', '1', '105', '0', 'Bologna', 'BOL', 'BO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('228', '1', '105', '0', 'Bolzano', 'BOZ', 'BZ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('229', '1', '105', '0', 'Brescia', 'BRE', 'BS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('230', '1', '105', '0', 'Brindisi', 'BRI', 'BR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('231', '1', '105', '0', 'Cagliari', 'CAG', 'CA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('232', '1', '105', '0', 'Caltanissetta', 'CAL', 'CL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('233', '1', '105', '0', 'Campobasso', 'CBO', 'CB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('234', '1', '105', '0', 'Carbonia-Iglesias', 'CAR', 'CI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('235', '1', '105', '0', 'Caserta', 'CAS', 'CE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('236', '1', '105', '0', 'Catania', 'CAT', 'CT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('237', '1', '105', '0', 'Catanzaro', 'CTZ', 'CZ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('238', '1', '105', '0', 'Chieti', 'CHI', 'CH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('239', '1', '105', '0', 'Como', 'COM', 'CO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('240', '1', '105', '0', 'Cosenza', 'COS', 'CS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('241', '1', '105', '0', 'Cremona', 'CRE', 'CR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('242', '1', '105', '0', 'Crotone', 'CRO', 'KR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('243', '1', '105', '0', 'Cuneo', 'CUN', 'CN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('244', '1', '105', '0', 'Enna', 'ENN', 'EN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('245', '1', '105', '0', 'Ferrara', 'FER', 'FE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('246', '1', '105', '0', 'Firenze', 'FIR', 'FI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('247', '1', '105', '0', 'Foggia', 'FOG', 'FG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('248', '1', '105', '0', 'Forli-Cesena', 'FOC', 'FC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('249', '1', '105', '0', 'Frosinone', 'FRO', 'FR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('250', '1', '105', '0', 'Genova', 'GEN', 'GE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('251', '1', '105', '0', 'Gorizia', 'GOR', 'GO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('252', '1', '105', '0', 'Grosseto', 'GRO', 'GR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('253', '1', '105', '0', 'Imperia', 'IMP', 'IM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('254', '1', '105', '0', 'Isernia', 'ISE', 'IS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('255', '1', '105', '0', 'L\'Aquila', 'AQU', 'AQ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('256', '1', '105', '0', 'La Spezia', 'LAS', 'SP', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('257', '1', '105', '0', 'Latina', 'LAT', 'LT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('258', '1', '105', '0', 'Lecce', 'LEC', 'LE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('259', '1', '105', '0', 'Lecco', 'LCC', 'LC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('260', '1', '105', '0', 'Livorno', 'LIV', 'LI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('261', '1', '105', '0', 'Lodi', 'LOD', 'LO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('262', '1', '105', '0', 'Lucca', 'LUC', 'LU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('263', '1', '105', '0', 'Macerata', 'MAC', 'MC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('264', '1', '105', '0', 'Mantova', 'MAN', 'MN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('265', '1', '105', '0', 'Massa-Carrara', 'MAS', 'MS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('266', '1', '105', '0', 'Matera', 'MAA', 'MT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('267', '1', '105', '0', 'Medio Campidano', 'MED', 'VS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('268', '1', '105', '0', 'Messina', 'MES', 'ME', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('269', '1', '105', '0', 'Milano', 'MIL', 'MI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('270', '1', '105', '0', 'Modena', 'MOD', 'MO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('271', '1', '105', '0', 'Napoli', 'NAP', 'NA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('272', '1', '105', '0', 'Novara', 'NOV', 'NO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('273', '1', '105', '0', 'Nuoro', 'NUR', 'NU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('274', '1', '105', '0', 'Ogliastra', 'OGL', 'OG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('275', '1', '105', '0', 'Olbia-Tempio', 'OLB', 'OT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('276', '1', '105', '0', 'Oristano', 'ORI', 'OR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('277', '1', '105', '0', 'Padova', 'PDA', 'PD', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('278', '1', '105', '0', 'Palermo', 'PAL', 'PA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('279', '1', '105', '0', 'Parma', 'PAA', 'PR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('280', '1', '105', '0', 'Pavia', 'PAV', 'PV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('281', '1', '105', '0', 'Perugia', 'PER', 'PG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('282', '1', '105', '0', 'Pesaro e Urbino', 'PES', 'PU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('283', '1', '105', '0', 'Pescara', 'PSC', 'PE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('284', '1', '105', '0', 'Piacenza', 'PIA', 'PC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('285', '1', '105', '0', 'Pisa', 'PIS', 'PI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('286', '1', '105', '0', 'Pistoia', 'PIT', 'PT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('287', '1', '105', '0', 'Pordenone', 'POR', 'PN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('288', '1', '105', '0', 'Potenza', 'PTZ', 'PZ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('289', '1', '105', '0', 'Prato', 'PRA', 'PO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('290', '1', '105', '0', 'Ragusa', 'RAG', 'RG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('291', '1', '105', '0', 'Ravenna', 'RAV', 'RA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('292', '1', '105', '0', 'Reggio Calabria', 'REG', 'RC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('293', '1', '105', '0', 'Reggio Emilia', 'REE', 'RE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('294', '1', '105', '0', 'Rieti', 'RIE', 'RI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('295', '1', '105', '0', 'Rimini', 'RIM', 'RN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('296', '1', '105', '0', 'Roma', 'ROM', 'RM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('297', '1', '105', '0', 'Rovigo', 'ROV', 'RO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('298', '1', '105', '0', 'Salerno', 'SAL', 'SA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('299', '1', '105', '0', 'Sassari', 'SAS', 'SS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('300', '1', '105', '0', 'Savona', 'SAV', 'SV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('301', '1', '105', '0', 'Siena', 'SIE', 'SI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('302', '1', '105', '0', 'Siracusa', 'SIR', 'SR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('303', '1', '105', '0', 'Sondrio', 'SOO', 'SO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('304', '1', '105', '0', 'Taranto', 'TAR', 'TA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('305', '1', '105', '0', 'Teramo', 'TER', 'TE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('306', '1', '105', '0', 'Terni', 'TRN', 'TR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('307', '1', '105', '0', 'Torino', 'TOR', 'TO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('308', '1', '105', '0', 'Trapani', 'TRA', 'TP', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('309', '1', '105', '0', 'Trento', 'TRE', 'TN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('310', '1', '105', '0', 'Treviso', 'TRV', 'TV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('311', '1', '105', '0', 'Trieste', 'TRI', 'TS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('312', '1', '105', '0', 'Udine', 'UDI', 'UD', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('313', '1', '105', '0', 'Varese', 'VAR', 'VA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('314', '1', '105', '0', 'Venezia', 'VEN', 'VE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('315', '1', '105', '0', 'Verbano Cusio Ossola', 'VCO', 'VB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('316', '1', '105', '0', 'Vercelli', 'VER', 'VC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('317', '1', '105', '0', 'Verona', 'VRN', 'VR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('318', '1', '105', '0', 'Vibo Valenzia', 'VIV', 'VV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('319', '1', '105', '0', 'Vicenza', 'VII', 'VI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('320', '1', '105', '0', 'Viterbo', 'VIT', 'VT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('321', '1', '195', '0', 'A Coru', 'ACO', '15', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('322', '1', '195', '0', 'Alava', 'ALA', '01', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('323', '1', '195', '0', 'Albacete', 'ALB', '02', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('324', '1', '195', '0', 'Alicante', 'ALI', '03', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('325', '1', '195', '0', 'Almeria', 'ALM', '04', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('326', '1', '195', '0', 'Asturias', 'AST', '33', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('327', '1', '195', '0', 'Avila', 'AVI', '05', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('328', '1', '195', '0', 'Badajoz', 'BAD', '06', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('329', '1', '195', '0', 'Baleares', 'BAL', '07', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('330', '1', '195', '0', 'Barcelona', 'BAR', '08', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('331', '1', '195', '0', 'Burgos', 'BUR', '09', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('332', '1', '195', '0', 'Caceres', 'CAC', '10', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('333', '1', '195', '0', 'Cadiz', 'CAD', '11', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('334', '1', '195', '0', 'Cantabria', 'CAN', '39', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('335', '1', '195', '0', 'Castellon', 'CAS', '12', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('336', '1', '195', '0', 'Ceuta', 'CEU', '51', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('337', '1', '195', '0', 'Ciudad Real', 'CIU', '13', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('338', '1', '195', '0', 'Cordoba', 'COR', '14', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('339', '1', '195', '0', 'Cuenca', 'CUE', '16', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('340', '1', '195', '0', 'Girona', 'GIR', '17', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('341', '1', '195', '0', 'Granada', 'GRA', '18', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('342', '1', '195', '0', 'Guadalajara', 'GUA', '19', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('343', '1', '195', '0', 'Guipuzcoa', 'GUI', '20', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('344', '1', '195', '0', 'Huelva', 'HUL', '21', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('345', '1', '195', '0', 'Huesca', 'HUS', '22', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('346', '1', '195', '0', 'Jaen', 'JAE', '23', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('347', '1', '195', '0', 'La Rioja', 'LRI', '26', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('348', '1', '195', '0', 'Las Palmas', 'LPA', '35', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('349', '1', '195', '0', 'Leon', 'LEO', '24', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('350', '1', '195', '0', 'Lleida', 'LLE', '25', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('351', '1', '195', '0', 'Lugo', 'LUG', '27', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('352', '1', '195', '0', 'Madrid', 'MAD', '28', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('353', '1', '195', '0', 'Malaga', 'MAL', '29', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('354', '1', '195', '0', 'Melilla', 'MEL', '52', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('355', '1', '195', '0', 'Murcia', 'MUR', '30', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('356', '1', '195', '0', 'Navarra', 'NAV', '31', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('357', '1', '195', '0', 'Ourense', 'OUR', '32', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('358', '1', '195', '0', 'Palencia', 'PAL', '34', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('359', '1', '195', '0', 'Pontevedra', 'PON', '36', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('360', '1', '195', '0', 'Salamanca', 'SAL', '37', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('361', '1', '195', '0', 'Santa Cruz de Tenerife', 'SCT', '38', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('362', '1', '195', '0', 'Segovia', 'SEG', '40', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('363', '1', '195', '0', 'Sevilla', 'SEV', '41', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('364', '1', '195', '0', 'Soria', 'SOR', '42', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('365', '1', '195', '0', 'Tarragona', 'TAR', '43', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('366', '1', '195', '0', 'Teruel', 'TER', '44', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('367', '1', '195', '0', 'Toledo', 'TOL', '45', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('368', '1', '195', '0', 'Valencia', 'VAL', '46', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('369', '1', '195', '0', 'Valladolid', 'VLL', '47', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('370', '1', '195', '0', 'Vizcaya', 'VIZ', '48', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('371', '1', '195', '0', 'Zamora', 'ZAM', '49', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('372', '1', '195', '0', 'Zaragoza', 'ZAR', '50', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('373', '1', '10', '0', 'Buenos Aires', 'BAS', 'BA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('374', '1', '10', '0', 'Ciudad Autonoma De Buenos Aires', 'CBA', 'CB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('375', '1', '10', '0', 'Catamarca', 'CAT', 'CA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('376', '1', '10', '0', 'Chaco', 'CHO', 'CH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('377', '1', '10', '0', 'Chubut', 'CTT', 'CT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('378', '1', '10', '0', 'Cordoba', 'COD', 'CO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('379', '1', '10', '0', 'Corrientes', 'CRI', 'CR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('380', '1', '10', '0', 'Entre Rios', 'ERS', 'ER', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('381', '1', '10', '0', 'Formosa', 'FRM', 'FR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('382', '1', '10', '0', 'Jujuy', 'JUJ', 'JU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('383', '1', '10', '0', 'La Pampa', 'LPM', 'LP', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('384', '1', '10', '0', 'La Rioja', 'LRI', 'LR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('385', '1', '10', '0', 'Mendoza', 'MED', 'ME', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('386', '1', '10', '0', 'Misiones', 'MIS', 'MI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('387', '1', '10', '0', 'Neuquen', 'NQU', 'NQ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('388', '1', '10', '0', 'Rio Negro', 'RNG', 'RN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('389', '1', '10', '0', 'Salta', 'SAL', 'SA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('390', '1', '10', '0', 'San Juan', 'SJN', 'SJ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('391', '1', '10', '0', 'San Luis', 'SLU', 'SL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('392', '1', '10', '0', 'Santa Cruz', 'SCZ', 'SC', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('393', '1', '10', '0', 'Santa Fe', 'SFE', 'SF', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('394', '1', '10', '0', 'Santiago Del Estero', 'SEN', 'SE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('395', '1', '10', '0', 'Tierra Del Fuego', 'TFE', 'TF', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('396', '1', '10', '0', 'Tucuman', 'TUC', 'TU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('397', '1', '11', '0', 'Aragatsotn', 'ARG', 'AG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('398', '1', '11', '0', 'Ararat', 'ARR', 'AR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('399', '1', '11', '0', 'Armavir', 'ARM', 'AV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('400', '1', '11', '0', 'Gegharkunik', 'GEG', 'GR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('401', '1', '11', '0', 'Kotayk', 'KOT', 'KT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('402', '1', '11', '0', 'Lori', 'LOR', 'LO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('403', '1', '11', '0', 'Shirak', 'SHI', 'SH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('404', '1', '11', '0', 'Syunik', 'SYU', 'SU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('405', '1', '11', '0', 'Tavush', 'TAV', 'TV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('406', '1', '11', '0', 'Vayots-Dzor', 'VAD', 'VD', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('407', '1', '11', '0', 'Yerevan', 'YER', 'ER', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('408', '1', '99', '0', 'Andaman & Nicobar Islands', 'ANI', 'AI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('409', '1', '99', '0', 'Andhra Pradesh', 'AND', 'AN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('410', '1', '99', '0', 'Arunachal Pradesh', 'ARU', 'AR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('411', '1', '99', '0', 'Assam', 'ASS', 'AS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('412', '1', '99', '0', 'Bihar', 'BIH', 'BI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('413', '1', '99', '0', 'Chandigarh', 'CHA', 'CA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('414', '1', '99', '0', 'Chhatisgarh', 'CHH', 'CH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('415', '1', '99', '0', 'Dadra & Nagar Haveli', 'DAD', 'DD', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('416', '1', '99', '0', 'Daman & Diu', 'DAM', 'DA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('417', '1', '99', '0', 'Delhi', 'DEL', 'DE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('418', '1', '99', '0', 'Goa', 'GOA', 'GO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('419', '1', '99', '0', 'Gujarat', 'GUJ', 'GU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('420', '1', '99', '0', 'Haryana', 'HAR', 'HA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('421', '1', '99', '0', 'Himachal Pradesh', 'HIM', 'HI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('422', '1', '99', '0', 'Jammu & Kashmir', 'JAM', 'JA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('423', '1', '99', '0', 'Jharkhand', 'JHA', 'JH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('424', '1', '99', '0', 'Karnataka', 'KAR', 'KA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('425', '1', '99', '0', 'Kerala', 'KER', 'KE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('426', '1', '99', '0', 'Lakshadweep', 'LAK', 'LA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('427', '1', '99', '0', 'Madhya Pradesh', 'MAD', 'MD', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('428', '1', '99', '0', 'Maharashtra', 'MAH', 'MH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('429', '1', '99', '0', 'Manipur', 'MAN', 'MN', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('430', '1', '99', '0', 'Meghalaya', 'MEG', 'ME', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('431', '1', '99', '0', 'Mizoram', 'MIZ', 'MI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('432', '1', '99', '0', 'Nagaland', 'NAG', 'NA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('433', '1', '99', '0', 'Orissa', 'ORI', 'OR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('434', '1', '99', '0', 'Pondicherry', 'PON', 'PO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('435', '1', '99', '0', 'Punjab', 'PUN', 'PU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('436', '1', '99', '0', 'Rajasthan', 'RAJ', 'RA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('437', '1', '99', '0', 'Sikkim', 'SIK', 'SI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('438', '1', '99', '0', 'Tamil Nadu', 'TAM', 'TA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('439', '1', '99', '0', 'Tripura', 'TRI', 'TR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('440', '1', '99', '0', 'Uttaranchal', 'UAR', 'UA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('441', '1', '99', '0', 'Uttar Pradesh', 'UTT', 'UT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('442', '1', '99', '0', 'West Bengal', 'WES', 'WE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('443', '1', '101', '0', 'Ahmadi va Kohkiluyeh', 'BOK', 'BO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('444', '1', '101', '0', 'Ardabil', 'ARD', 'AR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('445', '1', '101', '0', 'Azarbayjan-e Gharbi', 'AZG', 'AG', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('446', '1', '101', '0', 'Azarbayjan-e Sharqi', 'AZS', 'AS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('447', '1', '101', '0', 'Bushehr', 'BUS', 'BU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('448', '1', '101', '0', 'Chaharmahal va Bakhtiari', 'CMB', 'CM', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('449', '1', '101', '0', 'Esfahan', 'ESF', 'ES', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('450', '1', '101', '0', 'Fars', 'FAR', 'FA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('451', '1', '101', '0', 'Gilan', 'GIL', 'GI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('452', '1', '101', '0', 'Gorgan', 'GOR', 'GO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('453', '1', '101', '0', 'Hamadan', 'HAM', 'HA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('454', '1', '101', '0', 'Hormozgan', 'HOR', 'HO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('455', '1', '101', '0', 'Ilam', 'ILA', 'IL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('456', '1', '101', '0', 'Kerman', 'KER', 'KE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('457', '1', '101', '0', 'Kermanshah', 'BAK', 'BA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('458', '1', '101', '0', 'Khorasan-e Junoubi', 'KHJ', 'KJ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('459', '1', '101', '0', 'Khorasan-e Razavi', 'KHR', 'KR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('460', '1', '101', '0', 'Khorasan-e Shomali', 'KHS', 'KS', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('461', '1', '101', '0', 'Khuzestan', 'KHU', 'KH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('462', '1', '101', '0', 'Kordestan', 'KOR', 'KO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('463', '1', '101', '0', 'Lorestan', 'LOR', 'LO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('464', '1', '101', '0', 'Markazi', 'MAR', 'MR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('465', '1', '101', '0', 'Mazandaran', 'MAZ', 'MZ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('466', '1', '101', '0', 'Qazvin', 'QAS', 'QA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('467', '1', '101', '0', 'Qom', 'QOM', 'QO', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('468', '1', '101', '0', 'Semnan', 'SEM', 'SE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('469', '1', '101', '0', 'Sistan va Baluchestan', 'SBA', 'SB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('470', '1', '101', '0', 'Tehran', 'TEH', 'TE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('471', '1', '101', '0', 'Yazd', 'YAZ', 'YA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('472', '1', '101', '0', 'Zanjan', 'ZAN', 'ZA', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('535', '1', '84', '0', 'ΛΕΥΚΑΔΑΣ', 'ΛΕΥ', 'ΛΕ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('532', '1', '84', '0', 'ΛΑΡΙΣΑΣ', 'ΛΑΡ', 'ΛΡ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('504', '1', '84', '0', 'ΑΡΚΑΔΙΑΣ', 'ΑΡΚ', 'ΑΚ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('503', '1', '84', '0', 'ΑΡΓΟΛΙΔΑΣ', 'ΑΡΓ', 'ΑΡ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('533', '1', '84', '0', 'ΛΑΣΙΘΙΟΥ', 'ΛΑΣ', 'ΛΑ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('534', '1', '84', '0', 'ΛΕΣΒΟΥ', 'ΛΕΣ', 'ΛΣ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('530', '1', '84', '0', 'ΚΥΚΛΑΔΩΝ', 'ΚΥΚ', 'ΚΥ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('553', '1', '84', '0', 'ΑΙΤΩΛΟΑΚΑΡΝΑΝΙΑΣ', 'ΑΙΤ', 'ΑΙ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('529', '1', '84', '0', 'ΚΟΡΙΝΘΙΑΣ', 'ΚΟΡ', 'ΚΟ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('531', '1', '84', '0', 'ΛΑΚΩΝΙΑΣ', 'ΛΑΚ', 'ΛK', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('517', '1', '84', '0', 'ΗΜΑΘΙΑΣ', 'ΗΜΑ', 'ΗΜ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('518', '1', '84', '0', 'ΗΡΑΚΛΕΙΟΥ', 'ΗΡΑ', 'ΗΡ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('519', '1', '84', '0', 'ΘΕΣΠΡΩΤΙΑΣ', 'ΘΕΠ', 'ΘΠ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('520', '1', '84', '0', 'ΘΕΣΣΑΛΟΝΙΚΗΣ', 'ΘΕΣ', 'ΘΕ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('521', '1', '84', '0', 'ΙΩΑΝΝΙΝΩΝ', 'ΙΩΑ', 'ΙΩ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('522', '1', '84', '0', 'ΚΑΒΑΛΑΣ', 'ΚΑΒ', 'ΚΒ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('523', '1', '84', '0', 'ΚΑΡΔΙΤΣΑΣ', 'ΚΑΡ', 'ΚΡ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('524', '1', '84', '0', 'ΚΑΣΤΟΡΙΑΣ', 'ΚΑΣ', 'ΚΣ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('525', '1', '84', '0', 'ΚΕΡΚΥΡΑΣ', 'ΚΕΡ', 'ΚΕ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('526', '1', '84', '0', 'ΚΕΦΑΛΛΗΝΙΑΣ', 'ΚΕΦ', 'ΚΦ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('527', '1', '84', '0', 'ΚΙΛΚΙΣ', 'ΚΙΛ', 'ΚΙ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('528', '1', '84', '0', 'ΚΟΖΑΝΗΣ', 'ΚΟΖ', 'ΚZ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('507', '1', '84', '0', 'ΑΧΑΪΑΣ', 'ΑΧΑ', 'ΑΧ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('508', '1', '84', '0', 'ΒΟΙΩΤΙΑΣ', 'ΒΟΙ', 'ΒΟ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('509', '1', '84', '0', 'ΓΡΕΒΕΝΩΝ', 'ΓΡΕ', 'ΓΡ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('510', '1', '84', '0', 'ΔΡΑΜΑΣ', 'ΔΡΑ', 'ΔΡ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('511', '1', '84', '0', 'ΔΩΔΕΚΑΝΗΣΟΥ', 'ΔΩΔ', 'ΔΩ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('512', '1', '84', '0', 'ΕΒΡΟΥ', 'ΕΒΡ', 'ΕΒ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('513', '1', '84', '0', 'ΕΥΒΟΙΑΣ', 'ΕΥΒ', 'ΕΥ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('514', '1', '84', '0', 'ΕΥΡΥΤΑΝΙΑΣ', 'ΕΥΡ', 'ΕΡ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('515', '1', '84', '0', 'ΖΑΚΥΝΘΟΥ', 'ΖΑΚ', 'ΖΑ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('516', '1', '84', '0', 'ΗΛΕΙΑΣ', 'ΗΛΕ', 'ΗΛ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('505', '1', '84', '0', 'ΑΡΤΑΣ', 'ΑΡΤ', 'ΑΑ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('506', '1', '84', '0', 'ΑΤΤΙΚΗΣ', 'ΑΤΤ', 'ΑΤ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('536', '1', '84', '0', 'ΜΑΓΝΗΣΙΑΣ', 'ΜΑΓ', 'ΜΑ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('537', '1', '84', '0', 'ΜΕΣΣΗΝΙΑΣ', 'ΜΕΣ', 'ΜΕ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('538', '1', '84', '0', 'ΞΑΝΘΗΣ', 'ΞΑΝ', 'ΞΑ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('539', '1', '84', '0', 'ΠΕΛΛΗΣ', 'ΠΕΛ', 'ΠΕ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('540', '1', '84', '0', 'ΠΙΕΡΙΑΣ', 'ΠΙΕ', 'ΠΙ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('541', '1', '84', '0', 'ΠΡΕΒΕΖΑΣ', 'ΠΡΕ', 'ΠΡ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('542', '1', '84', '0', 'ΡΕΘΥΜΝΗΣ', 'ΡΕΘ', 'ΡΕ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('543', '1', '84', '0', 'ΡΟΔΟΠΗΣ', 'ΡΟΔ', 'ΡΟ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('544', '1', '84', '0', 'ΣΑΜΟΥ', 'ΣΑΜ', 'ΣΑ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('545', '1', '84', '0', 'ΣΕΡΡΩΝ', 'ΣΕΡ', 'ΣΕ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('546', '1', '84', '0', 'ΤΡΙΚΑΛΩΝ', 'ΤΡΙ', 'ΤΡ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('547', '1', '84', '0', 'ΦΘΙΩΤΙΔΑΣ', 'ΦΘΙ', 'ΦΘ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('548', '1', '84', '0', 'ΦΛΩΡΙΝΑΣ', 'ΦΛΩ', 'ΦΛ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('549', '1', '84', '0', 'ΦΩΚΙΔΑΣ', 'ΦΩΚ', 'ΦΩ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('550', '1', '84', '0', 'ΧΑΛΚΙΔΙΚΗΣ', 'ΧΑΛ', 'ΧΑ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('551', '1', '84', '0', 'ΧΑΝΙΩΝ', 'ΧΑΝ', 'ΧΝ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('552', '1', '84', '0', 'ΧΙΟΥ', 'ΧΙΟ', 'ΧΙ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('569', '1', '81', '0', 'Schleswig-Holstein', 'SHO', 'SH', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('554', '1', '81', '0', 'Freie und Hansestadt Hamburg', 'HAM', 'HH', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('555', '1', '81', '0', 'Niedersachsen', 'NIS', 'NI', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('556', '1', '81', '0', 'Freie Hansestadt Bremen', 'HBR', 'HB', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('557', '1', '81', '0', 'Nordrhein-Westfalen', 'NRW', 'NW', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('558', '1', '81', '0', 'Hessen', 'HES', 'HE', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('559', '1', '81', '0', 'Rheinland-Pfalz', 'RLP', 'RP', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('560', '1', '81', '0', 'Baden-Württemberg', 'BWÜ', 'BW', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('561', '1', '81', '0', 'Freistaat Bayern', 'BAV', 'BY', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('562', '1', '81', '0', 'Saarland', 'SLA', 'SL', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('563', '1', '81', '0', 'Berlin', 'BER', 'BE', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('564', '1', '81', '0', 'Brandenburg', 'BRB', 'BB', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('565', '1', '81', '0', 'Mecklenburg-Vorpommern', 'MVO', 'MV', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('566', '1', '81', '0', 'Freistaat Sachsen', 'SAC', 'SN', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('567', '1', '81', '0', 'Sachsen-Anhalt', 'SAA', 'ST', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('568', '1', '81', '0', 'Freistaat Thüringen', 'THÜ', 'TH', '0', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('570', '1', '176', '0', 'Адыгея Республика', 'AD', '01', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('571', '1', '176', '0', 'Алтай Республика', 'AL', '04', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('572', '1', '176', '0', 'Алтайский край', 'ALT', '22', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('573', '1', '176', '0', 'Амурская область', 'AMU', '28', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('574', '1', '176', '0', 'Архангельская область', 'ARK', '29', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('575', '1', '176', '0', 'Астраханская область', 'AST', '30', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('576', '1', '176', '0', 'Башкортостан Республика', 'BA', '02', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('577', '1', '176', '0', 'Белгородская область', 'BEL', '31', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('578', '1', '176', '0', 'Брянская область', 'BRY', '32', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('579', '1', '176', '0', 'Бурятия Республика', 'BU', '03', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('580', '1', '176', '0', 'Владимирская область', 'VLA', '33', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('581', '1', '176', '0', 'Волгоградская область', 'VGG', '34', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('582', '1', '176', '0', 'Вологодская область', 'VLG', '35', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('583', '1', '176', '0', 'Воронежская область', 'VOR', '36', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('584', '1', '176', '0', 'Дагестан Республика', 'DA', '05', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('585', '1', '176', '0', 'Еврейская автономная область', 'YEV', '79', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('586', '1', '176', '0', 'Забайкальский край', 'ZAB', '75', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('587', '1', '176', '0', 'Ивановская область', 'IVA', '37', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('588', '1', '176', '0', 'Ингушетия Республика', 'IN', '06', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('589', '1', '176', '0', 'Иркутская область', 'IRK', '38', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('590', '1', '176', '0', 'Кабардино-Балкарская Республика', 'KB', '07', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('591', '1', '176', '0', 'Калининградская область', 'KGD', '39', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('592', '1', '176', '0', 'Калмыкия Республика', 'KL', '08', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('593', '1', '176', '0', 'Калужская область', 'KLU', '40', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('594', '1', '176', '0', 'Камчатский край', 'KAM', '41', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('595', '1', '176', '0', 'Карачаево-Черкесская Республика', 'KC', '09', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('596', '1', '176', '0', 'Карелия Республика', 'KR', '10', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('597', '1', '176', '0', 'Кемеровская область', 'KEM', '42', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('598', '1', '176', '0', 'Кировская область', 'KIR', '43', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('599', '1', '176', '0', 'Коми Республика', 'KO', '11', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('600', '1', '176', '0', 'Костромская область', 'KOS', '44', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('601', '1', '176', '0', 'Краснодарский край', 'KDA', '23', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('602', '1', '176', '0', 'Красноярский край', 'KIA', '24', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('603', '1', '176', '0', 'Курганская область', 'KGN', '45', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('604', '1', '176', '0', 'Курская область', 'KRS', '46', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('605', '1', '176', '0', 'Ленинградская область', 'LEN', '47', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('606', '1', '176', '0', 'Липецкая область', 'LIP', '48', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('607', '1', '176', '0', 'Магаданская область', 'MAG', '49', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('608', '1', '176', '0', 'Марий Эл Республика', 'ME', '12', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('609', '1', '176', '0', 'Мордовия Республика', 'MO', '13', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('610', '1', '176', '0', 'Москва', 'MOW', '77', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('611', '1', '176', '0', 'Московская область', 'MOS', '50', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('612', '1', '176', '0', 'Мурманская область', 'MUR', '51', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('613', '1', '176', '0', 'Ненецкий автономный округ', 'NEN', '83', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('614', '1', '176', '0', 'Нижегородская область', 'NIZ', '52', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('615', '1', '176', '0', 'Новгородская область', 'NGR', '53', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('616', '1', '176', '0', 'Новосибирская область', 'NVS', '54', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('617', '1', '176', '0', 'Омская область', 'OMS', '55', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('618', '1', '176', '0', 'Оренбургская область', 'ORE', '56', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('619', '1', '176', '0', 'Орловская область', 'ORL', '57', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('620', '1', '176', '0', 'Пензенская область', 'PNZ', '58', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('621', '1', '176', '0', 'Пермский край', 'PER', '59', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('622', '1', '176', '0', 'Приморский край', 'PRI', '25', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('623', '1', '176', '0', 'Псковская область', 'PSK', '60', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('624', '1', '176', '0', 'Ростовская область', 'ROS', '61', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('625', '1', '176', '0', 'Рязанская область', 'RYA', '62', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('626', '1', '176', '0', 'Самарская область', 'SAM', '63', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('627', '1', '176', '0', 'Санкт-Петербург', 'SPE', '78', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('628', '1', '176', '0', 'Саратовская область', 'SAR', '64', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('629', '1', '176', '0', 'Саха (Якутия) Республика', 'SA', '14', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('630', '1', '176', '0', 'Сахалинская область', 'SAK', '65', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('631', '1', '176', '0', 'Свердловская область', 'SVE', '66', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('632', '1', '176', '0', 'Северная Осетия-Алания Республика', 'SE', '15', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('633', '1', '176', '0', 'Смоленская область', 'SMO', '67', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('634', '1', '176', '0', 'Ставропольский край', 'STA', '26', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('635', '1', '176', '0', 'Тамбовская область', 'TAM', '68', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('636', '1', '176', '0', 'Татарстан Республика', 'TA', '16', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('637', '1', '176', '0', 'Тверская область', 'TVE', '69', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('638', '1', '176', '0', 'Томская область', 'TOM', '70', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('639', '1', '176', '0', 'Тульская область', 'TUL', '71', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('640', '1', '176', '0', 'Тыва Республика', 'TY', '17', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('641', '1', '176', '0', 'Тюменская область', 'TYU', '72', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('642', '1', '176', '0', 'Удмуртская Республика', 'UD', '18', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('643', '1', '176', '0', 'Ульяновская область', 'ULY', '73', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('644', '1', '176', '0', 'Хакасия Республика', 'KK', '19', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('645', '1', '176', '0', 'Челябинская область', 'CHE', '74', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('646', '1', '176', '0', 'Чеченская Республика', 'CE', '20', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('647', '1', '176', '0', 'Чувашская Республика', 'CU', '21', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('648', '1', '176', '0', 'Чукотский автономный округ', 'CHU', '87', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('649', '1', '176', '0', 'Хабаровский край', 'KHA', '27', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('650', '1', '176', '0', 'Ханты-Мансийский автономный округ', 'KHM', '86', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('651', '1', '176', '0', 'Ямало-Ненецкий автономный округ', 'YAN', '89', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('652', '1', '176', '0', 'Ярославская область', 'YAR', '76', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('653', '1', '209', '0', 'กระบี่', 'กบ', 'กบ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('654', '1', '209', '0', 'กรุงเทพมหานคร', 'กทม', 'กท', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('655', '1', '209', '0', 'กาญจนบุรี', 'กจ', 'กจ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('656', '1', '209', '0', 'กาฬสินธุ์', 'กส', 'กส', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('657', '1', '209', '0', 'กำแพงเพชร', 'กพ', 'กพ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('658', '1', '209', '0', 'ขอนแก่น', 'ขก', 'ขก', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('659', '1', '209', '0', 'จันทบุรี', 'จบ', 'จบ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('660', '1', '209', '0', 'ฉะเชิงเทรา', 'ฉช', 'ฉช', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('661', '1', '209', '0', 'ชลบุรี', 'ชบ', 'ชบ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('662', '1', '209', '0', 'ชัยนาท', 'ชน', 'ชน', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('663', '1', '209', '0', 'ชัยภูมิ', 'ชย', 'ชย', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('664', '1', '209', '0', 'ชุมพร', 'ชพ', 'ชพ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('665', '1', '209', '0', 'เชียงราย', 'ชร', 'ชร', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('666', '1', '209', '0', 'เชียงใหม่', 'ชม', 'ชม', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('667', '1', '209', '0', 'ตรัง', 'ตง', 'ตง', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('668', '1', '209', '0', 'ตราด', 'ตร', 'ตร', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('669', '1', '209', '0', 'ตาก', 'ตก', 'ตก', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('670', '1', '209', '0', 'นครนายก', 'นย', 'นย', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('671', '1', '209', '0', 'นครปฐม', 'นฐ', 'นฐ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('672', '1', '209', '0', 'นครพนม', 'นพ', 'นพ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('673', '1', '209', '0', 'นครราชสีมา', 'นม', 'นม', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('674', '1', '209', '0', 'นครศรีธรรมราช', 'นศ', 'นศ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('675', '1', '209', '0', 'นครสวรรค์', 'นว', 'นว', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('676', '1', '209', '0', 'นนทบุรี', 'นบ', 'นบ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('677', '1', '209', '0', 'นราธิวาส', 'นธ', 'นธ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('678', '1', '209', '0', 'น่าน', 'นน', 'นน', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('679', '1', '209', '0', 'บุรีรัมย์', 'บร', 'บร', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('680', '1', '209', '0', 'บึงกาฬ', 'บก', 'บก', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('681', '1', '209', '0', 'ปทุมธานี', 'ปท', 'ปท', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('682', '1', '209', '0', 'ประจวบคีรีขันธ์', 'ปข', 'ปข', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('683', '1', '209', '0', 'ปราจีนบุรี', 'ปจ', 'ปจ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('684', '1', '209', '0', 'ปัตตานี', 'ปน', 'ปน', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('685', '1', '209', '0', 'พระนครศรีอยุธยา', 'อย', 'อย', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('686', '1', '209', '0', 'พังงา', 'พง', 'พง', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('687', '1', '209', '0', 'พัทลุง', 'พท', 'พท', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('688', '1', '209', '0', 'พิจิตร', 'พจ', 'พจ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('689', '1', '209', '0', 'พิษณุโลก', 'พล', 'พล', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('690', '1', '209', '0', 'เพชรบุรี', 'พบ', 'พบ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('691', '1', '209', '0', 'เพชรบูรณ์', 'พช', 'พช', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('692', '1', '209', '0', 'แพร่', 'พร', 'พร', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('693', '1', '209', '0', 'พะเยา', 'พย', 'พย', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('694', '1', '209', '0', 'ภูเก็ต', 'ภก', 'ภก', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('695', '1', '209', '0', 'มหาสารคาม', 'มค', 'มค', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('696', '1', '209', '0', 'แม่ฮ่องสอน', 'มส', 'มส', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('697', '1', '209', '0', 'มุกดาหาร', 'มห', 'มห', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('698', '1', '209', '0', 'ยะลา', 'ยล', 'ยล', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('699', '1', '209', '0', 'ยโสธร', 'ยส', 'ยส', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('700', '1', '209', '0', 'ร้อยเอ็ด', 'รอ', 'รอ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('701', '1', '209', '0', 'ระนอง', 'รน', 'รน', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('702', '1', '209', '0', 'ระยอง', 'รย', 'รย', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('703', '1', '209', '0', 'ราชบุรี', 'รบ', 'รบ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('704', '1', '209', '0', 'ลพบุรี', 'ลบ', 'ลบ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('705', '1', '209', '0', 'ลำปาง', 'ลป', 'ลป', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('706', '1', '209', '0', 'ลำพูน', 'ลพ', 'ลพ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('707', '1', '209', '0', 'เลย', 'ลย', 'ลย', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('708', '1', '209', '0', 'ศรีสะเกษ', 'ศก', 'ศก', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('709', '1', '209', '0', 'สกลนคร', 'สน', 'สน', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('710', '1', '209', '0', 'สงขลา', 'สข', 'สข', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('711', '1', '209', '0', 'สตูล', 'สต', 'สต', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('712', '1', '209', '0', 'สมุทรปราการ', 'สป', 'สป', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('713', '1', '209', '0', 'สมุทรสงคราม', 'สส', 'สส', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('714', '1', '209', '0', 'สมุทรสาคร', 'สค', 'สค', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('715', '1', '209', '0', 'สระบุรี', 'สบ', 'สบ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('716', '1', '209', '0', 'สระแก้ว', 'สก', 'สก', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('717', '1', '209', '0', 'สิงห์บุรี', 'สห', 'สห', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('718', '1', '209', '0', 'สุโขทัย', 'สท', 'สท', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('719', '1', '209', '0', 'สุพรรณบุรี', 'สพ', 'สพ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('720', '1', '209', '0', 'สุราษฎร์ธานี', 'สฎ', 'สฎ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('721', '1', '209', '0', 'สุรินทร์', 'สร', 'สร', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('722', '1', '209', '0', 'หนองคาย', 'นค', 'นค', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('723', '1', '209', '0', 'หนองบัวลำภู', 'นภ', 'นภ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('724', '1', '209', '0', 'อ่างทอง', 'อท', 'อท', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('725', '1', '209', '0', 'อุดรธานี', 'อด', 'อด', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('726', '1', '209', '0', 'อุตรดิตถ์', 'อต', 'อต', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('727', '1', '209', '0', 'อุทัยธานี', 'อน', 'อน', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('728', '1', '209', '0', 'อุบลราชธานี', 'อบ', 'อบ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('729', '1', '209', '0', 'อำนาจเจริญ', 'อจ', 'อจ', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('730', '1', '150', '0', 'Drenthe', 'DR', 'DR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('731', '1', '150', '0', 'Flevoland', 'FLV', 'FL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('732', '1', '150', '0', 'Friesland', 'FR', 'FR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('733', '1', '150', '0', 'Gelderland', 'GLD', 'GL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('734', '1', '150', '0', 'Groningen', 'GR', 'GR', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('735', '1', '150', '0', 'Limburg', 'LB', 'LB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('736', '1', '150', '0', 'Noord-Brabant', 'NB', 'NB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('737', '1', '150', '0', 'Noord-Holland', 'NH', 'NH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('738', '1', '150', '0', 'Overijssel', 'OVR', 'OV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('739', '1', '150', '0', 'Utrecht', 'UT', 'UT', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('740', '1', '150', '0', 'Zuid-Holland', 'ZH', 'ZH', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('741', '1', '150', '0', 'Zeeland', 'ZL', 'ZL', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('742', '1', '21', '0', 'Antwerpen', 'ant', 'AW', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('743', '1', '21', '0', 'Limburg', 'lim', 'LI', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('744', '1', '21', '0', 'Oost-Vlaanderen', 'ov', 'OV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('745', '1', '21', '0', 'Vlaams-Brabant', 'vb', 'VB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('746', '1', '21', '0', 'West-Vlaanderen', 'wv', 'WV', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('747', '1', '21', '0', 'Waals-Brabant (Brabant wallon)', 'wb', 'WB', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('748', '1', '21', '0', 'Henegouwen (Hainaut),', 'he', 'HE', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('749', '1', '21', '0', 'Luik (Liège/Lüttich)', 'lui', 'LU', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('750', '1', '21', '0', 'Luxemburg (Luxembourg)', 'lux', 'LX', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('751', '1', '215', '0', 'Adana', 'ADN', '01', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('752', '1', '215', '0', 'Adıyaman', 'ADY', '02', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('753', '1', '215', '0', 'Afyon', 'AFN', '03', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('754', '1', '215', '0', 'Ağrı', 'AGR', '04', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('755', '1', '215', '0', 'Amasya', 'AMS', '05', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('756', '1', '215', '0', 'Ankara', 'ANK', '06', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('757', '1', '215', '0', 'Antalya', 'ANT', '07', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('758', '1', '215', '0', 'Artvin', 'ART', '08', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('759', '1', '215', '0', 'Aydın', 'AYD', '09', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('760', '1', '215', '0', 'Balıkesir', 'BLK', '10', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('761', '1', '215', '0', 'Bilecik', 'BLC', '11', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('762', '1', '215', '0', 'Bingöl', 'BIN', '12', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('763', '1', '215', '0', 'Bitlis', 'BIT', '13', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('764', '1', '215', '0', 'Bolu', 'BOL', '14', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('765', '1', '215', '0', 'Burdur', 'DRD', '15', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('766', '1', '215', '0', 'Bursa', 'BUR', '16', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('767', '1', '215', '0', 'Çanakkale', 'CNK', '17', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('768', '1', '215', '0', 'Çankırı', 'CAK', '18', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('769', '1', '215', '0', 'Çorum', 'COR', '19', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('770', '1', '215', '0', 'Denizli', 'DEN', '20', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('771', '1', '215', '0', 'Diyarbakır', 'DYB', '21', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('772', '1', '215', '0', 'Edirne', 'EDR', '22', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('773', '1', '215', '0', 'Elazığ', 'ELZ', '23', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('774', '1', '215', '0', 'Erzincan', 'ERN', '24', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('775', '1', '215', '0', 'Erzurum', 'ERZ', '25', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('776', '1', '215', '0', 'Eskişehir', 'ESK', '26', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('777', '1', '215', '0', 'Gaziantep', 'GZA', '27', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('778', '1', '215', '0', 'Giresun', 'GRS', '28', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('779', '1', '215', '0', 'Gümüşhane', 'GMH', '29', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('780', '1', '215', '0', 'Hakkari', 'HKK', '30', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('781', '1', '215', '0', 'Hatay', 'HTY', '31', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('782', '1', '215', '0', 'Isparta', 'ISP', '32', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('783', '1', '215', '0', 'İçel (Mersin)', 'ICE', '33', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('784', '1', '215', '0', 'İstanbul', 'IST', '34', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('785', '1', '215', '0', 'İzmir', 'IZM', '35', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('786', '1', '215', '0', 'Kars', 'KRS', '36', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('787', '1', '215', '0', 'Kastamonu', 'KST', '37', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('788', '1', '215', '0', 'Kayseri', 'KYS', '38', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('789', '1', '215', '0', 'Kırklareli', 'KIR', '39', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('790', '1', '215', '0', 'Kırşehir', 'KIS', '40', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('791', '1', '215', '0', 'Kocaeli', 'KCL', '41', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('792', '1', '215', '0', 'Konya', 'KNY', '42', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('793', '1', '215', '0', 'Kütahya', 'KTH', '43', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('794', '1', '215', '0', 'Malatya', 'MLT', '44', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('795', '1', '215', '0', 'Manisa', 'MNS', '45', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('796', '1', '215', '0', 'K.maraş', 'KAH', '46', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('797', '1', '215', '0', 'Mardin', 'MRD', '47', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('798', '1', '215', '0', 'Muğla', 'MGL', '48', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('799', '1', '215', '0', 'Muş', 'MUS', '49', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('800', '1', '215', '0', 'Nevşehir', 'NEV', '50', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('801', '1', '215', '0', 'Niğde', 'NIG', '51', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('802', '1', '215', '0', 'Ordu', 'ORD', '52', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('803', '1', '215', '0', 'Rize', 'RIZ', '53', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('804', '1', '215', '0', 'Sakarya', 'SKR', '54', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('805', '1', '215', '0', 'Samsun', 'SMS', '55', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('806', '1', '215', '0', 'Siirt', 'SRT', '56', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('807', '1', '215', '0', 'Sinop', 'SNP', '57', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('808', '1', '215', '0', 'Sivas', 'SVS', '58', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('809', '1', '215', '0', 'Tekirdağ', 'TKR', '59', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('810', '1', '215', '0', 'Tokat', 'TKT', '60', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('811', '1', '215', '0', 'Trabzon', 'TRZ', '61', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('812', '1', '215', '0', 'Tunceli', 'TUN', '62', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('813', '1', '215', '0', 'Şanlıurfa', 'SNF', '63', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('814', '1', '215', '0', 'Uşak', 'USK', '64', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('815', '1', '215', '0', 'Van', 'VAN', '65', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('816', '1', '215', '0', 'Yozgat', 'YZT', '66', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('817', '1', '215', '0', 'Zonguldak', 'ZNG', '67', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('818', '1', '215', '0', 'Aksaray', 'AKS', '68', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('819', '1', '215', '0', 'Bayburt', 'BYB', '69', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('820', '1', '215', '0', 'Karaman', 'KRM', '70', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('821', '1', '215', '0', 'Kırıkkale', 'KRK', '71', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('822', '1', '215', '0', 'Batman', 'BTM', '72', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('823', '1', '215', '0', 'Şırnak', 'SRK', '73', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('824', '1', '215', '0', 'Bartın', 'BRT', '74', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('825', '1', '215', '0', 'Ardahan', 'ARH', '75', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('826', '1', '215', '0', 'Iğdır', 'IGD', '76', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('827', '1', '215', '0', 'Yalova', 'TLV', '77', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('828', '1', '215', '0', 'Karabük', 'KRB', '78', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('829', '1', '215', '0', 'Kilis', 'KLS', '79', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('830', '1', '215', '0', 'Osmaniye', 'OSM', '80', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

INSERT INTO lal5d_virtuemart_states
(`virtuemart_state_id`, `virtuemart_vendor_id`, `virtuemart_country_id`, `virtuemart_worldzone_id`, `state_name`, `state_3_code`, `state_2_code`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('831', '1', '215', '0', 'Düzce', 'DZC', '81', '0', '1', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_userfield_values`;
CREATE TABLE `lal5d_virtuemart_userfield_values` (
  `virtuemart_userfield_value_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_userfield_id` int(1) unsigned NOT NULL DEFAULT '0',
  `fieldtitle` varchar(255) NOT NULL DEFAULT '',
  `fieldvalue` varchar(255) NOT NULL DEFAULT '',
  `sys` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_userfield_value_id`),
  KEY `virtuemart_userfield_id` (`virtuemart_userfield_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='Holds the different values for dropdown and radio lists';

INSERT INTO lal5d_virtuemart_userfield_values
(`virtuemart_userfield_value_id`, `virtuemart_userfield_id`, `fieldtitle`, `fieldvalue`, `sys`, `ordering`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '23', 'COM_VIRTUEMART_SHOPPER_TITLE_MR', 'Mr', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('2', '23', 'COM_VIRTUEMART_SHOPPER_TITLE_MRS', 'Mrs', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('3', '51', 'None', '', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('4', '51', 'Non-resident (Canada)', 'R', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('5', '51', 'Federal government (United States)', 'A', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('6', '51', 'State government (United States)', 'B', '0', '2', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('7', '51', 'Tribe / Status Indian / Indian Band (both)', 'C', '0', '3', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('8', '51', 'Foreign diplomat (both)', 'D', '0', '4', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('9', '51', 'Charitable or benevolent org (both)', 'E', '0', '5', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('10', '51', 'Religious or educational org (both)', 'F', '0', '6', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('11', '51', 'Resale (both)', 'G', '0', '7', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('12', '51', 'Commercial agricultural production (both)', 'H', '0', '8', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('13', '51', 'Industrial production / manufacturer (both)', 'I', '0', '9', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('14', '51', 'Direct pay permit (United States)', 'J', '0', '10', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('15', '51', 'Direct mail (United States)', 'K', '0', '11', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('16', '51', 'Other (both)', 'L', '0', '12', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('17', '51', 'Local government (United States)', 'N', '0', '13', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('18', '51', 'Commercial aquaculture (Canada)', 'P', '0', '14', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('19', '51', 'Commercial Fishery (Canada)', 'Q', '0', '15', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_userfields`;
CREATE TABLE `lal5d_virtuemart_userfields` (
  `virtuemart_userfield_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '1',
  `userfield_jplugin_id` int(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(2048) DEFAULT NULL,
  `type` varchar(70) NOT NULL DEFAULT '',
  `maxlength` int(1) DEFAULT NULL,
  `size` int(1) DEFAULT NULL,
  `required` tinyint(4) NOT NULL DEFAULT '0',
  `cols` int(1) DEFAULT NULL,
  `rows` int(1) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `default` varchar(255) DEFAULT NULL,
  `registration` tinyint(1) NOT NULL DEFAULT '0',
  `shipment` tinyint(1) NOT NULL DEFAULT '0',
  `account` tinyint(1) NOT NULL DEFAULT '1',
  `cart` tinyint(1) NOT NULL DEFAULT '0',
  `readonly` tinyint(1) NOT NULL DEFAULT '0',
  `calculated` tinyint(1) NOT NULL DEFAULT '0',
  `sys` tinyint(4) NOT NULL DEFAULT '0',
  `userfield_params` varchar(17000) NOT NULL DEFAULT '',
  `ordering` int(1) NOT NULL DEFAULT '0',
  `shared` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_userfield_id`),
  UNIQUE KEY `name` (`name`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `ordering` (`ordering`),
  KEY `shared` (`shared`),
  KEY `published` (`published`),
  KEY `account` (`account`),
  KEY `shipment` (`shipment`),
  KEY `cart` (`cart`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COMMENT='Holds the fields for the user information';

INSERT INTO lal5d_virtuemart_userfields
(`virtuemart_userfield_id`, `virtuemart_vendor_id`, `userfield_jplugin_id`, `name`, `title`, `description`, `type`, `maxlength`, `size`, `required`, `cols`, `rows`, `value`, `default`, `registration`, `shipment`, `account`, `cart`, `readonly`, `calculated`, `sys`, `userfield_params`, `ordering`, `shared`, `published`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('5', '0', '0', 'email', 'COM_VIRTUEMART_REGISTER_EMAIL', '', 'emailaddress', '100', '30', '1', '', '', '', '', '1', '0', '1', '0', '0', '0', '1', '', '4', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('6', '0', '0', 'name', 'COM_VIRTUEMART_USER_DISPLAYED_NAME', '', 'text', '25', '30', '1', '0', '0', '', '', '1', '0', '1', '0', '0', '0', '1', '', '8', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('7', '0', '0', 'username', 'COM_VIRTUEMART_USERNAME', '', 'text', '25', '30', '1', '0', '0', '', '', '1', '0', '1', '0', '0', '0', '1', '', '6', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('8', '0', '0', 'password', 'COM_VIRTUEMART_SHOPPER_FORM_PASSWORD_1', '', 'password', '25', '30', '1', '', '', '', '', '1', '0', '1', '0', '0', '0', '1', '', '10', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('9', '0', '0', 'password2', 'COM_VIRTUEMART_SHOPPER_FORM_PASSWORD_2', '', 'password', '25', '30', '1', '', '', '', '', '1', '0', '1', '0', '0', '0', '1', '', '12', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('15', '0', '0', 'agreed', 'COM_VIRTUEMART_I_AGREE_TO_TOS', '', 'checkbox', '', '', '0', '', '', '', '', '0', '0', '0', '0', '0', '0', '1', '', '13', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('16', '0', '0', 'tos', 'COM_VIRTUEMART_STORE_FORM_TOS', '', 'custom', '', '', '1', '', '', '', '', '0', '0', '0', '1', '0', '0', '1', '', '14', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('17', '0', '0', 'customer_note', 'COM_VIRTUEMART_CNOTES_CART', '', 'textarea', '2500', '', '0', '60', '1', '', '', '0', '0', '0', '1', '0', '0', '1', '', '13', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('20', '0', '0', 'address_type_name', 'COM_VIRTUEMART_USER_FORM_ADDRESS_LABEL', '', 'text', '32', '30', '1', '', '', '', 'COM_VIRTUEMART_USER_FORM_ST_LABEL', '0', '1', '0', '0', '0', '0', '1', '', '16', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('21', '0', '0', 'delimiter_billto', 'COM_VIRTUEMART_USER_FORM_BILLTO_LBL', '', 'delimiter', '25', '30', '0', '', '', '', '', '1', '0', '1', '0', '0', '0', '0', '', '18', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('22', '0', '0', 'company', 'COM_VIRTUEMART_SHOPPER_FORM_COMPANY_NAME', '', 'text', '64', '30', '0', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '20', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('23', '0', '0', 'title', 'COM_VIRTUEMART_SHOPPER_FORM_TITLE', '', 'select', '0', '210', '0', '', '', '', '', '1', '0', '1', '0', '0', '0', '1', '', '22', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('24', '0', '0', 'first_name', 'COM_VIRTUEMART_SHOPPER_FORM_FIRST_NAME', '', 'text', '32', '30', '1', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '24', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('25', '0', '0', 'middle_name', 'COM_VIRTUEMART_SHOPPER_FORM_MIDDLE_NAME', '', 'text', '32', '30', '0', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '26', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('26', '0', '0', 'last_name', 'COM_VIRTUEMART_SHOPPER_FORM_LAST_NAME', '', 'text', '32', '30', '1', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '28', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('27', '0', '0', 'address_1', 'COM_VIRTUEMART_SHOPPER_FORM_ADDRESS_1', '', 'text', '64', '30', '1', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '30', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('28', '0', '0', 'address_2', 'COM_VIRTUEMART_SHOPPER_FORM_ADDRESS_2', '', 'text', '64', '30', '0', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '32', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('29', '0', '0', 'zip', 'COM_VIRTUEMART_SHOPPER_FORM_ZIP', '', 'text', '32', '30', '1', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '34', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('35', '0', '0', 'city', 'COM_VIRTUEMART_SHOPPER_FORM_CITY', '', 'text', '32', '30', '1', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '36', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('36', '0', '0', 'virtuemart_country_id', 'COM_VIRTUEMART_SHOPPER_FORM_COUNTRY', '', 'select', '0', '210', '1', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '38', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('37', '0', '0', 'virtuemart_state_id', 'COM_VIRTUEMART_SHOPPER_FORM_STATE', '', 'select', '0', '210', '1', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '40', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('38', '0', '0', 'phone_1', 'COM_VIRTUEMART_SHOPPER_FORM_PHONE', '', 'text', '32', '30', '0', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '42', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('39', '0', '0', 'phone_2', 'COM_VIRTUEMART_SHOPPER_FORM_PHONE2', '', 'text', '32', '30', '0', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '44', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('40', '0', '0', 'fax', 'COM_VIRTUEMART_SHOPPER_FORM_FAX', '', 'text', '32', '30', '0', '', '', '', '', '1', '1', '1', '0', '0', '0', '1', '', '46', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('41', '0', '0', 'delimiter_sendregistration', 'COM_VIRTUEMART_BUTTON_SEND_REG', '', 'delimiter', '25', '30', '0', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '', '2', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('42', '0', '0', 'delimiter_userinfo', 'COM_VIRTUEMART_ORDER_PRINT_CUST_INFO_LBL', '', 'delimiter', '', '', '0', '', '', '', '', '1', '0', '1', '0', '0', '0', '0', '', '14', '0', '1', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('50', '0', '0', 'tax_exemption_number', 'COM_VIRTUEMART_SHOPPER_FORM_TAXEXEMPTION_NBR', 'Vendors can set here a tax exemption number for a shopper. This field is only changeable by administrators.', 'text', '10', '0', '0', '0', '0', '', '', '0', '0', '1', '1', '0', '0', '0', '', '48', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0'),
('51', '0', '0', 'tax_usage_type', 'COM_VIRTUEMART_SHOPPER_FORM_TAX_USAGE', 'Federal, national, educational, public, or similar often get a special tax. This field is only writable by administrators.', 'select', '0', '0', '0', '0', '0', '', '', '0', '0', '1', '1', '0', '0', '0', '', '50', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_userinfos`;
CREATE TABLE `lal5d_virtuemart_userinfos` (
  `virtuemart_userinfo_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_user_id` int(1) unsigned NOT NULL DEFAULT '0',
  `address_type` char(2) NOT NULL DEFAULT '',
  `address_type_name` varchar(32) NOT NULL DEFAULT '',
  `company` varchar(64) DEFAULT NULL,
  `title` varchar(32) DEFAULT NULL,
  `last_name` varchar(96) DEFAULT NULL,
  `first_name` varchar(96) DEFAULT NULL,
  `middle_name` varchar(96) DEFAULT NULL,
  `phone_1` varchar(32) DEFAULT NULL,
  `phone_2` varchar(32) DEFAULT NULL,
  `fax` varchar(32) DEFAULT NULL,
  `address_1` varchar(96) NOT NULL DEFAULT '',
  `address_2` varchar(64) DEFAULT NULL,
  `city` varchar(96) NOT NULL DEFAULT '',
  `virtuemart_state_id` smallint(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_country_id` smallint(1) unsigned NOT NULL DEFAULT '0',
  `zip` varchar(32) NOT NULL DEFAULT '',
  `agreed` tinyint(1) NOT NULL DEFAULT '0',
  `tos` tinyint(1) NOT NULL DEFAULT '0',
  `customer_note` varchar(5000) NOT NULL DEFAULT '',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_userinfo_id`),
  KEY `i_virtuemart_user_id` (`virtuemart_userinfo_id`,`virtuemart_user_id`),
  KEY `virtuemart_user_id` (`virtuemart_user_id`,`address_type`),
  KEY `address_type` (`address_type`),
  KEY `address_type_name` (`address_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Customer Information, BT = BillTo and ST = ShipTo';

INSERT INTO lal5d_virtuemart_userinfos
(`virtuemart_userinfo_id`, `virtuemart_user_id`, `address_type`, `address_type_name`, `company`, `title`, `last_name`, `first_name`, `middle_name`, `phone_1`, `phone_2`, `fax`, `address_1`, `address_2`, `city`, `virtuemart_state_id`, `virtuemart_country_id`, `zip`, `agreed`, `tos`, `customer_note`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', '602', 'BT', '', 'Sample Company', 'Mr', 'John', 'Doe', '', '555-555-555', '', '', 'PO Box 123', '', 'Seattle', '48', '223', '98101', '0', '0', '', '2016-11-12 05:34:51', '602', '2016-11-12 05:34:51', '602', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_vendor_medias`;
CREATE TABLE `lal5d_virtuemart_vendor_medias` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_media_id` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`,`virtuemart_media_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_vendor_medias
(`id`, `virtuemart_vendor_id`, `virtuemart_media_id`, `ordering`) VALUES 
('1', '1', '1', '1');

DROP TABLE IF EXISTS `lal5d_virtuemart_vendor_users`;
CREATE TABLE `lal5d_virtuemart_vendor_users` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_user_id` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`,`virtuemart_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `lal5d_virtuemart_vendors`;
CREATE TABLE `lal5d_virtuemart_vendors` (
  `virtuemart_vendor_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(64) DEFAULT NULL,
  `vendor_currency` int(1) DEFAULT NULL,
  `vendor_accepted_currencies` varchar(1536) NOT NULL DEFAULT '',
  `vendor_params` varchar(17000) NOT NULL DEFAULT '',
  `metarobot` varchar(20) DEFAULT NULL,
  `metaauthor` varchar(64) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_vendor_id`),
  KEY `vendor_name` (`vendor_name`),
  KEY `vendor_currency` (`vendor_currency`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Vendors manage their products in your store';

INSERT INTO lal5d_virtuemart_vendors
(`virtuemart_vendor_id`, `vendor_name`, `vendor_currency`, `vendor_accepted_currencies`, `vendor_params`, `metarobot`, `metaauthor`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('1', 'Sample Company', '47', '52,26,47,144', 'max_cats_per_product=-1|vendor_min_pov=0|vendor_min_poq=1|vendor_freeshipment=0|vendor_address_format=\"\"|vendor_date_format=\"\"|vendor_letter_format=\"A4\"|vendor_letter_orientation=\"P\"|vendor_letter_margin_top=55|vendor_letter_margin_left=25|vendor_letter_margin_right=25|vendor_letter_margin_bottom=25|vendor_letter_margin_header=20|vendor_letter_margin_footer=20|vendor_letter_font=\"helvetica\"|vendor_letter_font_size=8|vendor_letter_header_font_size=7|vendor_letter_footer_font_size=6|vendor_letter_header=1|vendor_letter_header_line=1|vendor_letter_header_line_color=\"#000000\"|vendor_letter_header_image=\"1\"|vendor_letter_header_imagesize=60|vendor_letter_header_cell_height_ratio=1|vendor_letter_footer=1|vendor_letter_footer_line=1|vendor_letter_footer_line_color=\"#000000\"|vendor_letter_footer_cell_height_ratio=1|vendor_letter_add_tos=0|vendor_letter_add_tos_newpage=1|vendor_letter_for_product_pdf=0|vendor_mail_width=640|vendor_mail_header=1|vendor_mail_tos=1|vendor_mail_logo=1|vendor_mail_logo_width=200|vendor_mail_font=\"helvetica\"|vendor_mail_header_font_size=11|vendor_mail_font_size=12|vendor_mail_footer_font_size=10|', '', '', '0000-00-00 00:00:00', '0', '2016-11-12 05:34:51', '602', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_vendors_en_gb`;
CREATE TABLE `lal5d_virtuemart_vendors_en_gb` (
  `virtuemart_vendor_id` int(1) unsigned NOT NULL,
  `vendor_store_desc` text NOT NULL,
  `vendor_terms_of_service` text NOT NULL,
  `vendor_legal_info` text NOT NULL,
  `vendor_letter_css` text NOT NULL,
  `vendor_letter_header_html` varchar(8000) NOT NULL DEFAULT '<h1>{vm:vendorname}</h1><p>{vm:vendoraddress}</p>',
  `vendor_letter_footer_html` varchar(8000) NOT NULL DEFAULT '<p>{vm:vendorlegalinfo}<br />Page {vm:pagenum}/{vm:pagecount}</p>',
  `vendor_store_name` varchar(180) NOT NULL DEFAULT '',
  `vendor_phone` varchar(26) NOT NULL DEFAULT '',
  `vendor_url` varchar(255) NOT NULL DEFAULT '',
  `metadesc` varchar(400) NOT NULL DEFAULT '',
  `metakey` varchar(400) NOT NULL DEFAULT '',
  `customtitle` varchar(255) NOT NULL DEFAULT '',
  `vendor_invoice_free1` varchar(255) NOT NULL DEFAULT '',
  `vendor_invoice_free2` varchar(255) NOT NULL DEFAULT '',
  `vendor_mail_free1` varchar(255) NOT NULL DEFAULT '',
  `vendor_mail_free2` varchar(255) NOT NULL DEFAULT '',
  `vendor_mail_css` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(192) NOT NULL DEFAULT '',
  PRIMARY KEY (`virtuemart_vendor_id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO lal5d_virtuemart_vendors_en_gb
(`virtuemart_vendor_id`, `vendor_store_desc`, `vendor_terms_of_service`, `vendor_legal_info`, `vendor_letter_css`, `vendor_letter_header_html`, `vendor_letter_footer_html`, `vendor_store_name`, `vendor_phone`, `vendor_url`, `metadesc`, `metakey`, `customtitle`, `vendor_invoice_free1`, `vendor_invoice_free2`, `vendor_mail_free1`, `vendor_mail_free2`, `vendor_mail_css`, `slug`) VALUES 
('1', '<p>Welcome to VirtueMart the ecommerce managment system. The sample data give you a good insight of the possibilities with VirtueMart. The product description is directly the manual to configure the demonstrated features. \\n </p><p>You see here the store description used to describe your store. Check it out!</p> <p>We were established in 1869 in a time when getting good clothes was expensive, but the quality was good. Now that only a select few of those authentic clothes survive, we have dedicated this store to bringing the experience alive for collectors and master carrier everywhere.</p>', '<h5>This is a demo store. Your orders will not proceed. You have not configured any terms of service yet. Click <a href=\"/joomlaecommerce/administrator/index.php?option=com_virtuemart&view=user&task=editshop\">here</a> to change this text.</h5>', 'VAT-ID: XYZ-DEMO<br />Reg.Nr: DEMONUMBER', '.vmdoc-header { }\n.vmdoc-footer { }\n', '<h1>{vm:vendorname}</h1><p>{vm:vendoraddress}</p>', '{vm:vendorlegalinfo}<br /> Page {vm:pagenum}/{vm:pagecount}', 'VirtueMart 3 Sample store', '', 'http://localhost/joomlaecommerce/', '', '', '', '', '', '', '', '', 'virtuemart-3-sample-store');

DROP TABLE IF EXISTS `lal5d_virtuemart_vmuser_shoppergroups`;
CREATE TABLE `lal5d_virtuemart_vmuser_shoppergroups` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_user_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_shoppergroup_id` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `virtuemart_user_id` (`virtuemart_user_id`,`virtuemart_shoppergroup_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='xref table for users to shopper group';

DROP TABLE IF EXISTS `lal5d_virtuemart_vmusers`;
CREATE TABLE `lal5d_virtuemart_vmusers` (
  `virtuemart_user_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned NOT NULL DEFAULT '0',
  `user_is_vendor` tinyint(1) NOT NULL DEFAULT '0',
  `customer_number` varchar(32) DEFAULT NULL,
  `virtuemart_paymentmethod_id` int(1) unsigned DEFAULT NULL,
  `virtuemart_shipmentmethod_id` int(1) unsigned DEFAULT NULL,
  `agreed` tinyint(1) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_user_id`),
  UNIQUE KEY `u_virtuemart_user_id` (`virtuemart_user_id`,`virtuemart_vendor_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`),
  KEY `user_is_vendor` (`user_is_vendor`)
) ENGINE=InnoDB AUTO_INCREMENT=603 DEFAULT CHARSET=utf8 COMMENT='Holds the unique user data';

INSERT INTO lal5d_virtuemart_vmusers
(`virtuemart_user_id`, `virtuemart_vendor_id`, `user_is_vendor`, `customer_number`, `virtuemart_paymentmethod_id`, `virtuemart_shipmentmethod_id`, `agreed`, `created_on`, `created_by`, `modified_on`, `modified_by`, `locked_on`, `locked_by`) VALUES 
('602', '1', '1', 'TH282143f', '0', '0', '0', '2016-11-12 05:34:51', '602', '2016-11-12 05:34:51', '602', '0000-00-00 00:00:00', '0');

DROP TABLE IF EXISTS `lal5d_virtuemart_waitingusers`;
CREATE TABLE `lal5d_virtuemart_waitingusers` (
  `virtuemart_waitinguser_id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_product_id` int(1) unsigned NOT NULL DEFAULT '0',
  `virtuemart_user_id` int(1) unsigned NOT NULL DEFAULT '0',
  `notify_email` varchar(150) NOT NULL DEFAULT '',
  `notified` tinyint(1) NOT NULL DEFAULT '0',
  `notify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ordering` int(1) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_waitinguser_id`),
  KEY `virtuemart_product_id` (`virtuemart_product_id`),
  KEY `notify_email` (`notify_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores notifications, users waiting f. products out of stock';

DROP TABLE IF EXISTS `lal5d_virtuemart_worldzones`;
CREATE TABLE `lal5d_virtuemart_worldzones` (
  `virtuemart_worldzone_id` smallint(1) unsigned NOT NULL AUTO_INCREMENT,
  `virtuemart_vendor_id` int(1) unsigned DEFAULT NULL,
  `zone_name` varchar(255) DEFAULT NULL,
  `zone_cost` decimal(10,2) DEFAULT NULL,
  `zone_limit` decimal(10,2) DEFAULT NULL,
  `zone_description` varchar(18000) DEFAULT NULL,
  `zone_tax_rate` int(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(1) NOT NULL DEFAULT '0',
  `shared` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(1) NOT NULL DEFAULT '0',
  `modified_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(1) NOT NULL DEFAULT '0',
  `locked_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `locked_by` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`virtuemart_worldzone_id`),
  KEY `virtuemart_vendor_id` (`virtuemart_vendor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='The Zones managed by the Zone Shipment Module';